"""Synthetic-only FFprobe metadata checks for two phone views."""

from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, NoReturn

from .errors import AcquisitionValidationError
from .manifest import VerifiedFile


REGISTRY_SCHEMA_VERSION = "causalmove-synthetic-acquisition-registry-v1"
APPROVED_SYNTHETIC_ACQUISITION_REGISTRY_SHA256 = (
    "c5a90f85b832ee07e7bb0cb8ba97b2ae8f3d116d41f3fe45bc5339bd90090b96"
)
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
REGISTRY_FIELDS = frozenset(
    {
        "schema_version",
        "registry_id",
        "test_only",
        "ffprobe_version_prefix",
        "codec_name",
        "width",
        "height",
        "frame_rate_fps",
        "frame_rate_tolerance_fps",
        "frame_count",
        "duration_s",
        "duration_tolerance_s",
        "maximum_missing_frame_fraction",
        "maximum_sync_offset_s",
        "maximum_drift_ppm",
        "maximum_reprojection_error_px",
    }
)


class _DuplicateFieldError(ValueError):
    pass


def _fail(code: str, field: str) -> NoReturn:
    raise AcquisitionValidationError(code, field)


def _reject_duplicate_fields(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateFieldError
        result[key] = value
    return result


def _mapping(value: object, field: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        _fail("invalid_type", field)
    return value


def _string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("invalid_string", field)
    return value


def _number(value: object, field: str, *, minimum: float = 0.0) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < minimum:
        _fail("invalid_number", field)
    return parsed


def _integer(value: object, field: str, *, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        _fail("invalid_integer", field)
    return value


@dataclass(frozen=True)
class AcquisitionRegistry:
    schema_version: str
    registry_id: str
    registry_sha256: str
    test_only: bool
    ffprobe_version_prefix: str
    codec_name: str
    width: int
    height: int
    frame_rate_fps: float
    frame_rate_tolerance_fps: float
    frame_count: int
    duration_s: float
    duration_tolerance_s: float
    maximum_missing_frame_fraction: float
    maximum_sync_offset_s: float
    maximum_drift_ppm: float
    maximum_reprojection_error_px: float


@dataclass(frozen=True)
class AcquisitionContext:
    sync_offset_s: float
    drift_ppm: float
    reprojection_error_px: float

    def __post_init__(self) -> None:
        for field, value in (
            ("sync_offset_s", self.sync_offset_s),
            ("drift_ppm", self.drift_ppm),
            ("reprojection_error_px", self.reprojection_error_px),
        ):
            _number(value, f"acquisition_context.{field}")


@dataclass(frozen=True)
class VideoMetadata:
    relative_file_id: str
    codec_name: str
    width: int
    height: int
    frame_rate_fps: float
    frame_count: int
    duration_s: float
    missing_frame_fraction: float
    ffprobe_version: str


@dataclass(frozen=True)
class AcquisitionResult:
    state: str
    failure_codes: tuple[str, ...]
    calibration_eligible: bool
    replacement_authorized: bool
    video_metadata: tuple[VideoMetadata, ...]
    acquisition_registry_id: str
    acquisition_registry_sha256: str


def load_synthetic_acquisition_registry(
    path: Path, expected_sha256: str
) -> AcquisitionRegistry:
    """Load the one hashed test registry without accepting a real registry."""

    if not isinstance(path, Path) or not isinstance(expected_sha256, str):
        _fail("invalid_type", "acquisition_registry")
    if SHA256_PATTERN.fullmatch(expected_sha256) is None:
        _fail("invalid_sha256", "acquisition_registry.sha256")
    try:
        payload = path.read_bytes()
    except OSError:
        _fail("registry_read_error", "acquisition_registry")
    digest = hashlib.sha256(payload).hexdigest()
    if digest != expected_sha256:
        _fail("registry_hash_mismatch", "acquisition_registry")
    try:
        raw = json.loads(
            payload.decode("utf-8"), object_pairs_hook=_reject_duplicate_fields
        )
    except _DuplicateFieldError:
        _fail("duplicate_field", "acquisition_registry")
    except (UnicodeDecodeError, json.JSONDecodeError):
        _fail("invalid_json", "acquisition_registry")
    mapping = _mapping(raw, "acquisition_registry")
    if set(mapping) - REGISTRY_FIELDS:
        _fail("unknown_field", "acquisition_registry")
    if REGISTRY_FIELDS - set(mapping):
        _fail("missing_field", "acquisition_registry")
    if digest != APPROVED_SYNTHETIC_ACQUISITION_REGISTRY_SHA256:
        _fail("unapproved_registry_digest", "acquisition_registry")
    schema_version = _string(mapping["schema_version"], "acquisition_registry.schema")
    if schema_version != REGISTRY_SCHEMA_VERSION:
        _fail("unsupported_schema", "acquisition_registry.schema")
    if mapping["test_only"] is not True:
        _fail("real_registry_not_authorized", "acquisition_registry")

    maximum_missing = _number(
        mapping["maximum_missing_frame_fraction"],
        "acquisition_registry.maximum_missing_frame_fraction",
    )
    if maximum_missing > 1.0:
        _fail(
            "invalid_number", "acquisition_registry.maximum_missing_frame_fraction"
        )
    return AcquisitionRegistry(
        schema_version=schema_version,
        registry_id=_string(mapping["registry_id"], "acquisition_registry.registry_id"),
        registry_sha256=digest,
        test_only=True,
        ffprobe_version_prefix=_string(
            mapping["ffprobe_version_prefix"],
            "acquisition_registry.ffprobe_version_prefix",
        ),
        codec_name=_string(
            mapping["codec_name"], "acquisition_registry.codec_name"
        ),
        width=_integer(mapping["width"], "acquisition_registry.width", minimum=1),
        height=_integer(mapping["height"], "acquisition_registry.height", minimum=1),
        frame_rate_fps=_number(
            mapping["frame_rate_fps"], "acquisition_registry.frame_rate_fps"
        ),
        frame_rate_tolerance_fps=_number(
            mapping["frame_rate_tolerance_fps"],
            "acquisition_registry.frame_rate_tolerance_fps",
        ),
        frame_count=_integer(
            mapping["frame_count"], "acquisition_registry.frame_count", minimum=1
        ),
        duration_s=_number(
            mapping["duration_s"], "acquisition_registry.duration_s"
        ),
        duration_tolerance_s=_number(
            mapping["duration_tolerance_s"],
            "acquisition_registry.duration_tolerance_s",
        ),
        maximum_missing_frame_fraction=maximum_missing,
        maximum_sync_offset_s=_number(
            mapping["maximum_sync_offset_s"],
            "acquisition_registry.maximum_sync_offset_s",
        ),
        maximum_drift_ppm=_number(
            mapping["maximum_drift_ppm"], "acquisition_registry.maximum_drift_ppm"
        ),
        maximum_reprojection_error_px=_number(
            mapping["maximum_reprojection_error_px"],
            "acquisition_registry.maximum_reprojection_error_px",
        ),
    )


def _parse_frame_rate(value: object) -> float:
    text = _string(value, "ffprobe.frame_rate")
    parts = text.split("/")
    if len(parts) != 2:
        _fail("decode_failure", "ffprobe.frame_rate")
    try:
        numerator = float(parts[0])
        denominator = float(parts[1])
    except ValueError:
        _fail("decode_failure", "ffprobe.frame_rate")
    if not math.isfinite(numerator) or not math.isfinite(denominator) or denominator == 0:
        _fail("decode_failure", "ffprobe.frame_rate")
    return numerator / denominator


def _probe_video(
    source: VerifiedFile,
    registry: AcquisitionRegistry,
    ffprobe_executable: Path,
) -> VideoMetadata:
    try:
        version = subprocess.run(
            [str(ffprobe_executable), "-version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        _fail("decode_failure", "ffprobe")
    if version.returncode != 0 or not version.stdout:
        _fail("decode_failure", "ffprobe")
    version_line = version.stdout.splitlines()[0]
    if not version_line.startswith(registry.ffprobe_version_prefix):
        _fail("ffprobe_version_mismatch", "ffprobe")

    try:
        completed = subprocess.run(
            [
                str(ffprobe_executable),
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=codec_name,width,height,avg_frame_rate,nb_frames,duration",
                "-of",
                "json",
                str(source.resolved_path),
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        _fail("decode_failure", "ffprobe")
    if completed.returncode != 0:
        _fail("decode_failure", "ffprobe")
    try:
        report = json.loads(completed.stdout)
        streams = report["streams"]
        if not isinstance(streams, list) or len(streams) != 1:
            raise ValueError
        stream = streams[0]
        if not isinstance(stream, dict):
            raise ValueError
        codec_name = _string(stream["codec_name"], "ffprobe.codec_name")
        width = _integer(stream["width"], "ffprobe.width", minimum=1)
        height = _integer(stream["height"], "ffprobe.height", minimum=1)
        frame_rate = _parse_frame_rate(stream["avg_frame_rate"])
        frame_count = int(_string(stream["nb_frames"], "ffprobe.nb_frames"))
        duration = float(_string(stream["duration"], "ffprobe.duration"))
    except (AcquisitionValidationError, KeyError, TypeError, ValueError):
        _fail("decode_failure", "ffprobe")
    if frame_count < 1 or not math.isfinite(duration) or duration <= 0.0:
        _fail("decode_failure", "ffprobe")
    missing_fraction = max(0, registry.frame_count - frame_count) / registry.frame_count
    return VideoMetadata(
        relative_file_id=source.relative_uri,
        codec_name=codec_name,
        width=width,
        height=height,
        frame_rate_fps=frame_rate,
        frame_count=frame_count,
        duration_s=duration,
        missing_frame_fraction=missing_fraction,
        ffprobe_version=version_line,
    )


def _source_integrity_matches(source: VerifiedFile) -> bool:
    try:
        payload = source.resolved_path.read_bytes()
    except OSError:
        return False
    return len(payload) == source.size_bytes and hashlib.sha256(payload).hexdigest() == (
        source.sha256
    )


def evaluate_acquisition(
    views: tuple[VerifiedFile, VerifiedFile],
    context: AcquisitionContext,
    registry: AcquisitionRegistry,
    *,
    ffprobe_executable: Path,
) -> AcquisitionResult:
    """Evaluate technical QC without deleting or replacing a failed attempt."""

    if not isinstance(views, tuple) or len(views) != 2:
        _fail("view_count", "acquisition.views")
    if not isinstance(context, AcquisitionContext) or not isinstance(
        registry, AcquisitionRegistry
    ):
        _fail("invalid_type", "acquisition")
    if not registry.test_only:
        _fail("real_registry_not_authorized", "acquisition_registry")
    if not isinstance(ffprobe_executable, Path):
        _fail("invalid_type", "ffprobe_executable")

    failure_codes: set[str] = set()
    if context.sync_offset_s > registry.maximum_sync_offset_s:
        failure_codes.add("sync_failure")
    if context.drift_ppm > registry.maximum_drift_ppm:
        failure_codes.add("drift_failure")
    if context.reprojection_error_px > registry.maximum_reprojection_error_px:
        failure_codes.add("calibration_failure")

    if any(not isinstance(view, VerifiedFile) for view in views) or any(
        not _source_integrity_matches(view) for view in views
    ):
        failure_codes.add("source_integrity_failure")
        metadata: tuple[VideoMetadata, ...] = ()
    else:
        probed: list[VideoMetadata] = []
        try:
            for view in views:
                probed.append(_probe_video(view, registry, ffprobe_executable))
        except AcquisitionValidationError as error:
            failure_codes.add(error.code)
            probed = []
        metadata = tuple(probed)

    for item in metadata:
        if item.codec_name != registry.codec_name:
            failure_codes.add("codec_mismatch")
        if item.width != registry.width or item.height != registry.height:
            failure_codes.add("resolution_mismatch")
        if abs(item.frame_rate_fps - registry.frame_rate_fps) > (
            registry.frame_rate_tolerance_fps
        ):
            failure_codes.add("frame_rate_mismatch")
        if item.frame_count != registry.frame_count:
            failure_codes.add("frame_count_mismatch")
        if abs(item.duration_s - registry.duration_s) > registry.duration_tolerance_s:
            failure_codes.add("duration_mismatch")
        if item.missing_frame_fraction > registry.maximum_missing_frame_fraction:
            failure_codes.add("missing_frames")

    ordered_failures = tuple(sorted(failure_codes))
    eligible = not ordered_failures
    return AcquisitionResult(
        state="phone_technical_pass" if eligible else "phone_technical_missing",
        failure_codes=ordered_failures,
        calibration_eligible=eligible,
        replacement_authorized=False,
        video_metadata=metadata,
        acquisition_registry_id=registry.registry_id,
        acquisition_registry_sha256=registry.registry_sha256,
    )
