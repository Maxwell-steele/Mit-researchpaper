"""Controlled errors for the phone-pipeline trust boundary."""

from __future__ import annotations


class ManifestValidationError(ValueError):
    """A manifest violation that never echoes participant data or file paths."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class TrajectoryValidationError(ValueError):
    """A trajectory violation that never echoes source values or raw paths."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class AcquisitionValidationError(ValueError):
    """An acquisition-contract violation with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class EventValidationError(ValueError):
    """A synthetic-event contract violation with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class FeatureValidationError(ValueError):
    """A registry or measurement violation with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class TrialBatchValidationError(ValueError):
    """A policy-bridge contract violation with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class ProvenanceError(ValueError):
    """A deterministic-bundle violation with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")


class SyntheticRunError(ValueError):
    """A local synthetic-run failure with controlled disclosure."""

    def __init__(self, code: str, field: str) -> None:
        self.code = code
        self.field = field
        super().__init__(f"{code}: {field}")
