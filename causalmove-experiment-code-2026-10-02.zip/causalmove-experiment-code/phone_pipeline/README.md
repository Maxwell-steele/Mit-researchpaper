# CausalMove phone-pipeline scaffold

**Current status:** Tasks 1–5 of the Stage 1 scaffold are implemented. The package validates one strict two-phone trial manifest, verifies referenced files inside a controlled local root, normalizes one exact test-only trajectory format, checks generated synthetic-video metadata with local FFprobe, validates explicit synthetic event annotations, emits registry-driven feature records, enforces an all-or-nothing policy-batch firewall, and writes a deterministic evidence bundle. It is synthetic-software-only and is not an athlete-facing measurement or coaching system.

## Implemented boundary

The accepted manifest version is `causalmove-phone-trial-v1`. The current code:

- rejects malformed JSON, duplicate keys, missing fields, and unknown fields;
- validates registered sports, cues, phases, analysis roles, pair identity, integer bases, and SHA-256 syntax;
- requires exactly two distinct devices with `frontal_oblique` and `sagittal_oblique` roles, distinct view files, and one shared synchronization-event ID;
- rejects absolute paths, parent traversal, backslash-based paths, missing files, directories, symlinks, and SHA-256 mismatches;
- blocks inputs whose face or audio processing status is `failed`;
- keeps resolved controlled paths out of error messages and object representations; and
- prevents held-out handball trials from entering population-development roles.

The Stage 1 loader accepts only manifests bearing the explicit synthetic sentinels used by the tests. It refuses other manifests with `real_data_not_authorized` before reading any referenced video or trajectory export. This sentinel is an accidental-use guard, not authentication and not a substitute for consent, ethics approval, access control, or an authorization registry.

## Run tests

From the project root:

```bash
/Users/caokhanhngoc/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  -m unittest discover -s phone_pipeline/tests -v
```

The complete phone-pipeline suite currently contains 118 behavioral tests. Acquisition and end-to-end tests require local FFmpeg and FFprobe. The reserved synthetic success path imports the existing NumPy policy prototype, so the documented bundled Python runtime is required for the complete suite.

## Run the synthetic evidence example

The normal command creates a new output directory and stops before `TrialBatch` with `load_measure_unavailable`:

```bash
/Users/caokhanhngoc/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  phone_pipeline/run_synthetic.py \
  --input phone_pipeline/tests/fixtures \
  --output /tmp/causalmove-synthetic-stage1-check
```

Use a new `--output` path for every run; existing directories are never overwritten. Package-module invocation is also supported with `-m phone_pipeline.run_synthetic`.

The output contains canonical JSON/TSV artifacts plus `bundle_manifest.json`. That manifest records the synthetic provider and adapter versions, event and feature versions, registry and source-tree hashes, execution environment, input hashes, warnings, failure codes, conversion reasons, and a sorted artifact hash inventory. Its `output_inventory_scope` is `artifacts_excluding_bundle_manifest_v1`: the manifest inventories every sibling artifact but cannot include its own SHA-256 without creating a self-referential hash.

## Canonical trajectory contract

Task 2 adds immutable canonical records with metre units, zero-based contiguous frames, strictly increasing timestamps, registered anatomical sides, source hashes, adapter versions, confidence, and controlled missingness reasons. It rejects partial or non-finite coordinates, invalid confidence, duplicate frame-landmark rows, incomplete frames, and mixed trial, coordinate-frame, source-hash, or adapter identities.

`SyntheticTrajectoryAdapter` demonstrates the provider interface using only `causalmove-synthetic-trajectory-v1`. It performs a fixed `mm`-to-`m` conversion and `(+x, +z, -y)` axis transform, inventories ignored fixture fields, rechecks the source bytes and URI against the verified manifest, and preserves missing coordinates without imputation. This format is not a real OpenCap export and must never be described as OpenCap-compatible.

## Acquisition, events, and features

Task 3 compares both synthetic view files against one SHA-256-bound acquisition registry using local FFprobe. It records codec, dimensions, frame rate, frame count, duration, synchronization, drift, and reprojection failures with controlled codes. Technical failures remain missing and are never replaced automatically.

The event interface currently accepts explicit test annotations only. It does not infer contact events from video and does not represent a trained detector. Every event is bound to the registered method, QC label, ordered sequence, uncertainty assumption, and source hashes before a feature can be calculated.

The feature layer calculates the synthetic completion score `ln(cut_completion_time / 1 s)`, admits only registered measures with exact units, converts out-of-range values to missing without clipping, and preserves immutable originals for side-normalized derivatives. Feature bundles keep technical acquisition, task-fidelity failure, and controlled safety-related missingness separate. Kinematic load is deliberately absent.

## Outcome firewall and policy bridge

The normal bridge returns `load_measure_unavailable` and does not import or create a policy `TrialBatch`. A single reserved test branch checks cue/control identity, phase and role permissions, complete blocks, unique sequence and pair IDs, counterbalanced order, registry/source hashes, and record integrity before creating any batch. It converts the lower-is-better task score to the prototype's larger-is-better convention by negation; the asymmetric golden example produces `(0.15, 0.03)` for cue-minus-control performance and load.

That success branch is restricted to the exact SHA-256-bound `SYNTHETIC_TEST_LOAD_V1` fixture and exact unit, range, version, and `SYNTHETIC_SOFTWARE_ONLY` label. A modified fixture, caller-supplied replacement hash, forged wider range, non-test registry, non-synthetic manifest, missing load, or partial pair returns no batch. The synthetic load is test data, not an estimated or measured knee moment.

## Not implemented

Tasks 1–5 do not upload data, contact OpenCap, support a real provider export, infer pose or foot-contact events from video, estimate mechanical load, or rank cues. FFprobe reads only technical video metadata. The end-to-end runner generates two tiny black videos; it does not ingest athlete footage. No production `TrialBatch` can be created: the normal path stops with `load_measure_unavailable` until a separately registered phone-load estimator is developed and validated against synchronized force and 3D reference measurements.

Passing these tests demonstrates software behavior only. It does not establish phone-measurement validity, athlete benefit, individual safety, injury prevention, transfer to games, or readiness for MIT Sloan SSAC submission.

## Input handling

Use an immutable synthetic snapshot under one controlled root. Original inputs must not change while hashing or later processing is running. No network operation exists in this package. Do not place names, team identifiers, dates of birth, contact details, medical narratives, raw paths, credentials, or access tokens in manifests or test fixtures.
