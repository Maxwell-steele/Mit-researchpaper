"""Run the complete local Stage 1 scaffold on generated synthetic inputs."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import platform
import shutil
import subprocess
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path
from typing import NoReturn

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "phone_pipeline"

from .acquisition import (
    AcquisitionContext,
    evaluate_acquisition,
    load_synthetic_acquisition_registry,
)
from .adapters.synthetic import SyntheticTrajectoryAdapter
from .errors import (
    AcquisitionValidationError,
    EventValidationError,
    FeatureValidationError,
    ManifestValidationError,
    ProvenanceError,
    SyntheticRunError,
    TrajectoryValidationError,
    TrialBatchValidationError,
)
from .events import EventEstimate, extract_synthetic_events
from .features import (
    MeasurementRecord,
    build_synthetic_measurements,
    build_trial_feature_bundle,
    load_synthetic_measure_registry,
)
from .manifest import load_and_verify_trial_manifest, parse_trial_manifest
from .provenance import (
    EvidenceProvenance,
    canonical_json_bytes,
    canonical_tsv_bytes,
    write_evidence_bundle,
)
from .trial_batch import (
    CalibrationTrialInput,
    LoadRegistryStatus,
    build_synthetic_test_load_record,
    convert_to_trial_batch,
    load_synthetic_test_load_registry,
)


BASE_MANIFEST_NAME = "trial_manifest_synthetic_v1.json"
BASE_MANIFEST_SHA256 = (
    "bd12805119651a0588fcf5338f09e635fdd2828e569a75151de28679d1e0a00d"
)
TRAJECTORY_NAME = "trajectory_e2e_synthetic_v1.json"
ACQUISITION_REGISTRY_NAME = "acquisition_registry_synthetic_v1.json"
MEASURE_REGISTRY_NAME = "measure_registry_synthetic_v1.json"
LOAD_REGISTRY_NAME = "synthetic_test_load_registry_v1.json"
GENERATED_VIDEO_HASH = (
    "57c236260c301e0364d959567c854c6de167a2a3181d1abb5aff6b928edff611"
)


def _fail(code: str, field: str) -> NoReturn:
    raise SyntheticRunError(code, field)


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _read_fixture(input_directory: Path, name: str) -> tuple[Path, bytes]:
    path = input_directory / name
    if path.is_symlink():
        _fail("symlink_not_allowed", "input_fixture")
    try:
        if not path.is_file():
            _fail("fixture_unavailable", "input_fixture")
        return path, path.read_bytes()
    except OSError:
        _fail("fixture_unavailable", "input_fixture")


def _source_tree_sha256() -> str:
    package_root = Path(__file__).resolve().parent
    project_root = package_root.parent
    files = sorted(package_root.rglob("*.py")) + [project_root / "prototype/causal_move.py"]
    digest = hashlib.sha256()
    for path in sorted(files, key=lambda value: value.relative_to(project_root).as_posix()):
        relative = path.relative_to(project_root).as_posix().encode("utf-8")
        try:
            payload = path.read_bytes()
        except OSError:
            _fail("source_tree_unavailable", "source_tree")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(hashlib.sha256(payload).digest())
    return digest.hexdigest()


def _generate_video(path: Path, ffmpeg_executable: Path) -> None:
    try:
        completed = subprocess.run(
            [
                str(ffmpeg_executable),
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "color=c=black:s=64x64:r=10:d=2.1",
                "-c:v",
                "mpeg4",
                "-an",
                str(path),
            ],
            check=False,
            capture_output=True,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        _fail("synthetic_video_generation_failed", "ffmpeg")
    if completed.returncode != 0:
        _fail("synthetic_video_generation_failed", "ffmpeg")
    try:
        digest = _sha256(path.read_bytes())
    except OSError:
        _fail("synthetic_video_generation_failed", "ffmpeg")
    if digest != GENERATED_VIDEO_HASH:
        _fail("synthetic_video_hash_mismatch", "ffmpeg")


def _event_annotations(score: float) -> dict[str, tuple[float, float]]:
    initial_contact = 0.68
    return {
        "approach": (0.10, 0.01),
        "penultimate_contact": (0.42, 0.01),
        "initial_contact": (initial_contact, 0.01),
        "weight_acceptance": (0.76, 0.01),
        "toe_off": (0.91, 0.01),
        "exit": (initial_contact + math.exp(score), 0.02),
    }


def _trial_specs() -> tuple[dict[str, object], ...]:
    specs: list[dict[str, object]] = []
    for block in range(2):
        cue_period = 1 if block == 0 else 2
        specs.extend(
            (
                {
                    "block": block,
                    "member": "active",
                    "period": cue_period,
                    "score": 0.10,
                    "load": 0.04,
                },
                {
                    "block": block,
                    "member": "control",
                    "period": 3 - cue_period,
                    "score": 0.25,
                    "load": 0.01,
                },
            )
        )
    return tuple(specs)


def _manifest_bytes(base_mapping: dict[str, object], spec: dict[str, object]) -> bytes:
    mapping = copy.deepcopy(base_mapping)
    block = int(spec["block"])
    member = str(spec["member"])
    mapping["trial_id"] = f"SYNTHETIC-T-{block}-{member}"
    mapping["pair_id"] = f"SYNTHETIC-PAIR-{block}"
    mapping["pair_replicate"] = block + 1
    mapping["block_index"] = block
    mapping["pair_sequence_index"] = block
    mapping["pair_member"] = member
    mapping["within_pair_period"] = int(spec["period"])
    mapping["assigned_condition_id"] = (
        mapping["active_cue_id"] if member == "active" else "CTRL_NEUTRAL_V1"
    )
    return canonical_json_bytes(mapping)


def _unavailable_load_registry() -> LoadRegistryStatus:
    return LoadRegistryStatus(
        registry_id="PHONE_LOAD_PENDING_V1",
        registry_sha256="0" * 64,
        test_only=False,
        evidence_status="NOT_VALIDATED",
        measure_name=None,
        unit=None,
        minimum=None,
        maximum=None,
        processing_version=None,
        measure_available=False,
    )


def _trial_artifact(
    trial: CalibrationTrialInput, manifest_sha256: str
) -> dict[str, object]:
    manifest = trial.manifest
    features = trial.features
    return {
        "trial_id": manifest.trial_id,
        "athlete_id": manifest.athlete_id,
        "sport": manifest.sport,
        "active_cue_id": manifest.active_cue_id,
        "assigned_condition_id": manifest.assigned_condition_id,
        "pair_id": manifest.pair_id,
        "block_index": manifest.block_index,
        "pair_member": manifest.pair_member,
        "within_pair_period": manifest.within_pair_period,
        "acquisition_state": features.acquisition_state,
        "task_fidelity_status": features.task_fidelity_status,
        "calibration_eligible": features.calibration_eligible,
        "ineligibility_reasons": list(features.ineligibility_reasons),
        "input_manifest_sha256": manifest_sha256,
        "trajectory_export_sha256": manifest.trajectory_export.sha256,
        "manifest_measure_registry_sha256": manifest.measure_registry_hash,
        "manifest_acquisition_registry_sha256": manifest.acquisition_qc_registry_hash,
    }


def _conversion_artifact(result: object) -> dict[str, object]:
    eligible = bool(getattr(result, "eligible"))
    reasons = list(getattr(result, "reasons"))
    batch = getattr(result, "batch")
    pairs = []
    if batch is not None:
        for pair in batch.pairs:
            difference = pair.difference
            pairs.append(
                {
                    "athlete_id": pair.athlete_id,
                    "sport": pair.sport,
                    "cue": pair.cue,
                    "block": pair.block,
                    "sequence_index": pair.sequence_index,
                    "cue_period": pair.cue_period,
                    "control_period": pair.control_period,
                    "cue_outcome": list(pair.cue_outcome),
                    "control_outcome": list(pair.control_outcome),
                    "difference": [float(difference[0]), float(difference[1])],
                }
            )
    return {
        "eligible": eligible,
        "reasons": reasons,
        "batch_created": batch is not None,
        "phase": None if batch is None else batch.phase,
        "pairs": pairs,
    }


def run_synthetic(
    input_directory: Path,
    output_directory: Path,
    *,
    include_synthetic_test_load: bool = False,
) -> Path:
    """Run a coherent, generated, synthetic-only Stage 1 example."""

    if not isinstance(input_directory, Path) or not isinstance(output_directory, Path):
        _fail("invalid_type", "run_paths")
    if not isinstance(include_synthetic_test_load, bool):
        _fail("invalid_type", "include_synthetic_test_load")
    if output_directory.exists() or output_directory.is_symlink():
        raise ProvenanceError("output_exists", "output_directory")
    if input_directory.is_symlink() or not input_directory.is_dir():
        _fail("input_directory_unavailable", "input_directory")
    ffmpeg = shutil.which("ffmpeg")
    ffprobe = shutil.which("ffprobe")
    if ffmpeg is None or ffprobe is None:
        _fail("media_tool_unavailable", "media_tool")

    base_path, base_payload = _read_fixture(input_directory, BASE_MANIFEST_NAME)
    del base_path
    if _sha256(base_payload) != BASE_MANIFEST_SHA256:
        _fail("base_manifest_hash_mismatch", "base_manifest")
    base_manifest = parse_trial_manifest(base_payload)
    try:
        base_mapping = json.loads(base_payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        _fail("invalid_base_manifest", "base_manifest")
    if not isinstance(base_mapping, dict):
        _fail("invalid_base_manifest", "base_manifest")

    trajectory_path, trajectory_payload = _read_fixture(
        input_directory, TRAJECTORY_NAME
    )
    acquisition_path, acquisition_payload = _read_fixture(
        input_directory, ACQUISITION_REGISTRY_NAME
    )
    measure_path, measure_payload = _read_fixture(
        input_directory, MEASURE_REGISTRY_NAME
    )
    acquisition_registry = load_synthetic_acquisition_registry(
        acquisition_path, base_manifest.acquisition_qc_registry_hash
    )
    measure_registry = load_synthetic_measure_registry(
        measure_path, base_manifest.measure_registry_hash
    )
    load_registry = _unavailable_load_registry()
    load_payload: bytes | None = None
    if include_synthetic_test_load:
        load_path, load_payload = _read_fixture(input_directory, LOAD_REGISTRY_NAME)
        load_registry = load_synthetic_test_load_registry(
            load_path, _sha256(load_payload)
        )

    input_hashes = [
        _sha256(base_payload),
        _sha256(trajectory_payload),
        _sha256(acquisition_payload),
        _sha256(measure_payload),
        GENERATED_VIDEO_HASH,
        GENERATED_VIDEO_HASH,
    ]
    if load_payload is not None:
        input_hashes.append(_sha256(load_payload))

    trials: list[CalibrationTrialInput] = []
    all_events: list[tuple[str, EventEstimate]] = []
    all_measurements: list[MeasurementRecord] = []
    trajectory_rows: list[tuple[object, ...]] = []
    warnings: set[str] = {"generated_synthetic_black_video"}
    failure_codes: set[str] = set()
    manifest_hashes: dict[str, str] = {}
    ffprobe_versions: set[str] = set()
    provider_versions: set[str] = set()
    with tempfile.TemporaryDirectory(prefix="causalmove-synthetic-stage1-") as directory:
        controlled_root = Path(directory)
        video_directory = controlled_root / "videos"
        trajectory_directory = controlled_root / "trajectory"
        manifest_directory = controlled_root / "manifests"
        video_directory.mkdir()
        trajectory_directory.mkdir()
        manifest_directory.mkdir()
        for name in ("front.mp4", "side.mp4"):
            _generate_video(video_directory / name, Path(ffmpeg))
        controlled_trajectory = trajectory_directory / TRAJECTORY_NAME
        controlled_trajectory.write_bytes(trajectory_payload)

        for spec in _trial_specs():
            manifest_payload = _manifest_bytes(base_mapping, spec)
            input_hashes.append(_sha256(manifest_payload))
            manifest_path = manifest_directory / (
                f"trial-{spec['block']}-{spec['member']}.json"
            )
            manifest_path.write_bytes(manifest_payload)
            verified = load_and_verify_trial_manifest(manifest_path, controlled_root)
            manifest_hashes[verified.manifest.trial_id] = verified.manifest_sha256
            acquisition = evaluate_acquisition(
                verified.files.views,
                AcquisitionContext(
                    sync_offset_s=0.001,
                    drift_ppm=5.0,
                    reprojection_error_px=0.4,
                ),
                acquisition_registry,
                ffprobe_executable=Path(ffprobe),
            )
            failure_codes.update(acquisition.failure_codes)
            ffprobe_versions.update(
                metadata.ffprobe_version for metadata in acquisition.video_metadata
            )
            trajectory = SyntheticTrajectoryAdapter().normalize(
                verified.files.trajectory_export, verified.manifest
            )
            provider_versions.add(
                f"{trajectory.sidecar.provider_id}:{trajectory.sidecar.provider_version}"
            )
            warnings.update(trajectory.sidecar.warnings)
            score = float(spec["score"])
            events = extract_synthetic_events(
                _event_annotations(score),
                (verified.files.trajectory_export.sha256,),
                measure_registry.event_registry,
            )
            latest_event = max(event.timestamp_s for event in events)
            latest_trajectory = max(record.timestamp_s for record in trajectory.records)
            minimum_video_duration = min(
                metadata.duration_s for metadata in acquisition.video_metadata
            )
            if latest_event > latest_trajectory or latest_event > minimum_video_duration:
                _fail("event_outside_observation_window", "synthetic_timeline")
            measurements = build_synthetic_measurements(
                trial_id=verified.manifest.trial_id,
                events=events,
                candidate_values={},
                source_hashes=(verified.files.trajectory_export.sha256,),
                registry=measure_registry,
            )
            features = build_trial_feature_bundle(
                trial_id=verified.manifest.trial_id,
                acquisition=acquisition,
                measure_registry=measure_registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=False,
                safety_reason_code=None,
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=measurements,
            )
            load_record = None
            if include_synthetic_test_load:
                load_record = build_synthetic_test_load_record(
                    trial_id=verified.manifest.trial_id,
                    value=float(spec["load"]),
                    uncertainty=0.001,
                    source_hashes=(verified.files.trajectory_export.sha256,),
                    registry=load_registry,
                )
            trials.append(
                CalibrationTrialInput(
                    manifest=verified.manifest,
                    features=features,
                    synthetic_test_load=load_record,
                )
            )
            all_events.extend(
                (verified.manifest.trial_id, event) for event in events
            )
            all_measurements.extend(measurements)
            for record in trajectory.records:
                trajectory_rows.append(
                    (
                        record.trial_id,
                        record.frame_index,
                        record.timestamp_s,
                        record.landmark_name,
                        record.anatomical_side,
                        record.x,
                        record.y,
                        record.z,
                        record.unit,
                        record.confidence,
                        record.coordinate_frame_id,
                        record.source_export_sha256,
                        record.adapter_version,
                        record.missing_reason,
                    )
                )

    conversion = convert_to_trial_batch(tuple(trials), load_registry)
    conversion_mapping = _conversion_artifact(conversion)
    measurement_header = tuple(MeasurementRecord.__dataclass_fields__)
    measurement_rows = [
        tuple(
            "|".join(value) if isinstance(value, tuple) else value
            for value in (getattr(record, field) for field in measurement_header)
        )
        for record in sorted(
            all_measurements, key=lambda item: (item.trial_id, item.measurement_id)
        )
    ]
    artifacts = {
        "conversion.json": canonical_json_bytes(conversion_mapping),
        "events.json": canonical_json_bytes(
            [
                {"trial_id": trial_id, **asdict(event)}
                for trial_id, event in sorted(
                    all_events,
                    key=lambda item: (
                        item[0],
                        item[1].timestamp_s,
                        item[1].event_id,
                    ),
                )
            ]
        ),
        "measurements.tsv": canonical_tsv_bytes(
            measurement_header, measurement_rows
        ),
        "trajectories.tsv": canonical_tsv_bytes(
            (
                "trial_id",
                "frame_index",
                "timestamp_s",
                "landmark_name",
                "anatomical_side",
                "x",
                "y",
                "z",
                "unit",
                "confidence",
                "coordinate_frame_id",
                "source_export_sha256",
                "adapter_version",
                "missing_reason",
            ),
            sorted(trajectory_rows, key=lambda row: (str(row[0]), int(row[1]), str(row[3]))),
        ),
        "trials.json": canonical_json_bytes(
            [
                _trial_artifact(
                    trial, manifest_hashes[trial.manifest.trial_id]
                )
                for trial in sorted(trials, key=lambda item: item.manifest.trial_id)
            ]
        ),
    }
    registry_hashes = {
        acquisition_registry.registry_sha256,
        measure_registry.registry_sha256,
    }
    if include_synthetic_test_load:
        registry_hashes.add(load_registry.registry_sha256)
    if len(ffprobe_versions) != 1:
        _fail("ffprobe_version_inconsistent", "execution_environment")
    ffprobe_version = next(iter(ffprobe_versions))
    provenance = EvidenceProvenance(
        input_sha256s=tuple(input_hashes),
        provider_versions=tuple(provider_versions),
        adapter_versions=("synthetic-adapter-v1",),
        event_versions=(measure_registry.event_registry.method_version,),
        feature_versions=(measure_registry.feature_version,),
        registry_sha256s=tuple(registry_hashes),
        source_tree_sha256=_source_tree_sha256(),
        execution_environment=(
            f"python-{platform.python_version()};{ffprobe_version}"
        ),
        warnings=tuple(warnings),
        failure_codes=tuple(failure_codes),
        conversion_reasons=conversion.reasons,
        trial_count=len(trials),
        batch_created=conversion.batch is not None,
    )
    return write_evidence_bundle(output_directory, artifacts, provenance)


def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run the CausalMove synthetic-only Stage 1 evidence pipeline."
    )
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--include-synthetic-test-load", action="store_true")
    args = parser.parse_args(argv)
    controlled_errors = (
        AcquisitionValidationError,
        EventValidationError,
        FeatureValidationError,
        ManifestValidationError,
        ProvenanceError,
        SyntheticRunError,
        TrajectoryValidationError,
        TrialBatchValidationError,
    )
    try:
        output = run_synthetic(
            args.input,
            args.output,
            include_synthetic_test_load=args.include_synthetic_test_load,
        )
    except controlled_errors as error:
        sys.stderr.buffer.write(
            canonical_json_bytes({"ok": False, "error_code": error.code})
        )
        return 2
    sys.stdout.buffer.write(
        canonical_json_bytes(
            {"ok": True, "evidence_status": "SYNTHETIC_SOFTWARE_ONLY"}
        )
    )
    del output
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
