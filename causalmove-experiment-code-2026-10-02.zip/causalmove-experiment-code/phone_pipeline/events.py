"""Event interfaces exercised only by explicit synthetic annotations."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Mapping, NoReturn

from .errors import EventValidationError


SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")


def _fail(code: str, field: str) -> NoReturn:
    raise EventValidationError(code, field)


def _finite_number(value: object, field: str, *, minimum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < minimum:
        _fail("invalid_number", field)
    return parsed


@dataclass(frozen=True)
class EventRegistry:
    required_events: tuple[str, ...]
    method_version: str
    uncertainty_assumption: str
    test_only: bool

    def __post_init__(self) -> None:
        if (
            not self.required_events
            or any(not isinstance(item, str) or not item for item in self.required_events)
            or len(set(self.required_events)) != len(self.required_events)
        ):
            _fail("invalid_event_registry", "event_registry.required_events")
        if not isinstance(self.method_version, str) or not self.method_version:
            _fail("invalid_event_registry", "event_registry.method_version")
        if self.uncertainty_assumption != "independent_endpoints":
            _fail("invalid_event_registry", "event_registry.uncertainty_assumption")
        if not isinstance(self.test_only, bool):
            _fail("invalid_event_registry", "event_registry.test_only")


@dataclass(frozen=True)
class EventEstimate:
    event_id: str
    timestamp_s: float
    uncertainty_s: float
    method_version: str
    source_hashes: tuple[str, ...]
    qc_status: str


def extract_synthetic_events(
    annotations: Mapping[str, tuple[float, float]],
    source_hashes: tuple[str, ...],
    registry: EventRegistry,
) -> tuple[EventEstimate, ...]:
    """Validate annotations; this function does not infer events from video."""

    if not isinstance(registry, EventRegistry):
        _fail("invalid_type", "event_registry")
    if not registry.test_only:
        _fail("real_event_detector_not_authorized", "event_registry")
    if not isinstance(annotations, Mapping):
        _fail("invalid_type", "event_annotations")
    annotation_keys = set(annotations)
    required_keys = set(registry.required_events)
    if annotation_keys - required_keys:
        _fail("unknown_event", "event_annotations")
    if required_keys - annotation_keys:
        _fail("missing_event", "event_annotations")
    if (
        not isinstance(source_hashes, tuple)
        or not source_hashes
        or any(
            not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None
            for value in source_hashes
        )
    ):
        _fail("invalid_source_hash", "event_source_hashes")

    events: list[EventEstimate] = []
    for event_id in registry.required_events:
        annotation = annotations[event_id]
        if not isinstance(annotation, tuple) or len(annotation) != 2:
            _fail("invalid_annotation", "event_annotations")
        timestamp_s = _finite_number(
            annotation[0], "event_annotations.timestamp_s", minimum=0.0
        )
        uncertainty_s = _finite_number(
            annotation[1], "event_annotations.uncertainty_s", minimum=0.0
        )
        events.append(
            EventEstimate(
                event_id=event_id,
                timestamp_s=timestamp_s,
                uncertainty_s=uncertainty_s,
                method_version=registry.method_version,
                source_hashes=source_hashes,
                qc_status="synthetic_annotation_only",
            )
        )
    if any(
        later.timestamp_s <= earlier.timestamp_s
        for earlier, later in zip(events, events[1:])
    ):
        _fail("event_order", "event_annotations")
    return tuple(events)


def completion_time_from_events(
    events: tuple[EventEstimate, ...], registry: EventRegistry
) -> tuple[float, float]:
    """Return initial-contact-to-exit duration and independent-endpoint SD."""

    if not isinstance(registry, EventRegistry) or not registry.test_only:
        _fail("real_event_detector_not_authorized", "event_registry")
    if not isinstance(events, tuple) or not events or any(
        not isinstance(event, EventEstimate) for event in events
    ):
        _fail("invalid_type", "events")
    expected_sources: tuple[str, ...] | None = None
    for event in events:
        _finite_number(event.timestamp_s, "events.timestamp_s", minimum=0.0)
        _finite_number(event.uncertainty_s, "events.uncertainty_s", minimum=0.0)
        if event.method_version != registry.method_version:
            _fail("event_method_mismatch", "events.method_version")
        if event.qc_status != "synthetic_annotation_only":
            _fail("event_qc_mismatch", "events.qc_status")
        if (
            not isinstance(event.source_hashes, tuple)
            or not event.source_hashes
            or any(
                not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None
                for value in event.source_hashes
            )
        ):
            _fail("invalid_source_hash", "events.source_hashes")
        if expected_sources is None:
            expected_sources = event.source_hashes
        elif event.source_hashes != expected_sources:
            _fail("event_source_mismatch", "events.source_hashes")
    event_map = {event.event_id: event for event in events}
    if set(event_map) != set(registry.required_events) or len(event_map) != len(events):
        _fail("event_set_mismatch", "events")
    ordered_events = tuple(event_map[event_id] for event_id in registry.required_events)
    if any(
        later.timestamp_s <= earlier.timestamp_s
        for earlier, later in zip(ordered_events, ordered_events[1:])
    ):
        _fail("event_order", "events")
    initial_contact = event_map["initial_contact"]
    exit_event = event_map["exit"]
    duration = exit_event.timestamp_s - initial_contact.timestamp_s
    if duration <= 0.0:
        _fail("event_order", "events")
    uncertainty = math.sqrt(
        initial_contact.uncertainty_s**2 + exit_event.uncertainty_s**2
    )
    return duration, uncertainty
