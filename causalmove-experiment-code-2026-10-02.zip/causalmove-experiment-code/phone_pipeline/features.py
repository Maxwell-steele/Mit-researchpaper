"""Registry-driven synthetic features with provenance and no imputation."""

from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, NoReturn

from .acquisition import AcquisitionResult
from .errors import FeatureValidationError
from .events import EventEstimate, EventRegistry, completion_time_from_events


REGISTRY_SCHEMA_VERSION = "causalmove-synthetic-measure-registry-v1"
APPROVED_SYNTHETIC_MEASURE_REGISTRY_SHA256 = (
    "71cc2acf0fc834bd1786af9e774cf38a118da5ec56776a741e7b602f8ca6dff3"
)
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
REQUIRED_EVENTS = (
    "approach",
    "penultimate_contact",
    "initial_contact",
    "weight_acceptance",
    "toe_off",
    "exit",
)
REGISTERED_MEASURES = frozenset(
    {
        "achieved_cut_angle",
        "cut_completion_time",
        "entry_speed",
        "exit_speed",
        "foot_exit_alignment_error_at_initial_contact",
        "foot_progression_angle_at_initial_contact",
        "path_error",
        "penultimate_deceleration_share",
        "plant_contact_time",
        "plant_lateral_offset_normalized",
        "task_performance_score",
        "trunk_lean_toward_exit_at_initial_contact",
    }
)
DERIVED_EVENT_MEASURES = frozenset(
    {"cut_completion_time", "task_performance_score"}
)
REGISTRY_FIELDS = frozenset(
    {
        "schema_version",
        "registry_id",
        "test_only",
        "event_method_version",
        "feature_version",
        "required_events",
        "uncertainty_assumption",
        "measures",
    }
)
MEASURE_FIELDS = frozenset({"unit", "minimum", "maximum", "analysis_role"})
ANATOMICAL_SIDES = frozenset(
    {"left", "right", "midline", "not_applicable", "side_normalized"}
)
TASK_FIDELITY_STATUSES = frozenset(
    {
        "pass",
        "speed_deviation",
        "path_deviation",
        "angle_deviation",
        "wrong_execution",
        "not_assessable",
    }
)
SAFETY_REASON_CODES = frozenset(
    {
        "adverse_event",
        "medical_stop",
        "operator_safety_stop",
        "participant_safety_stop",
        "registered_stopping_rule",
    }
)
PRIMARY_MISSINGNESS_TREATMENTS = frozenset(
    {"preserve_missing_no_imputation_v1"}
)


class _DuplicateFieldError(ValueError):
    pass


def _fail(code: str, field: str) -> NoReturn:
    raise FeatureValidationError(code, field)


def _reject_duplicate_fields(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateFieldError
        result[key] = value
    return result


def _mapping(value: object, field: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        _fail("invalid_type", field)
    return value


def _string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("invalid_string", field)
    return value


def _number(value: object, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed):
        _fail("invalid_number", field)
    return parsed


def _record_hash(values: Mapping[str, object]) -> str:
    payload = json.dumps(
        values,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class MeasureSpec:
    measure_name: str
    unit: str
    minimum: float
    maximum: float
    analysis_role: str


@dataclass(frozen=True)
class SyntheticMeasureRegistry:
    schema_version: str
    registry_id: str
    registry_sha256: str
    test_only: bool
    event_registry: EventRegistry
    feature_version: str
    measures: Mapping[str, MeasureSpec]


@dataclass(frozen=True)
class SyntheticFeatureInput:
    value: float
    uncertainty: float
    unit: str
    anatomical_side: str
    event_window: str


@dataclass(frozen=True)
class MeasurementRecord:
    measurement_id: str
    trial_id: str
    measure_name: str
    value: float | None
    unit: str
    anatomical_side: str
    event_window: str
    uncertainty: float | None
    source_hashes: tuple[str, ...]
    processing_version: str
    measurement_valid: bool
    missing_reason: str | None
    missingness_class: str | None
    intended_analysis_role: str
    transform_id: str | None
    original_measurement_id: str | None
    original_measurement_hash: str | None
    original_value: float | None
    original_unit: str | None
    original_anatomical_side: str | None
    record_hash: str


@dataclass(frozen=True)
class TrialFeatureBundle:
    trial_id: str
    acquisition_state: str
    acquisition_failure_codes: tuple[str, ...]
    acquisition_registry_id: str
    acquisition_registry_sha256: str
    measure_registry_id: str
    measure_registry_sha256: str
    feature_version: str
    task_fidelity_status: str
    task_fidelity_rule_ids: tuple[str, ...]
    safety_related_missingness: bool
    safety_reason_code: str | None
    primary_missingness_treatment: str
    measurements: tuple[MeasurementRecord, ...]
    calibration_eligible: bool
    ineligibility_reasons: tuple[str, ...]


def load_synthetic_measure_registry(
    path: Path, expected_sha256: str
) -> SyntheticMeasureRegistry:
    """Load one exact test-only registry and bind it to its bytes."""

    if not isinstance(path, Path) or not isinstance(expected_sha256, str):
        _fail("invalid_type", "measure_registry")
    if SHA256_PATTERN.fullmatch(expected_sha256) is None:
        _fail("invalid_sha256", "measure_registry.sha256")
    try:
        payload = path.read_bytes()
    except OSError:
        _fail("registry_read_error", "measure_registry")
    digest = hashlib.sha256(payload).hexdigest()
    if digest != expected_sha256:
        _fail("registry_hash_mismatch", "measure_registry")
    try:
        raw = json.loads(
            payload.decode("utf-8"), object_pairs_hook=_reject_duplicate_fields
        )
    except _DuplicateFieldError:
        _fail("duplicate_field", "measure_registry")
    except (UnicodeDecodeError, json.JSONDecodeError):
        _fail("invalid_json", "measure_registry")
    mapping = _mapping(raw, "measure_registry")
    if set(mapping) - REGISTRY_FIELDS:
        _fail("unknown_field", "measure_registry")
    if REGISTRY_FIELDS - set(mapping):
        _fail("missing_field", "measure_registry")
    if digest != APPROVED_SYNTHETIC_MEASURE_REGISTRY_SHA256:
        _fail("unapproved_registry_digest", "measure_registry")
    schema_version = _string(mapping["schema_version"], "measure_registry.schema")
    if schema_version != REGISTRY_SCHEMA_VERSION:
        _fail("unsupported_schema", "measure_registry.schema")
    if mapping["test_only"] is not True:
        _fail("real_measure_registry_not_authorized", "measure_registry")
    required_events_raw = mapping["required_events"]
    if not isinstance(required_events_raw, list) or tuple(required_events_raw) != (
        REQUIRED_EVENTS
    ):
        _fail("event_registry_mismatch", "measure_registry.required_events")
    uncertainty_assumption = _string(
        mapping["uncertainty_assumption"],
        "measure_registry.uncertainty_assumption",
    )
    event_method_version = _string(
        mapping["event_method_version"], "measure_registry.event_method_version"
    )
    measures_raw = _mapping(mapping["measures"], "measure_registry.measures")
    if set(measures_raw) != REGISTERED_MEASURES:
        _fail("measure_set_mismatch", "measure_registry.measures")

    measures: dict[str, MeasureSpec] = {}
    for measure_name, raw_spec in measures_raw.items():
        spec = _mapping(raw_spec, "measure_registry.measures")
        if set(spec) - MEASURE_FIELDS:
            _fail("unknown_field", "measure_registry.measures")
        if MEASURE_FIELDS - set(spec):
            _fail("missing_field", "measure_registry.measures")
        minimum = _number(spec["minimum"], "measure_registry.measures.minimum")
        maximum = _number(spec["maximum"], "measure_registry.measures.maximum")
        if maximum < minimum:
            _fail("invalid_range", "measure_registry.measures")
        measures[measure_name] = MeasureSpec(
            measure_name=measure_name,
            unit=_string(spec["unit"], "measure_registry.measures.unit"),
            minimum=minimum,
            maximum=maximum,
            analysis_role=_string(
                spec["analysis_role"], "measure_registry.measures.analysis_role"
            ),
        )
    return SyntheticMeasureRegistry(
        schema_version=schema_version,
        registry_id=_string(mapping["registry_id"], "measure_registry.registry_id"),
        registry_sha256=digest,
        test_only=True,
        event_registry=EventRegistry(
            required_events=REQUIRED_EVENTS,
            method_version=event_method_version,
            uncertainty_assumption=uncertainty_assumption,
            test_only=True,
        ),
        feature_version=_string(
            mapping["feature_version"], "measure_registry.feature_version"
        ),
        measures=MappingProxyType(measures),
    )


def _measurement(
    *,
    trial_id: str,
    measure_name: str,
    raw_value: float,
    uncertainty: float,
    unit: str,
    anatomical_side: str,
    event_window: str,
    source_hashes: tuple[str, ...],
    registry: SyntheticMeasureRegistry,
) -> MeasurementRecord:
    spec = registry.measures[measure_name]
    valid = spec.minimum <= raw_value <= spec.maximum
    value = raw_value if valid else None
    saved_uncertainty = uncertainty if valid else None
    base: dict[str, object] = {
        "measurement_id": f"{trial_id}:{measure_name}:original",
        "trial_id": trial_id,
        "measure_name": measure_name,
        "value": value,
        "unit": unit,
        "anatomical_side": anatomical_side,
        "event_window": event_window,
        "uncertainty": saved_uncertainty,
        "source_hashes": source_hashes,
        "processing_version": registry.feature_version,
        "measurement_valid": valid,
        "missing_reason": None if valid else "outside_valid_range",
        "missingness_class": None if valid else "derived_invalid",
        "intended_analysis_role": spec.analysis_role,
        "transform_id": None,
        "original_measurement_id": None,
        "original_measurement_hash": None,
        "original_value": None,
        "original_unit": None,
        "original_anatomical_side": None,
    }
    return MeasurementRecord(**base, record_hash=_record_hash(base))


def build_synthetic_measurements(
    *,
    trial_id: str,
    events: tuple[EventEstimate, ...],
    candidate_values: Mapping[str, SyntheticFeatureInput],
    source_hashes: tuple[str, ...],
    registry: SyntheticMeasureRegistry,
) -> tuple[MeasurementRecord, ...]:
    """Build only registered synthetic measurements and never a load estimate."""

    if not isinstance(registry, SyntheticMeasureRegistry) or not registry.test_only:
        _fail("real_measure_registry_not_authorized", "measure_registry")
    _string(trial_id, "trial_id")
    if (
        not isinstance(source_hashes, tuple)
        or not source_hashes
        or any(
            not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None
            for value in source_hashes
        )
    ):
        _fail("invalid_source_hash", "source_hashes")
    if not isinstance(candidate_values, Mapping):
        _fail("invalid_type", "candidate_values")
    unknown = set(candidate_values) - set(registry.measures)
    if unknown:
        _fail("unregistered_measure", "candidate_values")
    if set(candidate_values) & DERIVED_EVENT_MEASURES:
        _fail("derived_measure_override", "candidate_values")

    duration, duration_uncertainty = completion_time_from_events(
        events, registry.event_registry
    )
    if events[0].source_hashes != source_hashes:
        _fail("event_source_mismatch", "source_hashes")
    measurements = [
        _measurement(
            trial_id=trial_id,
            measure_name="cut_completion_time",
            raw_value=duration,
            uncertainty=duration_uncertainty,
            unit="s",
            anatomical_side="not_applicable",
            event_window="initial_contact_to_exit",
            source_hashes=source_hashes,
            registry=registry,
        ),
        _measurement(
            trial_id=trial_id,
            measure_name="task_performance_score",
            raw_value=math.log(duration / 1.0),
            uncertainty=duration_uncertainty / duration,
            unit="1",
            anatomical_side="not_applicable",
            event_window="initial_contact_to_exit",
            source_hashes=source_hashes,
            registry=registry,
        ),
    ]
    for measure_name in sorted(candidate_values):
        candidate = candidate_values[measure_name]
        if not isinstance(candidate, SyntheticFeatureInput):
            _fail("invalid_type", "candidate_values")
        spec = registry.measures[measure_name]
        if candidate.unit != spec.unit:
            _fail("unit_mismatch", "candidate_values")
        value = _number(candidate.value, "candidate_values.value")
        uncertainty = _number(
            candidate.uncertainty, "candidate_values.uncertainty"
        )
        if uncertainty < 0.0:
            _fail("invalid_uncertainty", "candidate_values.uncertainty")
        if candidate.anatomical_side not in ANATOMICAL_SIDES:
            _fail("invalid_anatomical_side", "candidate_values.anatomical_side")
        event_window = _string(candidate.event_window, "candidate_values.event_window")
        measurements.append(
            _measurement(
                trial_id=trial_id,
                measure_name=measure_name,
                raw_value=value,
                uncertainty=uncertainty,
                unit=candidate.unit,
                anatomical_side=candidate.anatomical_side,
                event_window=event_window,
                source_hashes=source_hashes,
                registry=registry,
            )
        )
    return tuple(measurements)


def derive_side_normalized(
    original: MeasurementRecord, transform_id: str
) -> MeasurementRecord:
    """Create a reflected derivative while preserving the immutable original."""

    if not isinstance(original, MeasurementRecord) or not original.measurement_valid:
        _fail("invalid_source_measurement", "measurement")
    if original.value is None or original.anatomical_side not in {"left", "right"}:
        _fail("side_normalization_unavailable", "measurement")
    transform = _string(transform_id, "transform_id")
    normalized_value = -original.value if original.anatomical_side == "left" else original.value
    base: dict[str, object] = {
        "measurement_id": f"{original.measurement_id}:{transform}",
        "trial_id": original.trial_id,
        "measure_name": original.measure_name,
        "value": normalized_value,
        "unit": original.unit,
        "anatomical_side": "side_normalized",
        "event_window": original.event_window,
        "uncertainty": original.uncertainty,
        "source_hashes": original.source_hashes,
        "processing_version": original.processing_version,
        "measurement_valid": True,
        "missing_reason": None,
        "missingness_class": None,
        "intended_analysis_role": original.intended_analysis_role,
        "transform_id": transform,
        "original_measurement_id": original.measurement_id,
        "original_measurement_hash": original.record_hash,
        "original_value": original.value,
        "original_unit": original.unit,
        "original_anatomical_side": original.anatomical_side,
    }
    return MeasurementRecord(**base, record_hash=_record_hash(base))


def _measurement_payload(record: MeasurementRecord) -> dict[str, object]:
    return {
        field_name: getattr(record, field_name)
        for field_name in MeasurementRecord.__dataclass_fields__
        if field_name != "record_hash"
    }


def _validate_bundle_measurements(
    trial_id: str, measurements: tuple[MeasurementRecord, ...]
) -> None:
    if not isinstance(measurements, tuple) or any(
        not isinstance(value, MeasurementRecord) for value in measurements
    ):
        _fail("invalid_type", "measurements")

    identifiers: dict[str, MeasurementRecord] = {}
    expected_sources: tuple[str, ...] | None = None
    expected_processing_version: str | None = None
    for record in measurements:
        if record.trial_id != trial_id:
            _fail("measurement_trial_mismatch", "measurements.trial_id")
        if not isinstance(record.measurement_id, str) or not record.measurement_id:
            _fail("invalid_measurement_id", "measurements.measurement_id")
        if record.measurement_id in identifiers:
            _fail("duplicate_measurement_id", "measurements.measurement_id")
        identifiers[record.measurement_id] = record
        if (
            not isinstance(record.record_hash, str)
            or SHA256_PATTERN.fullmatch(record.record_hash) is None
            or record.record_hash != _record_hash(_measurement_payload(record))
        ):
            _fail("measurement_hash_mismatch", "measurements.record_hash")
        if (
            not isinstance(record.source_hashes, tuple)
            or not record.source_hashes
            or any(
                not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None
                for value in record.source_hashes
            )
        ):
            _fail("invalid_source_hash", "measurements.source_hashes")
        if expected_sources is None:
            expected_sources = record.source_hashes
        elif record.source_hashes != expected_sources:
            _fail("measurement_source_mismatch", "measurements.source_hashes")
        if not isinstance(record.processing_version, str) or not record.processing_version:
            _fail("invalid_processing_version", "measurements.processing_version")
        if expected_processing_version is None:
            expected_processing_version = record.processing_version
        elif record.processing_version != expected_processing_version:
            _fail(
                "measurement_processing_mismatch",
                "measurements.processing_version",
            )

    for record in measurements:
        if record.transform_id is None:
            if any(
                value is not None
                for value in (
                    record.original_measurement_id,
                    record.original_measurement_hash,
                    record.original_value,
                    record.original_unit,
                    record.original_anatomical_side,
                )
            ):
                _fail("invalid_original_link", "measurements.original")
            continue
        original = identifiers.get(record.original_measurement_id or "")
        if (
            original is None
            or record.original_measurement_hash != original.record_hash
            or record.original_value != original.value
            or record.original_unit != original.unit
            or record.original_anatomical_side != original.anatomical_side
        ):
            _fail("invalid_original_link", "measurements.original")


def validate_trial_feature_bundle_integrity(bundle: TrialFeatureBundle) -> None:
    """Revalidate a bundle before it crosses into another subsystem."""

    if not isinstance(bundle, TrialFeatureBundle):
        _fail("invalid_type", "feature_bundle")
    _string(bundle.trial_id, "feature_bundle.trial_id")
    for field, value in (
        ("acquisition_registry_id", bundle.acquisition_registry_id),
        ("measure_registry_id", bundle.measure_registry_id),
        ("feature_version", bundle.feature_version),
    ):
        _string(value, f"feature_bundle.{field}")
    for field, value in (
        ("acquisition_registry_sha256", bundle.acquisition_registry_sha256),
        ("measure_registry_sha256", bundle.measure_registry_sha256),
    ):
        if not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None:
            _fail("invalid_sha256", f"feature_bundle.{field}")
    if bundle.acquisition_state not in {
        "phone_technical_pass",
        "phone_technical_missing",
    }:
        _fail("invalid_acquisition_state", "feature_bundle.acquisition_state")
    if not isinstance(bundle.acquisition_failure_codes, tuple) or any(
        not isinstance(value, str) or not value
        for value in bundle.acquisition_failure_codes
    ):
        _fail("invalid_failure_codes", "feature_bundle.acquisition_failure_codes")
    if (
        bundle.acquisition_state == "phone_technical_pass"
        and bundle.acquisition_failure_codes
    ) or (
        bundle.acquisition_state == "phone_technical_missing"
        and not bundle.acquisition_failure_codes
    ):
        _fail("acquisition_state_mismatch", "feature_bundle.acquisition_state")
    if bundle.task_fidelity_status not in TASK_FIDELITY_STATUSES:
        _fail("invalid_task_fidelity_status", "feature_bundle.task_fidelity_status")
    if not isinstance(bundle.task_fidelity_rule_ids, tuple) or not (
        bundle.task_fidelity_rule_ids
    ) or any(
        not isinstance(value, str) or not value
        for value in bundle.task_fidelity_rule_ids
    ):
        _fail("invalid_rule_ids", "feature_bundle.task_fidelity_rule_ids")
    if not isinstance(bundle.safety_related_missingness, bool):
        _fail("invalid_type", "feature_bundle.safety_related_missingness")
    if bundle.safety_related_missingness:
        if bundle.safety_reason_code is None:
            _fail("missing_safety_reason", "feature_bundle.safety_reason_code")
        if bundle.safety_reason_code not in SAFETY_REASON_CODES:
            _fail("invalid_safety_reason", "feature_bundle.safety_reason_code")
    elif bundle.safety_reason_code is not None:
        _fail("unexpected_safety_reason", "feature_bundle.safety_reason_code")
    if bundle.primary_missingness_treatment not in PRIMARY_MISSINGNESS_TREATMENTS:
        _fail(
            "invalid_missingness_treatment",
            "feature_bundle.primary_missingness_treatment",
        )
    _validate_bundle_measurements(bundle.trial_id, bundle.measurements)
    if any(
        record.processing_version != bundle.feature_version
        for record in bundle.measurements
    ):
        _fail("measurement_processing_mismatch", "feature_bundle.feature_version")

    expected_reasons: set[str] = set()
    if bundle.acquisition_state != "phone_technical_pass":
        expected_reasons.add("technical_acquisition_missing")
    if bundle.task_fidelity_status != "pass":
        expected_reasons.add("task_fidelity_failure")
    if bundle.safety_related_missingness:
        expected_reasons.add("safety_related_missingness")
    primary = tuple(
        item
        for item in bundle.measurements
        if item.measure_name == "task_performance_score"
    )
    if len(primary) != 1 or not primary[0].measurement_valid:
        expected_reasons.add("performance_measure_unavailable")
    if bundle.ineligibility_reasons != tuple(sorted(expected_reasons)):
        _fail("ineligibility_reason_mismatch", "feature_bundle.ineligibility_reasons")
    if bundle.calibration_eligible != (not expected_reasons):
        _fail("eligibility_mismatch", "feature_bundle.calibration_eligible")


def build_trial_feature_bundle(
    *,
    trial_id: str,
    acquisition: AcquisitionResult,
    measure_registry: SyntheticMeasureRegistry,
    task_fidelity_status: str,
    task_fidelity_rule_ids: tuple[str, ...],
    safety_related_missingness: bool,
    safety_reason_code: str | None,
    primary_missingness_treatment: str,
    measurements: tuple[MeasurementRecord, ...],
) -> TrialFeatureBundle:
    """Keep technical, task-fidelity, and safety states separate and auditable."""

    _string(trial_id, "trial_id")
    if not isinstance(acquisition, AcquisitionResult):
        _fail("invalid_type", "acquisition")
    if (
        not isinstance(measure_registry, SyntheticMeasureRegistry)
        or not measure_registry.test_only
    ):
        _fail("real_measure_registry_not_authorized", "measure_registry")
    if task_fidelity_status not in TASK_FIDELITY_STATUSES:
        _fail("invalid_task_fidelity_status", "task_fidelity_status")
    if not isinstance(task_fidelity_rule_ids, tuple) or any(
        not isinstance(value, str) or not value for value in task_fidelity_rule_ids
    ):
        _fail("invalid_rule_ids", "task_fidelity_rule_ids")
    if not isinstance(safety_related_missingness, bool):
        _fail("invalid_type", "safety_related_missingness")
    if safety_related_missingness and safety_reason_code is None:
        _fail("missing_safety_reason", "safety_reason_code")
    if safety_related_missingness and safety_reason_code not in SAFETY_REASON_CODES:
        _fail("invalid_safety_reason", "safety_reason_code")
    if not safety_related_missingness and safety_reason_code is not None:
        _fail("unexpected_safety_reason", "safety_reason_code")
    if primary_missingness_treatment not in PRIMARY_MISSINGNESS_TREATMENTS:
        _fail(
            "invalid_missingness_treatment",
            "primary_missingness_treatment",
        )
    _validate_bundle_measurements(trial_id, measurements)

    reasons: set[str] = set()
    if not acquisition.calibration_eligible:
        reasons.add("technical_acquisition_missing")
    if task_fidelity_status != "pass":
        reasons.add("task_fidelity_failure")
    if safety_related_missingness:
        reasons.add("safety_related_missingness")
    primary = tuple(
        item for item in measurements if item.measure_name == "task_performance_score"
    )
    if len(primary) != 1 or not primary[0].measurement_valid:
        reasons.add("performance_measure_unavailable")
    ordered_reasons = tuple(sorted(reasons))
    bundle = TrialFeatureBundle(
        trial_id=trial_id,
        acquisition_state=acquisition.state,
        acquisition_failure_codes=acquisition.failure_codes,
        acquisition_registry_id=acquisition.acquisition_registry_id,
        acquisition_registry_sha256=acquisition.acquisition_registry_sha256,
        measure_registry_id=measure_registry.registry_id,
        measure_registry_sha256=measure_registry.registry_sha256,
        feature_version=measure_registry.feature_version,
        task_fidelity_status=task_fidelity_status,
        task_fidelity_rule_ids=task_fidelity_rule_ids,
        safety_related_missingness=safety_related_missingness,
        safety_reason_code=safety_reason_code,
        primary_missingness_treatment=primary_missingness_treatment,
        measurements=measurements,
        calibration_eligible=not ordered_reasons,
        ineligibility_reasons=ordered_reasons,
    )
    validate_trial_feature_bundle_integrity(bundle)
    return bundle
