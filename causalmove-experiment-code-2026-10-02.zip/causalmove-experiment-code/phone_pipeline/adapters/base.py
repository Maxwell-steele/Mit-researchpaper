"""Provider-neutral trajectory adapter protocol."""

from __future__ import annotations

from typing import Protocol

from ..manifest import TrialManifest, VerifiedFile
from ..trajectory import CanonicalTrajectory


class ProviderAdapter(Protocol):
    """Normalize a verified provider export into canonical trajectory records."""

    def normalize(
        self, source: VerifiedFile, manifest: TrialManifest
    ) -> CanonicalTrajectory: ...
