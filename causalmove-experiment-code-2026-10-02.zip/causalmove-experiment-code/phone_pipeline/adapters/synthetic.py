"""Test-only trajectory adapter; this is not a real provider format."""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping, NoReturn

from ..errors import TrajectoryValidationError
from ..manifest import TrialManifest, VerifiedFile
from ..trajectory import CanonicalTrajectory, NormalizationSidecar, TrajectoryRecord


ADAPTER_VERSION = "synthetic-adapter-v1"
SCHEMA_VERSION = "causalmove-synthetic-trajectory-v1"
TOP_LEVEL_FIELDS = frozenset(
    {
        "schema_version",
        "provider_id",
        "provider_version",
        "source_unit",
        "axis_transform",
        "landmark_map",
        "ignored_record_fields",
        "records",
    }
)
BASE_RECORD_FIELDS = frozenset(
    {
        "frame_index",
        "timestamp_ms",
        "landmark",
        "x_mm",
        "y_mm",
        "z_mm",
        "confidence",
        "missing_reason",
    }
)
REGISTERED_CANONICAL_LANDMARKS = frozenset({"left_ankle", "right_ankle"})


class _DuplicateFieldError(ValueError):
    pass


def _fail(code: str, field: str) -> NoReturn:
    raise TrajectoryValidationError(code, field)


def _reject_duplicate_fields(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateFieldError
        result[key] = value
    return result


def _mapping(value: object, field: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        _fail("invalid_type", field)
    return value


def _exact_fields(
    value: Mapping[str, object], expected: frozenset[str], field: str
) -> None:
    if set(value) - expected:
        _fail("unknown_field", field)
    if expected - set(value):
        _fail("missing_field", field)


def _string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("invalid_string", field)
    return value


def _number(value: object, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed):
        _fail("nonfinite_number", field)
    return parsed


def _optional_number(value: object, field: str) -> float | None:
    if value is None:
        return None
    return _number(value, field)


def _string_list(value: object, field: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        _fail("invalid_type", field)
    result = tuple(_string(item, field) for item in value)
    if len(set(result)) != len(result):
        _fail("duplicate_value", field)
    return result


def _anatomical_side(landmark: str) -> str:
    if landmark.startswith("left_"):
        return "left"
    if landmark.startswith("right_"):
        return "right"
    _fail("unsupported_landmark_side", "trajectory.landmark_map")


class SyntheticTrajectoryAdapter:
    """Normalize the one exact test schema without claiming provider support."""

    def normalize(
        self, source: VerifiedFile, manifest: TrialManifest
    ) -> CanonicalTrajectory:
        if not isinstance(source, VerifiedFile) or not isinstance(manifest, TrialManifest):
            _fail("invalid_type", "adapter.input")
        if source.relative_uri != manifest.trajectory_export.file_uri:
            _fail("source_manifest_mismatch", "trajectory_export")
        try:
            payload = source.resolved_path.read_bytes()
        except OSError:
            _fail("source_read_error", "trajectory_export")
        digest = hashlib.sha256(payload).hexdigest()
        if digest != source.sha256 or digest != manifest.trajectory_export.sha256:
            _fail("source_hash_mismatch", "trajectory_export")
        if len(payload) != source.size_bytes:
            _fail("source_size_mismatch", "trajectory_export")
        try:
            raw = json.loads(
                payload.decode("utf-8"), object_pairs_hook=_reject_duplicate_fields
            )
        except _DuplicateFieldError:
            _fail("duplicate_field", "trajectory_export")
        except (UnicodeDecodeError, json.JSONDecodeError):
            _fail("invalid_json", "trajectory_export")

        mapping = _mapping(raw, "trajectory_export")
        _exact_fields(mapping, TOP_LEVEL_FIELDS, "trajectory_export")
        schema_version = _string(mapping["schema_version"], "trajectory_export.schema")
        if schema_version != SCHEMA_VERSION:
            _fail("unsupported_schema", "trajectory_export.schema")
        provider_id = _string(mapping["provider_id"], "trajectory_export.provider_id")
        provider_version = _string(
            mapping["provider_version"], "trajectory_export.provider_version"
        )
        if provider_id != "synthetic_fixture":
            _fail("unsupported_provider", "trajectory_export.provider_id")
        if provider_version != "synthetic-v1":
            _fail("unsupported_provider_version", "trajectory_export.provider_version")
        if provider_id != manifest.trajectory_export.provider_id or provider_version != (
            manifest.trajectory_export.provider_version
        ):
            _fail("provider_manifest_mismatch", "trajectory_export")
        if mapping["source_unit"] != "mm":
            _fail("unsupported_unit", "trajectory_export.source_unit")
        axis_transform = _string_list(
            mapping["axis_transform"], "trajectory_export.axis_transform"
        )
        if axis_transform != ("+x", "+z", "-y"):
            _fail("unsupported_axis_transform", "trajectory_export.axis_transform")

        landmark_map_raw = _mapping(
            mapping["landmark_map"], "trajectory_export.landmark_map"
        )
        if not landmark_map_raw:
            _fail("empty_landmark_map", "trajectory_export.landmark_map")
        landmark_map: dict[str, str] = {}
        for source_name, canonical_value in landmark_map_raw.items():
            source_landmark = _string(source_name, "trajectory_export.landmark_map")
            canonical_landmark = _string(
                canonical_value, "trajectory_export.landmark_map"
            )
            if canonical_landmark not in REGISTERED_CANONICAL_LANDMARKS:
                _fail("unregistered_landmark", "trajectory_export.landmark_map")
            landmark_map[source_landmark] = canonical_landmark
        if len(set(landmark_map.values())) != len(landmark_map):
            _fail("duplicate_landmark_mapping", "trajectory_export.landmark_map")

        ignored_fields = _string_list(
            mapping["ignored_record_fields"],
            "trajectory_export.ignored_record_fields",
        )
        if set(ignored_fields) & BASE_RECORD_FIELDS:
            _fail("reserved_ignored_field", "trajectory_export.ignored_record_fields")
        record_fields = BASE_RECORD_FIELDS | set(ignored_fields)
        raw_records = mapping["records"]
        if not isinstance(raw_records, list) or not raw_records:
            _fail("empty_trajectory", "trajectory_export.records")

        records: list[TrajectoryRecord] = []
        for index, raw_record in enumerate(raw_records):
            field = f"trajectory_export.records[{index}]"
            item = _mapping(raw_record, field)
            _exact_fields(item, frozenset(record_fields), field)
            source_landmark = _string(item["landmark"], f"{field}.landmark")
            if source_landmark not in landmark_map:
                _fail("unknown_landmark", f"{field}.landmark")
            frame_index = item["frame_index"]
            if isinstance(frame_index, bool) or not isinstance(frame_index, int):
                _fail("invalid_frame_index", f"{field}.frame_index")
            timestamp_s = _number(item["timestamp_ms"], f"{field}.timestamp_ms") * 0.001
            source_coordinates = (
                _optional_number(item["x_mm"], f"{field}.x_mm"),
                _optional_number(item["y_mm"], f"{field}.y_mm"),
                _optional_number(item["z_mm"], f"{field}.z_mm"),
            )
            if all(value is None for value in source_coordinates):
                x = y = z = None
            elif any(value is None for value in source_coordinates):
                _fail("partial_coordinates", f"{field}.coordinates")
            else:
                source_x, source_y, source_z = source_coordinates
                assert source_x is not None and source_y is not None and source_z is not None
                x = source_x * 0.001
                y = source_z * 0.001
                z = -source_y * 0.001
            confidence = _optional_number(item["confidence"], f"{field}.confidence")
            missing_reason_value = item["missing_reason"]
            missing_reason = (
                None
                if missing_reason_value is None
                else _string(missing_reason_value, f"{field}.missing_reason")
            )
            canonical_landmark = landmark_map[source_landmark]
            records.append(
                TrajectoryRecord(
                    trial_id=manifest.trial_id,
                    frame_index=frame_index,
                    timestamp_s=timestamp_s,
                    landmark_name=canonical_landmark,
                    anatomical_side=_anatomical_side(canonical_landmark),
                    x=x,
                    y=y,
                    z=z,
                    unit="m",
                    confidence=confidence,
                    coordinate_frame_id=manifest.trajectory_export.coordinate_frame_id,
                    source_export_sha256=digest,
                    adapter_version=ADAPTER_VERSION,
                    missing_reason=missing_reason,
                )
            )

        records.sort(key=lambda record: (record.frame_index, record.landmark_name))
        sorted_mapping = tuple(sorted(landmark_map.items()))
        return CanonicalTrajectory(
            records=tuple(records),
            sidecar=NormalizationSidecar(
                provider_id=provider_id,
                provider_version=provider_version,
                source_schema_version=schema_version,
                source_landmark_names=tuple(source for source, _ in sorted_mapping),
                landmark_mapping=sorted_mapping,
                source_unit="mm",
                unit_scale_to_m=0.001,
                axis_transform=("+x", "+z", "-y"),
                timebase_source="timestamp_ms",
                time_scale_to_s=0.001,
                unsupported_fields=tuple(sorted(ignored_fields)),
                warnings=("synthetic_fixture_not_real_provider",),
            ),
        )
