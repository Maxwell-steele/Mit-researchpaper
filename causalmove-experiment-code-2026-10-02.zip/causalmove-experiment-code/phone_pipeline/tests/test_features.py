"""Behavioral tests for registry-driven synthetic measurements."""

from __future__ import annotations

import hashlib
import json
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from phone_pipeline.acquisition import AcquisitionResult
from phone_pipeline.errors import FeatureValidationError
from phone_pipeline.events import extract_synthetic_events
from phone_pipeline.features import (
    SyntheticFeatureInput,
    build_synthetic_measurements,
    build_trial_feature_bundle,
    derive_side_normalized,
    load_synthetic_measure_registry,
)

from phone_pipeline.tests.test_events import SOURCE_HASH, annotations


FIXTURE = (
    Path(__file__).resolve().parent
    / "fixtures"
    / "measure_registry_synthetic_v1.json"
)
FIXTURE_HASH = "71cc2acf0fc834bd1786af9e774cf38a118da5ec56776a741e7b602f8ca6dff3"


def passing_acquisition() -> AcquisitionResult:
    return AcquisitionResult(
        state="phone_technical_pass",
        failure_codes=(),
        calibration_eligible=True,
        replacement_authorized=False,
        video_metadata=(),
        acquisition_registry_id="SYNTHETIC_ACQUISITION_V1",
        acquisition_registry_sha256="a" * 64,
    )


class FeatureTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = load_synthetic_measure_registry(FIXTURE, FIXTURE_HASH)
        self.events = extract_synthetic_events(
            annotations(), (SOURCE_HASH,), self.registry.event_registry
        )

    def measurements(self, candidates=None):
        return build_synthetic_measurements(
            trial_id="SYNTHETIC-T001",
            events=self.events,
            candidate_values={} if candidates is None else candidates,
            source_hashes=(SOURCE_HASH,),
            registry=self.registry,
        )

    def test_completion_time_and_log_score_are_hand_calculated(self) -> None:
        measurements = {item.measure_name: item for item in self.measurements()}
        duration = measurements["cut_completion_time"]
        score = measurements["task_performance_score"]
        self.assertAlmostEqual(duration.value, 0.79)
        self.assertAlmostEqual(duration.uncertainty, math.sqrt(0.01**2 + 0.02**2))
        self.assertAlmostEqual(score.value, math.log(0.79))
        self.assertAlmostEqual(score.uncertainty, duration.uncertainty / 0.79)
        self.assertEqual(score.unit, "1")
        self.assertEqual(score.intended_analysis_role, "primary_performance")

    def test_unregistered_feature_is_rejected(self) -> None:
        candidates = {
            "knee_injury_risk": SyntheticFeatureInput(
                value=0.2,
                uncertainty=0.01,
                unit="1",
                anatomical_side="left",
                event_window="initial_contact",
            )
        }
        with self.assertRaises(FeatureValidationError) as raised:
            self.measurements(candidates)
        self.assertEqual(raised.exception.code, "unregistered_measure")

    def test_out_of_range_value_becomes_missing_and_is_not_clipped(self) -> None:
        candidates = {
            "entry_speed": SyntheticFeatureInput(
                value=20.0,
                uncertainty=0.1,
                unit="m/s",
                anatomical_side="not_applicable",
                event_window="approach",
            )
        }
        measurements = {item.measure_name: item for item in self.measurements(candidates)}
        entry_speed = measurements["entry_speed"]
        self.assertFalse(entry_speed.measurement_valid)
        self.assertIsNone(entry_speed.value)
        self.assertEqual(entry_speed.missing_reason, "outside_valid_range")
        self.assertEqual(entry_speed.missingness_class, "derived_invalid")

    def test_unit_mismatch_is_rejected(self) -> None:
        candidates = {
            "entry_speed": SyntheticFeatureInput(
                value=5.0,
                uncertainty=0.1,
                unit="km/h",
                anatomical_side="not_applicable",
                event_window="approach",
            )
        }
        with self.assertRaises(FeatureValidationError) as raised:
            self.measurements(candidates)
        self.assertEqual(raised.exception.code, "unit_mismatch")

    def test_side_normalization_preserves_original_measurement(self) -> None:
        candidates = {
            "foot_progression_angle_at_initial_contact": SyntheticFeatureInput(
                value=-12.0,
                uncertainty=1.0,
                unit="deg",
                anatomical_side="left",
                event_window="initial_contact",
            )
        }
        original = {item.measure_name: item for item in self.measurements(candidates)}[
            "foot_progression_angle_at_initial_contact"
        ]
        transformed = derive_side_normalized(original, "reflect_left_to_right_v1")
        self.assertEqual(original.value, -12.0)
        self.assertEqual(original.anatomical_side, "left")
        self.assertEqual(transformed.value, 12.0)
        self.assertEqual(transformed.transform_id, "reflect_left_to_right_v1")
        self.assertEqual(transformed.original_measurement_id, original.measurement_id)
        self.assertEqual(transformed.original_measurement_hash, original.record_hash)
        self.assertEqual(transformed.original_value, -12.0)
        self.assertEqual(transformed.original_unit, "deg")
        self.assertEqual(transformed.original_anatomical_side, "left")

    def test_task_fidelity_failure_is_not_reclassified_as_technical(self) -> None:
        bundle = build_trial_feature_bundle(
            trial_id="SYNTHETIC-T001",
            acquisition=passing_acquisition(),
            measure_registry=self.registry,
            task_fidelity_status="angle_deviation",
            task_fidelity_rule_ids=("SYNTHETIC_ANGLE_RULE_V1",),
            safety_related_missingness=False,
            safety_reason_code=None,
            primary_missingness_treatment="preserve_missing_no_imputation_v1",
            measurements=self.measurements(),
        )
        self.assertEqual(bundle.task_fidelity_status, "angle_deviation")
        self.assertEqual(bundle.acquisition_state, "phone_technical_pass")
        self.assertIn("task_fidelity_failure", bundle.ineligibility_reasons)
        self.assertFalse(bundle.calibration_eligible)

    def test_measurement_event_sources_must_match_requested_sources(self) -> None:
        with self.assertRaises(FeatureValidationError) as raised:
            build_synthetic_measurements(
                trial_id="SYNTHETIC-T001",
                events=self.events,
                candidate_values={},
                source_hashes=("b" * 64,),
                registry=self.registry,
            )
        self.assertEqual(raised.exception.code, "event_source_mismatch")

    def test_safety_missingness_requires_controlled_reason(self) -> None:
        with self.assertRaises(FeatureValidationError) as raised:
            build_trial_feature_bundle(
                trial_id="SYNTHETIC-T001",
                acquisition=passing_acquisition(),
                measure_registry=self.registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=True,
                safety_reason_code=None,
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=self.measurements(),
            )
        self.assertEqual(raised.exception.code, "missing_safety_reason")

    def test_safety_reason_rejects_free_text(self) -> None:
        with self.assertRaises(FeatureValidationError) as raised:
            build_trial_feature_bundle(
                trial_id="SYNTHETIC-T001",
                acquisition=passing_acquisition(),
                measure_registry=self.registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=True,
                safety_reason_code="athlete said their private medical details here",
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=self.measurements(),
            )
        self.assertEqual(raised.exception.code, "invalid_safety_reason")

    def test_bundle_rejects_measurement_from_another_trial(self) -> None:
        measurements = list(self.measurements())
        measurements[0] = replace(measurements[0], trial_id="SYNTHETIC-T999")
        with self.assertRaises(FeatureValidationError) as raised:
            build_trial_feature_bundle(
                trial_id="SYNTHETIC-T001",
                acquisition=passing_acquisition(),
                measure_registry=self.registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=False,
                safety_reason_code=None,
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=tuple(measurements),
            )
        self.assertEqual(raised.exception.code, "measurement_trial_mismatch")

    def test_bundle_rejects_duplicate_measurement_id(self) -> None:
        measurements = self.measurements()
        with self.assertRaises(FeatureValidationError) as raised:
            build_trial_feature_bundle(
                trial_id="SYNTHETIC-T001",
                acquisition=passing_acquisition(),
                measure_registry=self.registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=False,
                safety_reason_code=None,
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=measurements + (measurements[0],),
            )
        self.assertEqual(raised.exception.code, "duplicate_measurement_id")

    def test_bundle_rejects_tampered_measurement_hash(self) -> None:
        measurements = list(self.measurements())
        measurements[0] = replace(measurements[0], record_hash="0" * 64)
        with self.assertRaises(FeatureValidationError) as raised:
            build_trial_feature_bundle(
                trial_id="SYNTHETIC-T001",
                acquisition=passing_acquisition(),
                measure_registry=self.registry,
                task_fidelity_status="pass",
                task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
                safety_related_missingness=False,
                safety_reason_code=None,
                primary_missingness_treatment="preserve_missing_no_imputation_v1",
                measurements=tuple(measurements),
            )
        self.assertEqual(raised.exception.code, "measurement_hash_mismatch")

    def test_phone_load_measure_is_not_available_in_registry(self) -> None:
        self.assertNotIn(
            "peak_external_knee_abduction_moment_normalized",
            self.registry.measures,
        )

    def test_non_test_measure_registry_is_rejected(self) -> None:
        real_registry = replace(self.registry, test_only=False)
        with self.assertRaises(FeatureValidationError) as raised:
            build_synthetic_measurements(
                trial_id="SYNTHETIC-T001",
                events=self.events,
                candidate_values={},
                source_hashes=(SOURCE_HASH,),
                registry=real_registry,
            )
        self.assertEqual(raised.exception.code, "real_measure_registry_not_authorized")

    def test_modified_registry_with_self_consistent_hash_is_not_approved(self) -> None:
        mapping = json.loads(FIXTURE.read_text(encoding="utf-8"))
        mapping["measures"]["entry_speed"]["maximum"] = 999.0
        payload = json.dumps(mapping).encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "registry.json"
            path.write_bytes(payload)
            with self.assertRaises(FeatureValidationError) as raised:
                load_synthetic_measure_registry(
                    path, hashlib.sha256(payload).hexdigest()
                )
        self.assertEqual(raised.exception.code, "unapproved_registry_digest")


if __name__ == "__main__":
    unittest.main()
