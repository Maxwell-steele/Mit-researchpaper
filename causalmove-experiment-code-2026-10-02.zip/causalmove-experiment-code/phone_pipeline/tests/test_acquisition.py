"""Behavioral tests for synthetic-only two-view acquisition QC."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from phone_pipeline.acquisition import (
    AcquisitionContext,
    evaluate_acquisition,
    load_synthetic_acquisition_registry,
)
from phone_pipeline.errors import AcquisitionValidationError
from phone_pipeline.manifest import VerifiedFile


FIXTURE = (
    Path(__file__).resolve().parent
    / "fixtures"
    / "acquisition_registry_synthetic_v1.json"
)
FIXTURE_HASH = "c5a90f85b832ee07e7bb0cb8ba97b2ae8f3d116d41f3fe45bc5339bd90090b96"
FFMPEG = shutil.which("ffmpeg")
FFPROBE = shutil.which("ffprobe")


def verified_file(path: Path, relative_uri: str) -> VerifiedFile:
    payload = path.read_bytes()
    return VerifiedFile(
        relative_uri=relative_uri,
        sha256=hashlib.sha256(payload).hexdigest(),
        size_bytes=len(payload),
        resolved_path=path,
    )


@unittest.skipUnless(FFMPEG and FFPROBE, "FFmpeg and FFprobe are required")
class AcquisitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temporary_directory = tempfile.TemporaryDirectory()
        cls.video_paths = []
        for name in ("front.mp4", "side.mp4"):
            path = Path(cls.temporary_directory.name) / name
            subprocess.run(
                [
                    str(FFMPEG),
                    "-v",
                    "error",
                    "-f",
                    "lavfi",
                    "-i",
                    "color=c=black:s=64x64:r=10:d=2.1",
                    "-c:v",
                    "mpeg4",
                    "-an",
                    str(path),
                ],
                check=True,
                capture_output=True,
            )
            cls.video_paths.append(path)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temporary_directory.cleanup()

    def setUp(self) -> None:
        self.registry = load_synthetic_acquisition_registry(FIXTURE, FIXTURE_HASH)
        self.views = (
            verified_file(self.video_paths[0], "videos/front.mp4"),
            verified_file(self.video_paths[1], "videos/side.mp4"),
        )
        self.context = AcquisitionContext(
            sync_offset_s=0.001,
            drift_ppm=5.0,
            reprojection_error_px=0.4,
        )

    def test_registry_hash_and_exact_schema_are_verified(self) -> None:
        self.assertEqual(self.registry.registry_id, "SYNTHETIC_ACQUISITION_V1")
        self.assertTrue(self.registry.test_only)
        with self.assertRaises(AcquisitionValidationError) as raised:
            load_synthetic_acquisition_registry(FIXTURE, "0" * 64)
        self.assertEqual(raised.exception.code, "registry_hash_mismatch")

    def test_unknown_registry_field_is_rejected_without_echoing_value(self) -> None:
        mapping = json.loads(FIXTURE.read_text(encoding="utf-8"))
        mapping["PRIVATE-NAME"] = "must-not-enter"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "registry.json"
            payload = json.dumps(mapping).encode("utf-8")
            path.write_bytes(payload)
            with self.assertRaises(AcquisitionValidationError) as raised:
                load_synthetic_acquisition_registry(
                    path, hashlib.sha256(payload).hexdigest()
                )
        self.assertEqual(raised.exception.code, "unknown_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_modified_registry_with_self_consistent_hash_is_not_approved(self) -> None:
        mapping = json.loads(FIXTURE.read_text(encoding="utf-8"))
        mapping["maximum_sync_offset_s"] = 99.0
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "registry.json"
            payload = json.dumps(mapping).encode("utf-8")
            path.write_bytes(payload)
            with self.assertRaises(AcquisitionValidationError) as raised:
                load_synthetic_acquisition_registry(
                    path, hashlib.sha256(payload).hexdigest()
                )
        self.assertEqual(raised.exception.code, "unapproved_registry_digest")

    def test_matching_two_view_metadata_passes(self) -> None:
        result = evaluate_acquisition(
            self.views,
            self.context,
            self.registry,
            ffprobe_executable=Path(str(FFPROBE)),
        )
        self.assertEqual(result.state, "phone_technical_pass")
        self.assertEqual(result.failure_codes, ())
        self.assertTrue(result.calibration_eligible)
        self.assertFalse(result.replacement_authorized)
        self.assertEqual(len(result.video_metadata), 2)
        self.assertEqual(result.video_metadata[0].codec_name, "mpeg4")
        self.assertEqual(result.video_metadata[0].frame_count, 21)
        self.assertEqual(result.video_metadata[0].frame_rate_fps, 10.0)
        self.assertNotIn(self.temporary_directory.name, repr(result))

    def test_technical_missingness_is_preserved_and_not_replaced(self) -> None:
        failed_sync = replace(self.context, sync_offset_s=0.010)
        result = evaluate_acquisition(
            self.views,
            failed_sync,
            self.registry,
            ffprobe_executable=Path(str(FFPROBE)),
        )
        self.assertEqual(result.state, "phone_technical_missing")
        self.assertIn("sync_failure", result.failure_codes)
        self.assertFalse(result.calibration_eligible)
        self.assertFalse(result.replacement_authorized)

    def test_codec_mismatch_fails_closed(self) -> None:
        mismatched = replace(self.registry, codec_name="h264")
        result = evaluate_acquisition(
            self.views,
            self.context,
            mismatched,
            ffprobe_executable=Path(str(FFPROBE)),
        )
        self.assertEqual(result.state, "phone_technical_missing")
        self.assertEqual(result.failure_codes, ("codec_mismatch",))

    def test_missing_ffprobe_is_a_controlled_decode_failure(self) -> None:
        result = evaluate_acquisition(
            self.views,
            self.context,
            self.registry,
            ffprobe_executable=Path("/not/a/real/ffprobe"),
        )
        self.assertEqual(result.state, "phone_technical_missing")
        self.assertEqual(result.failure_codes, ("decode_failure",))
        self.assertEqual(result.video_metadata, ())


if __name__ == "__main__":
    unittest.main()
