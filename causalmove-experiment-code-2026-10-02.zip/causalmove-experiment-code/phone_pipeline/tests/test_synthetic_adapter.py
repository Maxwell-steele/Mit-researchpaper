"""Behavioral tests for the test-only trajectory adapter."""

from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from phone_pipeline.adapters.synthetic import SyntheticTrajectoryAdapter
from phone_pipeline.errors import TrajectoryValidationError
from phone_pipeline.manifest import VerifiedFile, parse_trial_manifest

from phone_pipeline.tests.test_manifest import valid_manifest_mapping


FIXTURE = Path(__file__).resolve().parent / "fixtures" / "trajectory_synthetic_v1.json"
FIXTURE_HASH = "f00639df2ae0ce5043c8c962a75d680e0d1bd0bb056253f980541c24961b2bdb"


def manifest_for(digest: str, file_uri: str = "trajectory_synthetic_v1.json"):
    mapping = valid_manifest_mapping()
    export = mapping["trajectory_export"]
    assert isinstance(export, dict)
    export.update(
        {
            "provider_id": "synthetic_fixture",
            "provider_version": "synthetic-v1",
            "file_uri": file_uri,
            "sha256": digest,
        }
    )
    return parse_trial_manifest(json.dumps(mapping).encode("utf-8"))


def normalize_mapping(mapping: dict[str, object]):
    payload = json.dumps(mapping, sort_keys=True, separators=(",", ":")).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "trajectory.json"
        path.write_bytes(payload)
        source = VerifiedFile(
            relative_uri="trajectory.json",
            sha256=digest,
            size_bytes=len(payload),
            resolved_path=path,
        )
        return SyntheticTrajectoryAdapter().normalize(
            source, manifest_for(digest, "trajectory.json")
        )


class SyntheticAdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.mapping = json.loads(FIXTURE.read_text(encoding="utf-8"))

    def test_synthetic_export_normalizes_to_registered_task_frame(self) -> None:
        source = VerifiedFile(
            relative_uri="trajectory_synthetic_v1.json",
            sha256=FIXTURE_HASH,
            size_bytes=FIXTURE.stat().st_size,
            resolved_path=FIXTURE,
        )
        result = SyntheticTrajectoryAdapter().normalize(
            source, manifest_for(FIXTURE_HASH)
        )
        self.assertEqual(len(result.records), 4)
        first = result.records[0]
        self.assertEqual(first.frame_index, 0)
        self.assertEqual(first.landmark_name, "left_ankle")
        self.assertEqual(first.anatomical_side, "left")
        self.assertEqual((first.x, first.y, first.z), (0.1, 0.3, -0.2))
        self.assertEqual(first.timestamp_s, 0.0)
        self.assertEqual(first.unit, "m")
        self.assertEqual(first.coordinate_frame_id, "cut_task_frame_v1")
        self.assertEqual(result.sidecar.axis_transform, ("+x", "+z", "-y"))
        self.assertEqual(result.sidecar.unsupported_fields, ("fixture_note",))

    def test_missing_landmark_coordinates_are_preserved_not_imputed(self) -> None:
        result = normalize_mapping(self.mapping)
        missing = result.records[-1]
        self.assertEqual(missing.landmark_name, "right_ankle")
        self.assertEqual((missing.x, missing.y, missing.z), (None, None, None))
        self.assertIsNone(missing.confidence)
        self.assertEqual(missing.missing_reason, "occluded")

    def test_adapter_rechecks_bytes_against_verified_source_hash(self) -> None:
        source = VerifiedFile(
            relative_uri="trajectory_synthetic_v1.json",
            sha256="0" * 64,
            size_bytes=FIXTURE.stat().st_size,
            resolved_path=FIXTURE,
        )
        with self.assertRaises(TrajectoryValidationError) as raised:
            SyntheticTrajectoryAdapter().normalize(source, manifest_for("0" * 64))
        self.assertEqual(raised.exception.code, "source_hash_mismatch")

    def test_verified_source_uri_must_match_manifest_export_uri(self) -> None:
        source = VerifiedFile(
            relative_uri="other.json",
            sha256=FIXTURE_HASH,
            size_bytes=FIXTURE.stat().st_size,
            resolved_path=FIXTURE,
        )
        with self.assertRaises(TrajectoryValidationError) as raised:
            SyntheticTrajectoryAdapter().normalize(source, manifest_for(FIXTURE_HASH))
        self.assertEqual(raised.exception.code, "source_manifest_mismatch")

    def assert_adapter_error(self, code: str, mapping: dict[str, object]) -> None:
        with self.assertRaises(TrajectoryValidationError) as raised:
            normalize_mapping(mapping)
        self.assertEqual(raised.exception.code, code)

    def test_unknown_top_level_field_is_rejected_without_echoing_value(self) -> None:
        self.mapping["PRIVATE-NAME"] = "must-not-enter"
        with self.assertRaises(TrajectoryValidationError) as raised:
            normalize_mapping(self.mapping)
        self.assertEqual(raised.exception.code, "unknown_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_non_synthetic_provider_id_is_rejected(self) -> None:
        self.mapping["provider_id"] = "real_provider"
        self.assert_adapter_error("unsupported_provider", self.mapping)

    def test_undeclared_record_field_is_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list) and isinstance(records[0], dict)
        records[0]["surprise"] = 1
        self.assert_adapter_error("unknown_field", self.mapping)

    def test_unknown_source_landmark_is_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list) and isinstance(records[0], dict)
        records[0]["landmark"] = "UNKNOWN"
        self.assert_adapter_error("unknown_landmark", self.mapping)

    def test_partial_coordinates_are_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list) and isinstance(records[0], dict)
        records[0]["x_mm"] = None
        self.assert_adapter_error("partial_coordinates", self.mapping)

    def test_frame_gap_is_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list)
        for item in records[2:]:
            assert isinstance(item, dict)
            item["frame_index"] = 2
        self.assert_adapter_error("noncontiguous_frames", self.mapping)

    def test_nonincreasing_frame_time_is_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list)
        for item in records[2:]:
            assert isinstance(item, dict)
            item["timestamp_ms"] = 0.0
        self.assert_adapter_error("nonincreasing_time", self.mapping)

    def test_confidence_outside_unit_interval_is_rejected(self) -> None:
        records = self.mapping["records"]
        assert isinstance(records, list) and isinstance(records[0], dict)
        records[0]["confidence"] = -0.1
        self.assert_adapter_error("invalid_confidence", self.mapping)

    def test_adapter_output_is_deterministic_for_identical_bytes(self) -> None:
        first = normalize_mapping(self.mapping)
        second = normalize_mapping(self.mapping)
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
