"""Behavioral tests for the two-phone trial-manifest boundary."""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from phone_pipeline.errors import ManifestValidationError
from phone_pipeline.manifest import (
    load_and_verify_trial_manifest,
    parse_trial_manifest,
    verify_manifest_files,
)


HASH_A = "3d8b6beee0aee1c126a37a2729389af620fa6f819a3ba38da7e9bdbee0cf588e"
HASH_B = "7392d6defdeeab026a156d48113ce4c195d91e010eab7f32bdf94bd1c4657e58"
HASH_C = "a8198524f58e72b56283ab71ebddada22840f108b46ef7165bb3fca9919c5558"


def valid_manifest_mapping() -> dict[str, object]:
    """Return a complete hand-inspectable manifest mapping."""

    return {
        "schema_version": "causalmove-phone-trial-v1",
        "study_id": "SYNTHETIC-STUDY",
        "athlete_id": "SYNTHETIC-A001",
        "session_id": "SYNTHETIC-S001",
        "trial_id": "SYNTHETIC-T001",
        "athlete_record_hash": HASH_A,
        "processing_authorization_id": "SYNTHETIC-AUTH-001",
        "intended_output_tier": "r1_controlled_raw",
        "phase": "calibration",
        "task_id": "cut_90",
        "sport": "basketball",
        "assigned_condition_id": "FPA_ALIGN_EXIT_V1",
        "active_cue_id": "FPA_ALIGN_EXIT_V1",
        "plant_limb": "left",
        "pair_id": "SYNTHETIC-PAIR-001",
        "pair_replicate": 1,
        "block_index": 0,
        "pair_member": "active",
        "pair_sequence_index": 0,
        "within_pair_period": 1,
        "previous_cue_id": None,
        "washout_trial_ids": [],
        "replacement_of_trial_id": None,
        "personal_update_role": "update_input",
        "prospective_outcome_role": "not_used",
        "response_population_role": "not_used",
        "phone_configuration_hash": HASH_A,
        "acquisition_qc_registry_hash": HASH_B,
        "measure_registry_hash": HASH_C,
        "views": [
            {
                "camera_role": "frontal_oblique",
                "video_uri": "videos/front.mp4",
                "sha256": HASH_A,
                "device_id": "PHONE-A",
                "clock_domain": "CLOCK-V1",
                "sync_event_id": "SYNC-001",
                "intrinsic_calibration_id": "INTRINSIC-A",
                "extrinsic_calibration_id": "EXTRINSIC-A",
                "face_deidentification_status": "not_required_restricted",
                "audio_status": "removed_verified",
            },
            {
                "camera_role": "sagittal_oblique",
                "video_uri": "videos/side.mp4",
                "sha256": HASH_B,
                "device_id": "PHONE-B",
                "clock_domain": "CLOCK-V1",
                "sync_event_id": "SYNC-001",
                "intrinsic_calibration_id": "INTRINSIC-B",
                "extrinsic_calibration_id": "EXTRINSIC-B",
                "face_deidentification_status": "not_required_restricted",
                "audio_status": "removed_verified",
            },
        ],
        "trajectory_export": {
            "provider_id": "synthetic_fixture",
            "provider_version": "synthetic-v1",
            "file_uri": "trajectory/export.json",
            "sha256": HASH_C,
            "coordinate_frame_id": "cut_task_frame_v1",
        },
    }


class ManifestParsingTests(unittest.TestCase):
    def valid_payload(self) -> bytes:
        return json.dumps(valid_manifest_mapping()).encode("utf-8")

    def assert_manifest_error(self, code: str, payload: object) -> None:
        encoded = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
        with self.assertRaises(ManifestValidationError) as raised:
            parse_trial_manifest(encoded)
        self.assertEqual(raised.exception.code, code)

    def test_valid_manifest_parses_exactly_two_distinct_camera_roles(self) -> None:
        manifest = parse_trial_manifest(self.valid_payload())
        self.assertEqual(
            tuple(view.camera_role for view in manifest.views),
            ("frontal_oblique", "sagittal_oblique"),
        )

    def test_unknown_top_level_field_is_rejected(self) -> None:
        payload = valid_manifest_mapping()
        payload["PRIVATE-NAME"] = "must-not-enter"
        with self.assertRaises(ManifestValidationError) as raised:
            parse_trial_manifest(json.dumps(payload).encode("utf-8"))
        self.assertEqual(raised.exception.code, "unknown_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_duplicate_camera_role_is_rejected(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list)
        assert isinstance(views[1], dict)
        views[1]["camera_role"] = "frontal_oblique"
        with self.assertRaisesRegex(ManifestValidationError, "camera_roles"):
            parse_trial_manifest(json.dumps(payload).encode("utf-8"))

    def test_invalid_json_is_rejected_with_controlled_error(self) -> None:
        self.assert_manifest_error("invalid_json", b"{not-json")

    def test_duplicate_json_key_is_rejected(self) -> None:
        payload = self.valid_payload().decode("utf-8")
        duplicate = payload.replace(
            '"study_id": "SYNTHETIC-STUDY",',
            '"study_id": "SYNTHETIC-STUDY", "study_id": "SECOND",',
            1,
        )
        self.assert_manifest_error("duplicate_field", duplicate.encode("utf-8"))

    def test_duplicate_user_controlled_key_is_not_echoed(self) -> None:
        payload = self.valid_payload().decode("utf-8")
        duplicate = payload.replace(
            '"study_id": "SYNTHETIC-STUDY",',
            '"PRIVATE-NAME": 1, "PRIVATE-NAME": 2, "study_id": "SYNTHETIC-STUDY",',
            1,
        )
        with self.assertRaises(ManifestValidationError) as raised:
            parse_trial_manifest(duplicate.encode("utf-8"))
        self.assertEqual(raised.exception.code, "duplicate_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_missing_required_field_is_rejected(self) -> None:
        payload = valid_manifest_mapping()
        del payload["trial_id"]
        self.assert_manifest_error("missing_field", payload)

    def test_unknown_view_field_is_rejected_without_echoing_value(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list)
        assert isinstance(views[0], dict)
        views[0]["athlete_name"] = "PRIVATE-NAME"
        with self.assertRaises(ManifestValidationError) as raised:
            parse_trial_manifest(json.dumps(payload).encode("utf-8"))
        self.assertEqual(raised.exception.code, "unknown_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_boolean_is_not_accepted_as_integer_counter(self) -> None:
        payload = valid_manifest_mapping()
        payload["block_index"] = False
        self.assert_manifest_error("invalid_type", payload)

    def test_non_sha256_registry_hash_is_rejected(self) -> None:
        payload = valid_manifest_mapping()
        payload["measure_registry_hash"] = "abc"
        self.assert_manifest_error("invalid_sha256", payload)

    def test_unregistered_sport_is_rejected(self) -> None:
        payload = valid_manifest_mapping()
        payload["sport"] = "tennis"
        self.assert_manifest_error("invalid_value", payload)

    def test_one_based_pair_replicate_cannot_be_zero(self) -> None:
        payload = valid_manifest_mapping()
        payload["pair_replicate"] = 0
        self.assert_manifest_error("invalid_integer_range", payload)

    def test_within_pair_period_must_be_one_or_two(self) -> None:
        payload = valid_manifest_mapping()
        payload["within_pair_period"] = 3
        self.assert_manifest_error("invalid_value", payload)

    def test_view_sync_event_ids_must_match(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list)
        assert isinstance(views[1], dict)
        views[1]["sync_event_id"] = "SYNC-OTHER"
        self.assert_manifest_error("sync_event_mismatch", payload)

    def test_two_phone_views_require_distinct_device_ids(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list)
        assert isinstance(views[0], dict) and isinstance(views[1], dict)
        views[1]["device_id"] = views[0]["device_id"]
        self.assert_manifest_error("duplicate_device_id", payload)

    def test_two_phone_views_cannot_reference_the_same_file(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list)
        assert isinstance(views[0], dict) and isinstance(views[1], dict)
        views[1]["video_uri"] = views[0]["video_uri"]
        views[1]["sha256"] = views[0]["sha256"]
        self.assert_manifest_error("duplicate_view_uri", payload)

    def test_active_pair_member_must_match_active_assigned_condition(self) -> None:
        payload = valid_manifest_mapping()
        payload["assigned_condition_id"] = "CTRL_NEUTRAL_V1"
        self.assert_manifest_error("pair_condition_mismatch", payload)

    def test_control_pair_member_must_match_neutral_assigned_condition(self) -> None:
        payload = valid_manifest_mapping()
        payload["pair_member"] = "control"
        self.assert_manifest_error("pair_condition_mismatch", payload)

    def test_phase_and_analysis_roles_must_be_compatible(self) -> None:
        invalid_cases = (
            {"phase": "screening", "personal_update_role": "update_input"},
            {"phase": "reliability_pilot", "prospective_outcome_role": "evaluation"},
            {"phase": "model_development", "response_population_role": "not_used"},
            {"phase": "calibration", "personal_update_role": "not_used"},
            {"phase": "policy_validation", "personal_update_role": "update_input"},
        )
        for overrides in invalid_cases:
            with self.subTest(overrides=overrides):
                payload = valid_manifest_mapping()
                payload.update(overrides)
                self.assert_manifest_error("phase_role_mismatch", payload)

    def test_heldout_handball_cannot_enter_population_development(self) -> None:
        payload = valid_manifest_mapping()
        payload.update(
            {
                "sport": "handball",
                "phase": "model_development",
                "personal_update_role": "not_used",
                "response_population_role": "population_train",
            }
        )
        self.assert_manifest_error("heldout_sport_role_mismatch", payload)


class ManifestFileTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.controlled_root = Path(self.temporary_directory.name) / "controlled"
        (self.controlled_root / "videos").mkdir(parents=True)
        (self.controlled_root / "trajectory").mkdir()
        (self.controlled_root / "videos" / "front.mp4").write_bytes(b"front-video")
        (self.controlled_root / "videos" / "side.mp4").write_bytes(b"side-video")
        (self.controlled_root / "trajectory" / "export.json").write_bytes(
            b'{"synthetic":true}'
        )

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def parsed_manifest(self, **overrides: object):
        payload = valid_manifest_mapping()
        for key, value in overrides.items():
            if key == "frontal_video_uri":
                views = payload["views"]
                assert isinstance(views, list) and isinstance(views[0], dict)
                views[0]["video_uri"] = value
            elif key == "frontal_sha256":
                views = payload["views"]
                assert isinstance(views, list) and isinstance(views[0], dict)
                views[0]["sha256"] = value
            elif key == "trajectory_uri":
                export = payload["trajectory_export"]
                assert isinstance(export, dict)
                export["file_uri"] = value
            else:
                raise AssertionError(f"Unsupported test override: {key}")
        return parse_trial_manifest(json.dumps(payload).encode("utf-8"))

    def assert_file_error(self, code: str, manifest) -> ManifestValidationError:
        with self.assertRaises(ManifestValidationError) as raised:
            verify_manifest_files(manifest, self.controlled_root)
        self.assertEqual(raised.exception.code, code)
        self.assertNotIn(str(self.controlled_root), str(raised.exception))
        return raised.exception

    def test_matching_regular_files_are_verified(self) -> None:
        verified = verify_manifest_files(self.parsed_manifest(), self.controlled_root)
        self.assertEqual(tuple(item.relative_uri for item in verified.views), (
            "videos/front.mp4",
            "videos/side.mp4",
        ))
        self.assertEqual(verified.trajectory_export.sha256, HASH_C)
        self.assertNotIn(str(self.controlled_root), repr(verified))

    def test_parent_traversal_is_rejected_without_disclosing_root(self) -> None:
        self.assert_file_error(
            "path_outside_controlled_root",
            self.parsed_manifest(frontal_video_uri="../outside.mp4"),
        )

    def test_absolute_path_is_rejected(self) -> None:
        self.assert_file_error(
            "path_outside_controlled_root",
            self.parsed_manifest(frontal_video_uri="/tmp/outside.mp4"),
        )

    def test_backslash_uri_is_rejected_instead_of_reinterpreted(self) -> None:
        self.assert_file_error(
            "invalid_uri",
            self.parsed_manifest(frontal_video_uri=r"videos\..\outside.mp4"),
        )

    def test_symlink_input_is_rejected(self) -> None:
        link = self.controlled_root / "videos" / "link.mp4"
        try:
            link.symlink_to(self.controlled_root / "videos" / "front.mp4")
        except OSError as error:
            self.skipTest(f"symlinks unavailable: {error}")
        self.assert_file_error(
            "symlink_not_allowed",
            self.parsed_manifest(frontal_video_uri="videos/link.mp4"),
        )

    def test_directory_is_rejected_as_non_regular_file(self) -> None:
        self.assert_file_error(
            "not_regular_file",
            self.parsed_manifest(frontal_video_uri="videos"),
        )

    def test_missing_file_is_rejected(self) -> None:
        self.assert_file_error(
            "file_not_found",
            self.parsed_manifest(frontal_video_uri="videos/missing.mp4"),
        )

    def test_hash_mismatch_is_rejected(self) -> None:
        self.assert_file_error(
            "sha256_mismatch",
            self.parsed_manifest(frontal_sha256="0" * 64),
        )

    def test_failed_face_deidentification_blocks_file_verification(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list) and isinstance(views[0], dict)
        views[0]["face_deidentification_status"] = "failed"
        manifest = parse_trial_manifest(json.dumps(payload).encode("utf-8"))
        self.assert_file_error("deidentification_failed", manifest)

    def test_failed_audio_processing_blocks_file_verification(self) -> None:
        payload = valid_manifest_mapping()
        views = payload["views"]
        assert isinstance(views, list) and isinstance(views[0], dict)
        views[0]["audio_status"] = "failed"
        manifest = parse_trial_manifest(json.dumps(payload).encode("utf-8"))
        self.assert_file_error("audio_processing_failed", manifest)

    def test_intermediate_symlink_component_is_rejected(self) -> None:
        actual = self.controlled_root / "actual"
        actual.mkdir()
        (actual / "front.mp4").write_bytes(b"front-video")
        linked_directory = self.controlled_root / "linked"
        try:
            linked_directory.symlink_to(actual, target_is_directory=True)
        except OSError as error:
            self.skipTest(f"symlinks unavailable: {error}")
        self.assert_file_error(
            "symlink_not_allowed",
            self.parsed_manifest(frontal_video_uri="linked/front.mp4"),
        )

    def test_manifest_loader_returns_manifest_hash_and_verified_files(self) -> None:
        manifest_path = self.controlled_root / "trial.json"
        payload = json.dumps(
            valid_manifest_mapping(), sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        manifest_path.write_bytes(payload)
        verified = load_and_verify_trial_manifest(manifest_path, self.controlled_root)
        self.assertEqual(verified.manifest.trial_id, "SYNTHETIC-T001")
        self.assertEqual(
            verified.manifest_sha256,
            "49b35ebb2958ac8f7e778fdc682395851b1ef92c8fc901f4feca9f2872fd68c1",
        )

    def test_loader_rejects_manifest_symlink(self) -> None:
        source = self.controlled_root / "source.json"
        source.write_text(json.dumps(valid_manifest_mapping()), encoding="utf-8")
        manifest_link = self.controlled_root / "trial-link.json"
        try:
            os.symlink(source, manifest_link)
        except OSError as error:
            self.skipTest(f"symlinks unavailable: {error}")
        with self.assertRaises(ManifestValidationError) as raised:
            load_and_verify_trial_manifest(manifest_link, self.controlled_root)
        self.assertEqual(raised.exception.code, "symlink_not_allowed")

    def test_stage_one_loader_rejects_every_non_synthetic_sentinel(self) -> None:
        overrides = (
            ("study_id", "REAL-STUDY"),
            ("athlete_id", "A001"),
            ("session_id", "S001"),
            ("trial_id", "T001"),
            ("pair_id", "PAIR-001"),
            ("processing_authorization_id", "AUTH-001"),
            ("intended_output_tier", "r2_public_analysis"),
        )
        for field, value in overrides:
            with self.subTest(field=field):
                payload = valid_manifest_mapping()
                payload[field] = value
                manifest_path = self.controlled_root / f"real-{field}.json"
                manifest_path.write_text(json.dumps(payload), encoding="utf-8")
                with self.assertRaises(ManifestValidationError) as raised:
                    load_and_verify_trial_manifest(manifest_path, self.controlled_root)
                self.assertEqual(raised.exception.code, "real_data_not_authorized")

        payload = valid_manifest_mapping()
        export = payload["trajectory_export"]
        assert isinstance(export, dict)
        export["provider_version"] = "real-provider-version"
        manifest_path = self.controlled_root / "real-provider.json"
        manifest_path.write_text(json.dumps(payload), encoding="utf-8")
        with self.assertRaises(ManifestValidationError) as raised:
            load_and_verify_trial_manifest(manifest_path, self.controlled_root)
        self.assertEqual(raised.exception.code, "real_data_not_authorized")

        payload = valid_manifest_mapping()
        export = payload["trajectory_export"]
        assert isinstance(export, dict)
        export["provider_id"] = "unapproved_provider"
        manifest_path = self.controlled_root / "real-provider-id.json"
        manifest_path.write_text(json.dumps(payload), encoding="utf-8")
        with self.assertRaises(ManifestValidationError) as raised:
            load_and_verify_trial_manifest(manifest_path, self.controlled_root)
        self.assertEqual(raised.exception.code, "real_data_not_authorized")


if __name__ == "__main__":
    unittest.main()
