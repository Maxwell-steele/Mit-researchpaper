"""End-to-end tests for the local synthetic Stage 1 runner."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from phone_pipeline.run_synthetic import run_synthetic


FIXTURES = Path(__file__).resolve().parent / "fixtures"
FFMPEG = shutil.which("ffmpeg")
FFPROBE = shutil.which("ffprobe")


@unittest.skipUnless(FFMPEG and FFPROBE, "FFmpeg and FFprobe are required")
class EndToEndTests(unittest.TestCase):
    def bytes_by_relative_name(self, directory: Path) -> dict[str, bytes]:
        return {
            path.relative_to(directory).as_posix(): path.read_bytes()
            for path in sorted(directory.rglob("*"))
            if path.is_file()
        }

    def test_normal_run_stops_before_trial_batch_and_is_deterministic(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            first = run_synthetic(
                FIXTURES,
                Path(parent) / "normal-001",
                include_synthetic_test_load=False,
            )
            second = run_synthetic(
                FIXTURES,
                Path(parent) / "normal-002",
                include_synthetic_test_load=False,
            )
            self.assertEqual(
                self.bytes_by_relative_name(first),
                self.bytes_by_relative_name(second),
            )
            conversion = json.loads(
                (first / "conversion.json").read_text(encoding="utf-8")
            )
            self.assertFalse(conversion["eligible"])
            self.assertFalse(conversion["batch_created"])
            self.assertEqual(conversion["reasons"], ["load_measure_unavailable"])
            manifest = json.loads(
                (first / "bundle_manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(manifest["evidence_status"], "SYNTHETIC_SOFTWARE_ONLY")
            self.assertFalse(manifest["batch_created"])
            self.assertEqual(manifest["trial_count"], 4)
            self.assertEqual(
                manifest["provider_versions"],
                ["synthetic_fixture:synthetic-v1"],
            )
            for item in manifest["output_inventory"]:
                payload = (first / item["relative_path"]).read_bytes()
                self.assertEqual(hashlib.sha256(payload).hexdigest(), item["sha256"])
                self.assertEqual(len(payload), item["size_bytes"])
            trials = json.loads(
                (first / "trials.json").read_text(encoding="utf-8")
            )
            events = json.loads(
                (first / "events.json").read_text(encoding="utf-8")
            )
            self.assertEqual(len(trials), 4)
            self.assertEqual(len(events), 24)
            self.assertTrue(
                all("input_manifest_sha256" in trial for trial in trials)
            )
            self.assertTrue(all("trial_id" in event for event in events))
            combined = b"".join(self.bytes_by_relative_name(first).values())
            self.assertNotIn(str(Path(parent)).encode("utf-8"), combined)
            self.assertNotIn(b"athlete benefit", combined.lower())
            self.assertNotIn(b"injury prevention", combined.lower())

    def test_reserved_test_load_reaches_hand_checked_trial_batch(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            output = run_synthetic(
                FIXTURES,
                Path(parent) / "synthetic-load-001",
                include_synthetic_test_load=True,
            )
            conversion = json.loads(
                (output / "conversion.json").read_text(encoding="utf-8")
            )
            self.assertTrue(conversion["eligible"])
            self.assertTrue(conversion["batch_created"])
            self.assertEqual(conversion["reasons"], [])
            self.assertEqual(len(conversion["pairs"]), 2)
            first = next(pair for pair in conversion["pairs"] if pair["block"] == 0)
            self.assertAlmostEqual(first["difference"][0], 0.15)
            self.assertAlmostEqual(first["difference"][1], 0.03)
            manifest = json.loads(
                (output / "bundle_manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(manifest["evidence_status"], "SYNTHETIC_SOFTWARE_ONLY")
            self.assertTrue(manifest["batch_created"])

    def test_documented_direct_script_command_succeeds_with_controlled_json(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            output = Path(parent) / "direct-script"
            completed = subprocess.run(
                [
                    sys.executable,
                    "phone_pipeline/run_synthetic.py",
                    "--input",
                    "phone_pipeline/tests/fixtures",
                    "--output",
                    str(output),
                ],
                cwd=FIXTURES.parent.parent.parent,
                check=False,
                capture_output=True,
                text=True,
                timeout=60,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(
                json.loads(completed.stdout),
                {"evidence_status": "SYNTHETIC_SOFTWARE_ONLY", "ok": True},
            )
            self.assertEqual(completed.stderr, "")
            self.assertTrue((output / "bundle_manifest.json").is_file())


if __name__ == "__main__":
    unittest.main()
