"""Behavioral tests for provider-independent canonical trajectories."""

from __future__ import annotations

import unittest

from phone_pipeline.errors import TrajectoryValidationError
from phone_pipeline.trajectory import (
    CanonicalTrajectory,
    NormalizationSidecar,
    TrajectoryRecord,
)


SOURCE_HASH = "f00639df2ae0ce5043c8c962a75d680e0d1bd0bb056253f980541c24961b2bdb"


def record(
    frame_index: int,
    timestamp_s: float,
    landmark_name: str,
    **overrides: object,
) -> TrajectoryRecord:
    values: dict[str, object] = {
        "trial_id": "SYNTHETIC-T001",
        "frame_index": frame_index,
        "timestamp_s": timestamp_s,
        "landmark_name": landmark_name,
        "anatomical_side": "left" if landmark_name.startswith("left_") else "right",
        "x": 0.1,
        "y": 0.3,
        "z": -0.2,
        "unit": "m",
        "confidence": 0.95,
        "coordinate_frame_id": "cut_task_frame_v1",
        "source_export_sha256": SOURCE_HASH,
        "adapter_version": "synthetic-adapter-v1",
        "missing_reason": None,
    }
    values.update(overrides)
    return TrajectoryRecord(**values)


def sidecar() -> NormalizationSidecar:
    return NormalizationSidecar(
        provider_id="synthetic_fixture",
        provider_version="synthetic-v1",
        source_schema_version="causalmove-synthetic-trajectory-v1",
        source_landmark_names=("LANK", "RANK"),
        landmark_mapping=(("LANK", "left_ankle"), ("RANK", "right_ankle")),
        source_unit="mm",
        unit_scale_to_m=0.001,
        axis_transform=("+x", "+z", "-y"),
        timebase_source="timestamp_ms",
        time_scale_to_s=0.001,
        unsupported_fields=("fixture_note",),
        warnings=("synthetic_fixture_not_real_provider",),
    )


class TrajectoryRecordTests(unittest.TestCase):
    def assert_record_error(self, code: str, **overrides: object) -> None:
        with self.assertRaises(TrajectoryValidationError) as raised:
            record(0, 0.0, "left_ankle", **overrides)
        self.assertEqual(raised.exception.code, code)

    def test_partial_missing_coordinates_are_rejected(self) -> None:
        self.assert_record_error(
            "partial_coordinates",
            x=None,
            y=0.2,
            z=None,
            confidence=None,
            missing_reason="occluded",
        )

    def test_nonfinite_coordinate_is_rejected(self) -> None:
        self.assert_record_error("nonfinite_coordinate", x=float("nan"))

    def test_confidence_outside_unit_interval_is_rejected(self) -> None:
        self.assert_record_error("invalid_confidence", confidence=1.1)

    def test_missing_coordinates_require_reason_and_null_confidence(self) -> None:
        self.assert_record_error(
            "missing_reason_required",
            x=None,
            y=None,
            z=None,
            confidence=None,
        )
        self.assert_record_error(
            "confidence_on_missing_coordinates",
            x=None,
            y=None,
            z=None,
            confidence=0.2,
            missing_reason="occluded",
        )


class CanonicalTrajectoryTests(unittest.TestCase):
    def valid_records(self) -> tuple[TrajectoryRecord, ...]:
        return (
            record(0, 0.0, "left_ankle"),
            record(0, 0.0, "right_ankle"),
            record(1, 0.01, "left_ankle"),
            record(1, 0.01, "right_ankle"),
        )

    def assert_trajectory_error(
        self, code: str, records: tuple[TrajectoryRecord, ...]
    ) -> None:
        with self.assertRaises(TrajectoryValidationError) as raised:
            CanonicalTrajectory(records=records, sidecar=sidecar())
        self.assertEqual(raised.exception.code, code)

    def test_frame_indices_must_be_zero_based_and_contiguous(self) -> None:
        records = self.valid_records()
        changed = records[:2] + tuple(
            record(2, 0.01, item.landmark_name) for item in records[2:]
        )
        self.assert_trajectory_error("noncontiguous_frames", changed)

    def test_frame_timestamps_must_increase_strictly(self) -> None:
        records = self.valid_records()
        changed = records[:2] + tuple(
            record(1, 0.0, item.landmark_name) for item in records[2:]
        )
        self.assert_trajectory_error("nonincreasing_time", changed)

    def test_every_frame_must_contain_the_same_landmark_set(self) -> None:
        self.assert_trajectory_error("incomplete_frame", self.valid_records()[:-1])

    def test_duplicate_frame_landmark_is_rejected(self) -> None:
        records = self.valid_records()
        self.assert_trajectory_error("duplicate_frame_landmark", records + (records[-1],))
