"""Behavioral tests for synthetic annotation event extraction."""

from __future__ import annotations

import math
import unittest
from dataclasses import replace

from phone_pipeline.errors import EventValidationError
from phone_pipeline.events import (
    EventRegistry,
    completion_time_from_events,
    extract_synthetic_events,
)


SOURCE_HASH = "f00639df2ae0ce5043c8c962a75d680e0d1bd0bb056253f980541c24961b2bdb"
REQUIRED_EVENTS = (
    "approach",
    "penultimate_contact",
    "initial_contact",
    "weight_acceptance",
    "toe_off",
    "exit",
)


def registry() -> EventRegistry:
    return EventRegistry(
        required_events=REQUIRED_EVENTS,
        method_version="synthetic-annotation-events-v1",
        uncertainty_assumption="independent_endpoints",
        test_only=True,
    )


def annotations() -> dict[str, tuple[float, float]]:
    return {
        "approach": (0.10, 0.01),
        "penultimate_contact": (0.42, 0.01),
        "initial_contact": (0.68, 0.01),
        "weight_acceptance": (0.76, 0.01),
        "toe_off": (0.91, 0.01),
        "exit": (1.47, 0.02),
    }


class EventTests(unittest.TestCase):
    def assert_event_error(
        self, code: str, values: dict[str, tuple[float, float]]
    ) -> None:
        with self.assertRaises(EventValidationError) as raised:
            extract_synthetic_events(values, (SOURCE_HASH,), registry())
        self.assertEqual(raised.exception.code, code)

    def test_registered_sequence_produces_ordered_auditable_events(self) -> None:
        result = extract_synthetic_events(annotations(), (SOURCE_HASH,), registry())
        self.assertEqual(tuple(item.event_id for item in result), REQUIRED_EVENTS)
        self.assertEqual(result[2].timestamp_s, 0.68)
        self.assertEqual(result[2].uncertainty_s, 0.01)
        self.assertEqual(result[2].source_hashes, (SOURCE_HASH,))
        self.assertEqual(result[2].method_version, "synthetic-annotation-events-v1")
        self.assertEqual(result[2].qc_status, "synthetic_annotation_only")

    def test_missing_required_event_is_rejected(self) -> None:
        values = annotations()
        del values["toe_off"]
        self.assert_event_error("missing_event", values)

    def test_unknown_event_is_rejected(self) -> None:
        values = annotations()
        values["heel_strike"] = (0.5, 0.01)
        self.assert_event_error("unknown_event", values)

    def test_reordered_events_are_rejected(self) -> None:
        values = annotations()
        values["weight_acceptance"] = (0.60, 0.01)
        self.assert_event_error("event_order", values)

    def test_completion_time_and_uncertainty_are_hand_calculated(self) -> None:
        events = extract_synthetic_events(annotations(), (SOURCE_HASH,), registry())
        estimate, uncertainty = completion_time_from_events(events, registry())
        self.assertAlmostEqual(estimate, 0.79)
        self.assertAlmostEqual(uncertainty, math.sqrt(0.01**2 + 0.02**2))

    def test_completion_rejects_unregistered_event_method(self) -> None:
        events = list(extract_synthetic_events(annotations(), (SOURCE_HASH,), registry()))
        events[2] = replace(events[2], method_version="forged-detector-v1")
        with self.assertRaises(EventValidationError) as raised:
            completion_time_from_events(tuple(events), registry())
        self.assertEqual(raised.exception.code, "event_method_mismatch")

    def test_completion_rejects_inconsistent_event_sources(self) -> None:
        events = list(extract_synthetic_events(annotations(), (SOURCE_HASH,), registry()))
        events[-1] = replace(events[-1], source_hashes=("b" * 64,))
        with self.assertRaises(EventValidationError) as raised:
            completion_time_from_events(tuple(events), registry())
        self.assertEqual(raised.exception.code, "event_source_mismatch")

    def test_completion_rejects_non_synthetic_qc_status(self) -> None:
        events = list(extract_synthetic_events(annotations(), (SOURCE_HASH,), registry()))
        events[0] = replace(events[0], qc_status="production_detector_pass")
        with self.assertRaises(EventValidationError) as raised:
            completion_time_from_events(tuple(events), registry())
        self.assertEqual(raised.exception.code, "event_qc_mismatch")

    def test_completion_rejects_forged_intermediate_event_order(self) -> None:
        events = list(extract_synthetic_events(annotations(), (SOURCE_HASH,), registry()))
        events[3] = replace(events[3], timestamp_s=0.05)
        with self.assertRaises(EventValidationError) as raised:
            completion_time_from_events(tuple(events), registry())
        self.assertEqual(raised.exception.code, "event_order")

    def test_non_test_registry_is_rejected(self) -> None:
        real_registry = EventRegistry(
            required_events=REQUIRED_EVENTS,
            method_version="unvalidated-real-detector",
            uncertainty_assumption="independent_endpoints",
            test_only=False,
        )
        with self.assertRaises(EventValidationError) as raised:
            extract_synthetic_events(annotations(), (SOURCE_HASH,), real_registry)
        self.assertEqual(raised.exception.code, "real_event_detector_not_authorized")


if __name__ == "__main__":
    unittest.main()
