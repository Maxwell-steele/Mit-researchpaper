"""Behavioral tests for deterministic, non-overwriting evidence bundles."""

from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from phone_pipeline.errors import ProvenanceError
from phone_pipeline.provenance import (
    EvidenceProvenance,
    canonical_json_bytes,
    canonical_tsv_bytes,
    write_evidence_bundle,
)


class ProvenanceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.provenance = EvidenceProvenance(
            input_sha256s=("b" * 64, "a" * 64),
            provider_versions=("synthetic_fixture:synthetic-v1",),
            adapter_versions=("synthetic-adapter-v1",),
            event_versions=("synthetic-annotation-events-v1",),
            feature_versions=("synthetic-features-v1",),
            registry_sha256s=("d" * 64, "c" * 64),
            source_tree_sha256="e" * 64,
            execution_environment="python-test-runtime",
            warnings=("synthetic_fixture_not_real_provider", "alpha_warning"),
            failure_codes=("sync_failure", "calibration_failure"),
            conversion_reasons=("load_measure_unavailable",),
            trial_count=4,
            batch_created=False,
        )
        self.artifacts = {
            "conversion.json": canonical_json_bytes(
                {"eligible": False, "reasons": ["load_measure_unavailable"]}
            ),
            "measurements.tsv": canonical_tsv_bytes(
                ("trial_id", "measure"),
                (("SYNTHETIC-T001", "task_performance_score"),),
            ),
        }

    def bytes_by_relative_name(self, directory: Path) -> dict[str, bytes]:
        return {
            path.relative_to(directory).as_posix(): path.read_bytes()
            for path in sorted(directory.rglob("*"))
            if path.is_file()
        }

    def test_identical_inputs_produce_byte_identical_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            first = write_evidence_bundle(
                Path(parent) / "run-001", self.artifacts, self.provenance
            )
            second = write_evidence_bundle(
                Path(parent) / "run-002", self.artifacts, self.provenance
            )
            self.assertEqual(
                self.bytes_by_relative_name(first),
                self.bytes_by_relative_name(second),
            )
            manifest = json.loads(
                (first / "bundle_manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(manifest["evidence_status"], "SYNTHETIC_SOFTWARE_ONLY")
            self.assertEqual(manifest["input_sha256s"], ["a" * 64, "b" * 64])
            self.assertEqual(
                manifest["provider_versions"],
                ["synthetic_fixture:synthetic-v1"],
            )
            self.assertEqual(
                manifest["output_inventory_scope"],
                "artifacts_excluding_bundle_manifest_v1",
            )
            self.assertEqual(
                manifest["warnings"],
                ["alpha_warning", "synthetic_fixture_not_real_provider"],
            )
            self.assertEqual(
                [item["relative_path"] for item in manifest["output_inventory"]],
                ["conversion.json", "measurements.tsv"],
            )

    def test_existing_output_directory_is_never_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            output = Path(parent) / "run-001"
            output.mkdir()
            marker = output / "keep.txt"
            marker.write_bytes(b"unchanged")
            with self.assertRaises(ProvenanceError) as raised:
                write_evidence_bundle(output, self.artifacts, self.provenance)
            self.assertEqual(raised.exception.code, "output_exists")
            self.assertEqual(marker.read_bytes(), b"unchanged")

    def test_artifact_path_traversal_is_rejected_before_directory_creation(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            output = Path(parent) / "run-001"
            with self.assertRaises(ProvenanceError) as raised:
                write_evidence_bundle(
                    output,
                    {"../escape.json": b"{}\n"},
                    self.provenance,
                )
            self.assertEqual(raised.exception.code, "invalid_artifact_name")
            self.assertFalse(output.exists())

    def test_canonical_json_rejects_nonfinite_numbers(self) -> None:
        with self.assertRaises(ProvenanceError) as raised:
            canonical_json_bytes({"value": float("nan")})
        self.assertEqual(raised.exception.code, "nonfinite_json")

    def test_empty_provider_versions_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as parent:
            with self.assertRaises(ProvenanceError) as raised:
                write_evidence_bundle(
                    Path(parent) / "run-001",
                    self.artifacts,
                    replace(self.provenance, provider_versions=()),
                )
            self.assertEqual(raised.exception.code, "invalid_controlled_value")


if __name__ == "__main__":
    unittest.main()
