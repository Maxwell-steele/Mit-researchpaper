"""Behavioral tests for the fail-closed policy-batch bridge."""

from __future__ import annotations

import json
import hashlib
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from phone_pipeline.acquisition import AcquisitionResult
from phone_pipeline.events import extract_synthetic_events
from phone_pipeline.features import (
    build_synthetic_measurements,
    build_trial_feature_bundle,
    load_synthetic_measure_registry,
)
from phone_pipeline.manifest import parse_trial_manifest
from phone_pipeline.trial_batch import (
    CalibrationTrialInput,
    LoadRegistryStatus,
    build_synthetic_test_load_record,
    convert_to_trial_batch,
    load_synthetic_test_load_registry,
)
from phone_pipeline.errors import TrialBatchValidationError
from phone_pipeline.tests.test_events import SOURCE_HASH, annotations
from phone_pipeline.tests.test_features import FIXTURE as MEASURE_FIXTURE
from phone_pipeline.tests.test_features import FIXTURE_HASH as MEASURE_FIXTURE_HASH
from phone_pipeline.tests.test_manifest import valid_manifest_mapping


LOAD_FIXTURE = (
    Path(__file__).resolve().parent
    / "fixtures"
    / "synthetic_test_load_registry_v1.json"
)
LOAD_FIXTURE_HASH = "e64f41cdb7d5cffd25df01d187e04dee7b47928ce6fe098fdb1a5961ee04ae20"


def unavailable_registry() -> LoadRegistryStatus:
    return LoadRegistryStatus(
        registry_id="PHONE_LOAD_PENDING_V1",
        registry_sha256="a" * 64,
        test_only=False,
        evidence_status="NOT_VALIDATED",
        measure_name=None,
        unit=None,
        minimum=None,
        maximum=None,
        processing_version=None,
        measure_available=False,
    )


class TrialBatchBoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.measure_registry = load_synthetic_measure_registry(
            MEASURE_FIXTURE, MEASURE_FIXTURE_HASH
        )
        self.load_registry = load_synthetic_test_load_registry(
            LOAD_FIXTURE, LOAD_FIXTURE_HASH
        )
        self.complete_trials = self.make_trials(blocks=2)

    def manifest_for(
        self,
        *,
        block: int,
        member: str,
        period: int,
        sequence_index: int,
    ):
        mapping = valid_manifest_mapping()
        mapping["trial_id"] = f"SYNTHETIC-T-{block}-{member}"
        mapping["pair_id"] = f"SYNTHETIC-PAIR-{block}"
        mapping["pair_replicate"] = block + 1
        mapping["block_index"] = block
        mapping["pair_sequence_index"] = sequence_index
        mapping["pair_member"] = member
        mapping["within_pair_period"] = period
        mapping["assigned_condition_id"] = (
            mapping["active_cue_id"] if member == "active" else "CTRL_NEUTRAL_V1"
        )
        mapping["acquisition_qc_registry_hash"] = "a" * 64
        mapping["measure_registry_hash"] = MEASURE_FIXTURE_HASH
        trajectory = mapping["trajectory_export"]
        assert isinstance(trajectory, dict)
        trajectory["sha256"] = SOURCE_HASH
        return parse_trial_manifest(json.dumps(mapping).encode("utf-8"))

    def trial_input(
        self,
        *,
        block: int,
        member: str,
        period: int,
        score: float,
        load: float,
    ) -> CalibrationTrialInput:
        manifest = self.manifest_for(
            block=block,
            member=member,
            period=period,
            sequence_index=block,
        )
        event_values = annotations()
        initial_contact = event_values["initial_contact"][0]
        event_values["exit"] = (initial_contact + math.exp(score), 0.02)
        events = extract_synthetic_events(
            event_values,
            (SOURCE_HASH,),
            self.measure_registry.event_registry,
        )
        measurements = build_synthetic_measurements(
            trial_id=manifest.trial_id,
            events=events,
            candidate_values={},
            source_hashes=(SOURCE_HASH,),
            registry=self.measure_registry,
        )
        acquisition = AcquisitionResult(
            state="phone_technical_pass",
            failure_codes=(),
            calibration_eligible=True,
            replacement_authorized=False,
            video_metadata=(),
            acquisition_registry_id="SYNTHETIC_ACQUISITION_V1",
            acquisition_registry_sha256="a" * 64,
        )
        bundle = build_trial_feature_bundle(
            trial_id=manifest.trial_id,
            acquisition=acquisition,
            measure_registry=self.measure_registry,
            task_fidelity_status="pass",
            task_fidelity_rule_ids=("SYNTHETIC_PASS_RULE_V1",),
            safety_related_missingness=False,
            safety_reason_code=None,
            primary_missingness_treatment="preserve_missing_no_imputation_v1",
            measurements=measurements,
        )
        load_record = build_synthetic_test_load_record(
            trial_id=manifest.trial_id,
            value=load,
            uncertainty=0.001,
            source_hashes=(SOURCE_HASH,),
            registry=self.load_registry,
        )
        return CalibrationTrialInput(
            manifest=manifest,
            features=bundle,
            synthetic_test_load=load_record,
        )

    def make_trials(self, *, blocks: int) -> tuple[CalibrationTrialInput, ...]:
        trials = []
        for block in range(blocks):
            cue_period = 1 if block % 2 == 0 else 2
            trials.extend(
                (
                    self.trial_input(
                        block=block,
                        member="active",
                        period=cue_period,
                        score=0.10,
                        load=0.04,
                    ),
                    self.trial_input(
                        block=block,
                        member="control",
                        period=3 - cue_period,
                        score=0.25,
                        load=0.01,
                    ),
                )
            )
        return tuple(trials)

    def test_unavailable_phone_load_refuses_batch_before_prototype_import(self) -> None:
        original_import = __import__

        def guarded_import(name, *args, **kwargs):
            if name == "prototype.causal_move":
                raise AssertionError("prototype import crossed unavailable-load boundary")
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=guarded_import):
            result = convert_to_trial_batch(
                self.complete_trials, unavailable_registry()
            )
        self.assertIsNone(result.batch)
        self.assertFalse(result.eligible)
        self.assertEqual(result.reasons, ("load_measure_unavailable",))

    def test_reserved_synthetic_registry_uses_asymmetric_sign_convention(self) -> None:
        result = convert_to_trial_batch(self.complete_trials, self.load_registry)
        self.assertTrue(result.eligible)
        self.assertEqual(result.reasons, ())
        self.assertIsNotNone(result.batch)
        assert result.batch is not None
        self.assertEqual(result.batch.phase, "calibration")
        self.assertEqual(len(result.batch.pairs), 2)
        first = next(pair for pair in result.batch.pairs if pair.block == 0)
        self.assertAlmostEqual(first.cue_outcome[0], -0.10)
        self.assertAlmostEqual(first.control_outcome[0], -0.25)
        self.assertAlmostEqual(first.difference[0], 0.15)
        self.assertAlmostEqual(first.difference[1], 0.03)

    def test_synthetic_registry_rejects_non_synthetic_manifest(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(
            altered[0],
            manifest=replace(altered[0].manifest, study_id="REAL-STUDY"),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("synthetic_manifest_required", result.reasons)

    def test_duplicate_pair_members_are_rejected(self) -> None:
        altered = list(self.complete_trials)
        control = altered[1]
        altered[1] = replace(
            control,
            manifest=replace(
                control.manifest,
                pair_member="active",
                assigned_condition_id=control.manifest.active_cue_id,
            ),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("pair_member_set", result.reasons)

    def test_mixed_pair_identity_is_rejected(self) -> None:
        altered = list(self.complete_trials)
        altered[1] = replace(
            altered[1],
            manifest=replace(altered[1].manifest, pair_id="SYNTHETIC-OTHER-PAIR"),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("pair_identity_mismatch", result.reasons)

    def test_invalid_pair_periods_are_rejected(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(
            altered[0],
            manifest=replace(altered[0].manifest, within_pair_period=2),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("pair_period_set", result.reasons)

    def test_at_least_two_blocks_per_cue_are_required(self) -> None:
        result = convert_to_trial_batch(self.complete_trials[:2], self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("insufficient_blocks", result.reasons)

    def test_cue_control_order_must_be_counterbalanced(self) -> None:
        altered = list(self.make_trials(blocks=3))
        for index in (2, 3):
            member = altered[index].manifest.pair_member
            altered[index] = replace(
                altered[index],
                manifest=replace(
                    altered[index].manifest,
                    within_pair_period=1 if member == "active" else 2,
                ),
            )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("pair_order_imbalance", result.reasons)

    def test_prospective_role_is_blocked_by_outcome_firewall(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(
            altered[0],
            manifest=replace(
                altered[0].manifest,
                phase="policy_validation",
                personal_update_role="not_used",
                prospective_outcome_role="evaluation",
            ),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("forbidden_trial_role", result.reasons)

    def test_missing_pair_member_is_rejected(self) -> None:
        altered = self.complete_trials[:1] + self.complete_trials[2:]
        result = convert_to_trial_batch(altered, self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("pair_member_set", result.reasons)

    def test_duplicate_trial_input_is_rejected_explicitly(self) -> None:
        altered = self.complete_trials + (self.complete_trials[0],)
        result = convert_to_trial_batch(altered, self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("duplicate_trial_id", result.reasons)

    def test_pair_id_cannot_be_reused_for_another_block(self) -> None:
        altered = list(self.complete_trials)
        first_pair_id = altered[0].manifest.pair_id
        for index in (2, 3):
            altered[index] = replace(
                altered[index],
                manifest=replace(altered[index].manifest, pair_id=first_pair_id),
            )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("duplicate_pair_id", result.reasons)

    def test_tampered_feature_record_cannot_reach_policy_batch(self) -> None:
        altered = list(self.complete_trials)
        records = list(altered[0].features.measurements)
        score_index = next(
            index
            for index, record in enumerate(records)
            if record.measure_name == "task_performance_score"
        )
        records[score_index] = replace(records[score_index], value=-1.5)
        altered[0] = replace(
            altered[0],
            features=replace(altered[0].features, measurements=tuple(records)),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("feature_bundle_integrity", result.reasons)

    def test_missing_synthetic_load_record_is_rejected(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(altered[0], synthetic_test_load=None)
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("load_record_missing", result.reasons)

    def test_mixed_measure_registry_is_rejected(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(
            altered[0],
            features=replace(
                altered[0].features,
                measure_registry_sha256="b" * 64,
            ),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("registry_mismatch", result.reasons)

    def test_synthetic_registry_hash_is_verified(self) -> None:
        with self.assertRaises(TrialBatchValidationError) as raised:
            load_synthetic_test_load_registry(LOAD_FIXTURE, "0" * 64)
        self.assertEqual(raised.exception.code, "registry_hash_mismatch")

    def test_synthetic_registry_rejects_unknown_field_without_echoing_it(self) -> None:
        mapping = json.loads(LOAD_FIXTURE.read_text(encoding="utf-8"))
        mapping["PRIVATE-NAME"] = "must-not-enter"
        payload = json.dumps(mapping).encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "load-registry.json"
            path.write_bytes(payload)
            with self.assertRaises(TrialBatchValidationError) as raised:
                load_synthetic_test_load_registry(
                    path, hashlib.sha256(payload).hexdigest()
                )
        self.assertEqual(raised.exception.code, "unknown_field")
        self.assertNotIn("PRIVATE-NAME", str(raised.exception))

    def test_modified_registry_with_self_consistent_hash_is_not_approved(self) -> None:
        mapping = json.loads(LOAD_FIXTURE.read_text(encoding="utf-8"))
        mapping["maximum"] = 1000.0
        payload = json.dumps(mapping).encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "modified-load-registry.json"
            path.write_bytes(payload)
            with self.assertRaises(TrialBatchValidationError) as raised:
                load_synthetic_test_load_registry(
                    path, hashlib.sha256(payload).hexdigest()
                )
        self.assertEqual(raised.exception.code, "unapproved_registry_digest")

    def test_forged_registry_status_with_wider_range_is_not_authorized(self) -> None:
        forged = replace(self.load_registry, maximum=1000.0)
        result = convert_to_trial_batch(self.complete_trials, forged)
        self.assertIsNone(result.batch)
        self.assertEqual(result.reasons, ("load_registry_not_authorized",))

    def test_available_non_test_registry_is_not_authorized(self) -> None:
        untrusted = replace(
            self.load_registry,
            test_only=False,
            evidence_status="PRODUCTION",
        )
        result = convert_to_trial_batch(self.complete_trials, untrusted)
        self.assertIsNone(result.batch)
        self.assertEqual(result.reasons, ("load_registry_not_authorized",))

    def test_untyped_future_outcome_mapping_fails_closed(self) -> None:
        altered = list(self.complete_trials)
        altered[0] = replace(
            altered[0],
            manifest={"future_policy_label": "P", "reference_load": 999.0},
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertEqual(result.reasons, ("invalid_trial_input",))

    def test_nonnumeric_forged_load_fails_closed(self) -> None:
        altered = list(self.complete_trials)
        load = altered[0].synthetic_test_load
        assert load is not None
        altered[0] = replace(
            altered[0],
            synthetic_test_load=replace(load, value="not-a-number"),
        )
        result = convert_to_trial_batch(tuple(altered), self.load_registry)
        self.assertIsNone(result.batch)
        self.assertIn("load_measure_invalid", result.reasons)

    def test_mixed_athlete_sport_cue_and_block_fields_are_rejected(self) -> None:
        mutations = {
            "athlete_id": "SYNTHETIC-A999",
            "sport": "soccer",
            "active_cue_id": "BRAKE_EARLIER_V1",
            "block_index": 99,
        }
        for field, value in mutations.items():
            with self.subTest(field=field):
                altered = list(self.complete_trials)
                altered[1] = replace(
                    altered[1],
                    manifest=replace(altered[1].manifest, **{field: value}),
                )
                result = convert_to_trial_batch(tuple(altered), self.load_registry)
                self.assertIsNone(result.batch)
                self.assertFalse(result.eligible)


if __name__ == "__main__":
    unittest.main()
