"""Tests for the synthetic-only phone pipeline."""
