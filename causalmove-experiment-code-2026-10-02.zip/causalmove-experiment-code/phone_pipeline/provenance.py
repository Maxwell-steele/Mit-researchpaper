"""Deterministic, non-overwriting evidence bundles for synthetic runs."""

from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, NoReturn, Sequence

from .errors import ProvenanceError


EVIDENCE_STATUS = "SYNTHETIC_SOFTWARE_ONLY"
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
ARTIFACT_NAME_PATTERN = re.compile(r"[a-z0-9][a-z0-9_.-]*\Z")
CONTROLLED_VALUE_PATTERN = re.compile(r"[A-Za-z0-9_.:-]+\Z")


def _fail(code: str, field: str) -> NoReturn:
    raise ProvenanceError(code, field)


def canonical_json_bytes(value: object) -> bytes:
    """Encode finite JSON with stable keys, separators, UTF-8, and newline."""

    try:
        return (
            json.dumps(
                value,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            )
            + "\n"
        ).encode("utf-8")
    except ValueError:
        _fail("nonfinite_json", "json")
    except (TypeError, UnicodeError):
        _fail("invalid_json_value", "json")


def _tsv_scalar(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        text = "true" if value else "false"
    elif isinstance(value, float):
        if not math.isfinite(value):
            _fail("nonfinite_tsv", "tsv")
        text = repr(value)
    elif isinstance(value, (str, int)):
        text = str(value)
    else:
        _fail("invalid_tsv_value", "tsv")
    if any(character in text for character in ("\t", "\r", "\n")):
        _fail("unsafe_tsv_value", "tsv")
    return text


def canonical_tsv_bytes(
    header: tuple[str, ...], rows: Sequence[Sequence[object]]
) -> bytes:
    """Encode fixed-width tabular rows with stable LF line endings."""

    if not isinstance(header, tuple) or not header:
        _fail("invalid_tsv_header", "tsv.header")
    encoded_header = tuple(_tsv_scalar(value) for value in header)
    if any(not value for value in encoded_header) or len(set(encoded_header)) != len(
        encoded_header
    ):
        _fail("invalid_tsv_header", "tsv.header")
    lines = ["\t".join(encoded_header)]
    for row in rows:
        if len(row) != len(header):
            _fail("tsv_width_mismatch", "tsv.rows")
        lines.append("\t".join(_tsv_scalar(value) for value in row))
    return ("\n".join(lines) + "\n").encode("utf-8")


@dataclass(frozen=True)
class EvidenceProvenance:
    input_sha256s: tuple[str, ...]
    provider_versions: tuple[str, ...]
    adapter_versions: tuple[str, ...]
    event_versions: tuple[str, ...]
    feature_versions: tuple[str, ...]
    registry_sha256s: tuple[str, ...]
    source_tree_sha256: str
    execution_environment: str
    warnings: tuple[str, ...]
    failure_codes: tuple[str, ...]
    conversion_reasons: tuple[str, ...]
    trial_count: int
    batch_created: bool


def _validate_hashes(values: tuple[str, ...], field: str) -> tuple[str, ...]:
    if not isinstance(values, tuple) or not values or any(
        not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None
        for value in values
    ):
        _fail("invalid_sha256", field)
    return tuple(sorted(values))


def _validate_controlled_values(
    values: tuple[str, ...], field: str
) -> tuple[str, ...]:
    if not isinstance(values, tuple) or any(
        not isinstance(value, str)
        or CONTROLLED_VALUE_PATTERN.fullmatch(value) is None
        for value in values
    ):
        _fail("invalid_controlled_value", field)
    return tuple(sorted(set(values)))


def _manifest_mapping(
    artifacts: Mapping[str, bytes], provenance: EvidenceProvenance
) -> dict[str, object]:
    if not isinstance(provenance, EvidenceProvenance):
        _fail("invalid_type", "provenance")
    if (
        isinstance(provenance.trial_count, bool)
        or not isinstance(provenance.trial_count, int)
        or provenance.trial_count < 0
    ):
        _fail("invalid_trial_count", "provenance.trial_count")
    if not isinstance(provenance.batch_created, bool):
        _fail("invalid_type", "provenance.batch_created")
    if (
        not isinstance(provenance.source_tree_sha256, str)
        or SHA256_PATTERN.fullmatch(provenance.source_tree_sha256) is None
    ):
        _fail("invalid_sha256", "provenance.source_tree_sha256")
    execution_environment = provenance.execution_environment
    if (
        not isinstance(execution_environment, str)
        or not execution_environment
        or execution_environment.startswith("/")
        or any(character in execution_environment for character in ("\r", "\n"))
    ):
        _fail("invalid_environment", "provenance.execution_environment")
    provider_versions = _validate_controlled_values(
        provenance.provider_versions, "provenance.provider_versions"
    )
    if not provider_versions:
        _fail("invalid_controlled_value", "provenance.provider_versions")
    inventory = [
        {
            "relative_path": name,
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size_bytes": len(payload),
        }
        for name, payload in sorted(artifacts.items())
    ]
    return {
        "schema_version": "causalmove-synthetic-evidence-bundle-v1",
        "evidence_status": EVIDENCE_STATUS,
        "input_sha256s": list(
            _validate_hashes(provenance.input_sha256s, "provenance.input_sha256s")
        ),
        "provider_versions": list(provider_versions),
        "adapter_versions": list(
            _validate_controlled_values(
                provenance.adapter_versions, "provenance.adapter_versions"
            )
        ),
        "event_versions": list(
            _validate_controlled_values(
                provenance.event_versions, "provenance.event_versions"
            )
        ),
        "feature_versions": list(
            _validate_controlled_values(
                provenance.feature_versions, "provenance.feature_versions"
            )
        ),
        "registry_sha256s": list(
            _validate_hashes(
                provenance.registry_sha256s, "provenance.registry_sha256s"
            )
        ),
        "source_tree_sha256": provenance.source_tree_sha256,
        "execution_environment": execution_environment,
        "warnings": list(
            _validate_controlled_values(provenance.warnings, "provenance.warnings")
        ),
        "failure_codes": list(
            _validate_controlled_values(
                provenance.failure_codes, "provenance.failure_codes"
            )
        ),
        "conversion_reasons": list(
            _validate_controlled_values(
                provenance.conversion_reasons, "provenance.conversion_reasons"
            )
        ),
        "trial_count": provenance.trial_count,
        "batch_created": provenance.batch_created,
        "output_inventory_scope": "artifacts_excluding_bundle_manifest_v1",
        "output_inventory": inventory,
    }


def write_evidence_bundle(
    output_directory: Path,
    artifacts: Mapping[str, bytes],
    provenance: EvidenceProvenance,
) -> Path:
    """Write one new evidence directory without overwriting an earlier run."""

    if not isinstance(output_directory, Path) or not isinstance(artifacts, Mapping):
        _fail("invalid_type", "evidence_bundle")
    if output_directory.exists() or output_directory.is_symlink():
        _fail("output_exists", "output_directory")
    checked: dict[str, bytes] = {}
    for name, payload in artifacts.items():
        if (
            not isinstance(name, str)
            or ARTIFACT_NAME_PATTERN.fullmatch(name) is None
            or name == "bundle_manifest.json"
        ):
            _fail("invalid_artifact_name", "artifacts")
        if not isinstance(payload, bytes):
            _fail("invalid_artifact_payload", "artifacts")
        checked[name] = payload
    if not checked:
        _fail("empty_artifacts", "artifacts")
    manifest_bytes = canonical_json_bytes(_manifest_mapping(checked, provenance))
    try:
        output_directory.mkdir(parents=False, exist_ok=False)
        for name, payload in sorted(checked.items()):
            (output_directory / name).write_bytes(payload)
        (output_directory / "bundle_manifest.json").write_bytes(manifest_bytes)
    except FileExistsError:
        _fail("output_exists", "output_directory")
    except OSError:
        _fail("output_write_error", "output_directory")
    return output_directory
