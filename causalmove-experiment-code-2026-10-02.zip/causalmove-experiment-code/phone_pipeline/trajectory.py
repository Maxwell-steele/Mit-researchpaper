"""Provider-independent trajectory records for the phone pipeline."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

from .errors import TrajectoryValidationError


SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
ANATOMICAL_SIDES = frozenset({"left", "right", "midline", "not_applicable"})
MISSING_REASONS = frozenset({"occluded", "provider_missing"})


def _fail(code: str, field: str) -> None:
    raise TrajectoryValidationError(code, field)


def _finite_number(value: object, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed):
        _fail("nonfinite_coordinate", field)
    return parsed


def _nonempty_string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("invalid_string", field)
    return value


@dataclass(frozen=True)
class TrajectoryRecord:
    trial_id: str
    frame_index: int
    timestamp_s: float
    landmark_name: str
    anatomical_side: str
    x: float | None
    y: float | None
    z: float | None
    unit: str
    confidence: float | None
    coordinate_frame_id: str
    source_export_sha256: str
    adapter_version: str
    missing_reason: str | None

    def __post_init__(self) -> None:
        _nonempty_string(self.trial_id, "record.trial_id")
        if isinstance(self.frame_index, bool) or not isinstance(self.frame_index, int):
            _fail("invalid_frame_index", "record.frame_index")
        if self.frame_index < 0:
            _fail("invalid_frame_index", "record.frame_index")
        timestamp = _finite_number(self.timestamp_s, "record.timestamp_s")
        if timestamp < 0.0:
            _fail("invalid_timestamp", "record.timestamp_s")
        _nonempty_string(self.landmark_name, "record.landmark_name")
        if self.anatomical_side not in ANATOMICAL_SIDES:
            _fail("invalid_anatomical_side", "record.anatomical_side")
        if self.unit != "m":
            _fail("invalid_unit", "record.unit")
        _nonempty_string(self.coordinate_frame_id, "record.coordinate_frame_id")
        if not isinstance(self.source_export_sha256, str) or SHA256_PATTERN.fullmatch(
            self.source_export_sha256
        ) is None:
            _fail("invalid_sha256", "record.source_export_sha256")
        _nonempty_string(self.adapter_version, "record.adapter_version")

        coordinates = (self.x, self.y, self.z)
        missing_count = sum(value is None for value in coordinates)
        if missing_count not in {0, 3}:
            _fail("partial_coordinates", "record.coordinates")
        if missing_count == 3:
            if self.missing_reason not in MISSING_REASONS:
                _fail("missing_reason_required", "record.missing_reason")
            if self.confidence is not None:
                _fail("confidence_on_missing_coordinates", "record.confidence")
            return

        for axis, value in zip(("x", "y", "z"), coordinates, strict=True):
            _finite_number(value, f"record.{axis}")
        if self.missing_reason is not None:
            _fail("unexpected_missing_reason", "record.missing_reason")
        if self.confidence is not None:
            confidence = _finite_number(self.confidence, "record.confidence")
            if confidence < 0.0 or confidence > 1.0:
                _fail("invalid_confidence", "record.confidence")


@dataclass(frozen=True)
class NormalizationSidecar:
    provider_id: str
    provider_version: str
    source_schema_version: str
    source_landmark_names: tuple[str, ...]
    landmark_mapping: tuple[tuple[str, str], ...]
    source_unit: str
    unit_scale_to_m: float
    axis_transform: tuple[str, str, str]
    timebase_source: str
    time_scale_to_s: float
    unsupported_fields: tuple[str, ...]
    warnings: tuple[str, ...]

    def __post_init__(self) -> None:
        for field, value in (
            ("provider_id", self.provider_id),
            ("provider_version", self.provider_version),
            ("source_schema_version", self.source_schema_version),
            ("source_unit", self.source_unit),
            ("timebase_source", self.timebase_source),
        ):
            _nonempty_string(value, f"sidecar.{field}")
        for field, value in (
            ("unit_scale_to_m", self.unit_scale_to_m),
            ("time_scale_to_s", self.time_scale_to_s),
        ):
            parsed = _finite_number(value, f"sidecar.{field}")
            if parsed <= 0.0:
                _fail("invalid_scale", f"sidecar.{field}")


@dataclass(frozen=True)
class CanonicalTrajectory:
    records: tuple[TrajectoryRecord, ...]
    sidecar: NormalizationSidecar

    def __post_init__(self) -> None:
        if not self.records:
            _fail("empty_trajectory", "trajectory.records")
        keys = tuple((record.frame_index, record.landmark_name) for record in self.records)
        if len(set(keys)) != len(keys):
            _fail("duplicate_frame_landmark", "trajectory.records")

        frame_indices = sorted({record.frame_index for record in self.records})
        if frame_indices != list(range(len(frame_indices))):
            _fail("noncontiguous_frames", "trajectory.records")

        frame_timestamps: list[float] = []
        expected_landmarks: frozenset[str] | None = None
        for frame_index in frame_indices:
            frame_records = tuple(
                record for record in self.records if record.frame_index == frame_index
            )
            landmarks = frozenset(record.landmark_name for record in frame_records)
            if expected_landmarks is None:
                expected_landmarks = landmarks
            elif landmarks != expected_landmarks:
                _fail("incomplete_frame", "trajectory.records")
            timestamps = {record.timestamp_s for record in frame_records}
            if len(timestamps) != 1:
                _fail("frame_time_mismatch", "trajectory.records")
            frame_timestamps.append(next(iter(timestamps)))

        if any(
            later <= earlier
            for earlier, later in zip(frame_timestamps, frame_timestamps[1:])
        ):
            _fail("nonincreasing_time", "trajectory.records")

        for attribute, code in (
            ("trial_id", "mixed_trial_id"),
            ("coordinate_frame_id", "mixed_coordinate_frame"),
            ("source_export_sha256", "mixed_source_hash"),
            ("adapter_version", "mixed_adapter_version"),
        ):
            if len({getattr(record, attribute) for record in self.records}) != 1:
                _fail(code, "trajectory.records")

        mapped_landmarks = {target for _, target in self.sidecar.landmark_mapping}
        if expected_landmarks != mapped_landmarks:
            _fail("landmark_mapping_mismatch", "trajectory.sidecar")
