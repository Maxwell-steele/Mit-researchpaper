"""Fail-closed bridge from phone feature records to the policy prototype."""

from __future__ import annotations

import hashlib
import importlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, NoReturn

from .errors import FeatureValidationError, TrialBatchValidationError
from .features import TrialFeatureBundle, validate_trial_feature_bundle_integrity
from .manifest import TrialManifest


LOAD_REGISTRY_SCHEMA_VERSION = "causalmove-synthetic-test-load-registry-v1"
SYNTHETIC_LOAD_REGISTRY_ID = "SYNTHETIC_TEST_LOAD_V1"
SYNTHETIC_EVIDENCE_STATUS = "SYNTHETIC_SOFTWARE_ONLY"
SYNTHETIC_LOAD_MEASURE = "synthetic_test_load"
APPROVED_SYNTHETIC_LOAD_REGISTRY_SHA256 = (
    "e64f41cdb7d5cffd25df01d187e04dee7b47928ce6fe098fdb1a5961ee04ae20"
)
APPROVED_SYNTHETIC_LOAD_UNIT = "N*m/kg"
APPROVED_SYNTHETIC_LOAD_MINIMUM = -1.0
APPROVED_SYNTHETIC_LOAD_MAXIMUM = 1.0
APPROVED_SYNTHETIC_LOAD_PROCESSING_VERSION = "synthetic-test-load-v1"
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
LOAD_REGISTRY_FIELDS = frozenset(
    {
        "schema_version",
        "registry_id",
        "test_only",
        "evidence_status",
        "measure_name",
        "unit",
        "minimum",
        "maximum",
        "processing_version",
    }
)


class _DuplicateFieldError(ValueError):
    pass


def _fail(code: str, field: str) -> NoReturn:
    raise TrialBatchValidationError(code, field)


def _reject_duplicate_fields(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateFieldError
        result[key] = value
    return result


def _string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("invalid_string", field)
    return value


def _number(value: object, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _fail("invalid_number", field)
    parsed = float(value)
    if not math.isfinite(parsed):
        _fail("invalid_number", field)
    return parsed


def _hash_payload(values: Mapping[str, object]) -> str:
    payload = json.dumps(
        values,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class LoadRegistryStatus:
    """Status of a separately registered phone-load measurement."""

    registry_id: str
    registry_sha256: str
    test_only: bool
    evidence_status: str
    measure_name: str | None
    unit: str | None
    minimum: float | None
    maximum: float | None
    processing_version: str | None
    measure_available: bool


@dataclass(frozen=True)
class SyntheticTestLoadRecord:
    """A non-scientific load value used only to exercise software wiring."""

    trial_id: str
    measure_name: str
    value: float
    uncertainty: float
    unit: str
    source_hashes: tuple[str, ...]
    processing_version: str
    registry_id: str
    registry_sha256: str
    evidence_status: str
    record_hash: str


@dataclass(frozen=True)
class CalibrationTrialInput:
    """One exact manifest, its feature bundle, and optional test load record."""

    manifest: TrialManifest
    features: TrialFeatureBundle
    synthetic_test_load: SyntheticTestLoadRecord | None


@dataclass(frozen=True)
class TrialBatchConversionResult:
    """One all-or-nothing policy-batch conversion result."""

    batch: Any | None
    eligible: bool
    reasons: tuple[str, ...]


def load_synthetic_test_load_registry(
    path: Path, expected_sha256: str
) -> LoadRegistryStatus:
    """Load the one exact, hashed registry that may exercise the test bridge."""

    if not isinstance(path, Path) or not isinstance(expected_sha256, str):
        _fail("invalid_type", "load_registry")
    if SHA256_PATTERN.fullmatch(expected_sha256) is None:
        _fail("invalid_sha256", "load_registry.sha256")
    try:
        payload = path.read_bytes()
    except OSError:
        _fail("registry_read_error", "load_registry")
    digest = hashlib.sha256(payload).hexdigest()
    if digest != expected_sha256:
        _fail("registry_hash_mismatch", "load_registry")
    try:
        raw = json.loads(
            payload.decode("utf-8"), object_pairs_hook=_reject_duplicate_fields
        )
    except _DuplicateFieldError:
        _fail("duplicate_field", "load_registry")
    except (UnicodeDecodeError, json.JSONDecodeError):
        _fail("invalid_json", "load_registry")
    if not isinstance(raw, dict):
        _fail("invalid_type", "load_registry")
    if set(raw) - LOAD_REGISTRY_FIELDS:
        _fail("unknown_field", "load_registry")
    if LOAD_REGISTRY_FIELDS - set(raw):
        _fail("missing_field", "load_registry")
    if digest != APPROVED_SYNTHETIC_LOAD_REGISTRY_SHA256:
        _fail("unapproved_registry_digest", "load_registry")
    if raw["schema_version"] != LOAD_REGISTRY_SCHEMA_VERSION:
        _fail("unsupported_schema", "load_registry.schema_version")
    if raw["registry_id"] != SYNTHETIC_LOAD_REGISTRY_ID:
        _fail("load_registry_not_authorized", "load_registry.registry_id")
    if raw["test_only"] is not True:
        _fail("load_registry_not_authorized", "load_registry.test_only")
    if raw["evidence_status"] != SYNTHETIC_EVIDENCE_STATUS:
        _fail("load_registry_not_authorized", "load_registry.evidence_status")
    if raw["measure_name"] != SYNTHETIC_LOAD_MEASURE:
        _fail("load_registry_not_authorized", "load_registry.measure_name")
    minimum = _number(raw["minimum"], "load_registry.minimum")
    maximum = _number(raw["maximum"], "load_registry.maximum")
    if maximum < minimum:
        _fail("invalid_range", "load_registry")
    return LoadRegistryStatus(
        registry_id=SYNTHETIC_LOAD_REGISTRY_ID,
        registry_sha256=digest,
        test_only=True,
        evidence_status=SYNTHETIC_EVIDENCE_STATUS,
        measure_name=SYNTHETIC_LOAD_MEASURE,
        unit=_string(raw["unit"], "load_registry.unit"),
        minimum=minimum,
        maximum=maximum,
        processing_version=_string(
            raw["processing_version"], "load_registry.processing_version"
        ),
        measure_available=True,
    )


def _authorized_synthetic_registry(registry: object) -> bool:
    return (
        isinstance(registry, LoadRegistryStatus)
        and registry.measure_available is True
        and registry.test_only is True
        and registry.registry_id == SYNTHETIC_LOAD_REGISTRY_ID
        and registry.registry_sha256 == APPROVED_SYNTHETIC_LOAD_REGISTRY_SHA256
        and registry.evidence_status == SYNTHETIC_EVIDENCE_STATUS
        and registry.measure_name == SYNTHETIC_LOAD_MEASURE
        and registry.unit == APPROVED_SYNTHETIC_LOAD_UNIT
        and registry.minimum == APPROVED_SYNTHETIC_LOAD_MINIMUM
        and registry.maximum == APPROVED_SYNTHETIC_LOAD_MAXIMUM
        and registry.processing_version
        == APPROVED_SYNTHETIC_LOAD_PROCESSING_VERSION
    )


def build_synthetic_test_load_record(
    *,
    trial_id: str,
    value: float,
    uncertainty: float,
    source_hashes: tuple[str, ...],
    registry: LoadRegistryStatus,
) -> SyntheticTestLoadRecord:
    """Build one provenance-bound value under the reserved test registry."""

    if not _authorized_synthetic_registry(registry):
        _fail("load_registry_not_authorized", "load_registry")
    parsed_trial_id = _string(trial_id, "trial_id")
    parsed_value = _number(value, "load.value")
    parsed_uncertainty = _number(uncertainty, "load.uncertainty")
    if parsed_uncertainty < 0.0:
        _fail("invalid_uncertainty", "load.uncertainty")
    assert registry.minimum is not None and registry.maximum is not None
    if not registry.minimum <= parsed_value <= registry.maximum:
        _fail("outside_valid_range", "load.value")
    if (
        not isinstance(source_hashes, tuple)
        or not source_hashes
        or any(
            not isinstance(item, str) or SHA256_PATTERN.fullmatch(item) is None
            for item in source_hashes
        )
    ):
        _fail("invalid_source_hash", "load.source_hashes")
    base: dict[str, object] = {
        "trial_id": parsed_trial_id,
        "measure_name": SYNTHETIC_LOAD_MEASURE,
        "value": parsed_value,
        "uncertainty": parsed_uncertainty,
        "unit": registry.unit,
        "source_hashes": source_hashes,
        "processing_version": registry.processing_version,
        "registry_id": registry.registry_id,
        "registry_sha256": registry.registry_sha256,
        "evidence_status": registry.evidence_status,
    }
    return SyntheticTestLoadRecord(**base, record_hash=_hash_payload(base))


def _is_stage_one_synthetic_manifest(manifest: TrialManifest) -> bool:
    synthetic_ids = (
        manifest.athlete_id,
        manifest.session_id,
        manifest.trial_id,
        manifest.pair_id,
    )
    return (
        manifest.study_id == "SYNTHETIC-STUDY"
        and all(value.startswith("SYNTHETIC-") for value in synthetic_ids)
        and manifest.processing_authorization_id.startswith("SYNTHETIC-AUTH-")
        and manifest.intended_output_tier == "r1_controlled_raw"
        and manifest.trajectory_export.provider_id == "synthetic_fixture"
        and manifest.trajectory_export.provider_version == "synthetic-v1"
    )


def _load_record_payload(record: SyntheticTestLoadRecord) -> dict[str, object]:
    return {
        field_name: getattr(record, field_name)
        for field_name in SyntheticTestLoadRecord.__dataclass_fields__
        if field_name != "record_hash"
    }


def _task_score(features: TrialFeatureBundle) -> float | None:
    if not isinstance(features.measurements, tuple):
        return None
    records = tuple(
        record
        for record in features.measurements
        if record.measure_name == "task_performance_score"
        and record.transform_id is None
    )
    if len(records) != 1:
        return None
    record = records[0]
    if (
        not record.measurement_valid
        or record.value is None
        or isinstance(record.value, bool)
        or not isinstance(record.value, (int, float))
        or not math.isfinite(record.value)
        or record.unit != "1"
        or record.intended_analysis_role != "primary_performance"
    ):
        return None
    return record.value


def _validate_trial(
    trial: CalibrationTrialInput, registry: LoadRegistryStatus
) -> tuple[set[str], float | None, float | None]:
    reasons: set[str] = set()
    if not isinstance(trial.manifest, TrialManifest) or not isinstance(
        trial.features, TrialFeatureBundle
    ):
        return {"invalid_trial_input"}, None, None
    manifest = trial.manifest
    features = trial.features
    if not _is_stage_one_synthetic_manifest(manifest):
        reasons.add("synthetic_manifest_required")
    if (
        manifest.phase != "calibration"
        or manifest.personal_update_role != "update_input"
        or manifest.prospective_outcome_role != "not_used"
        or manifest.response_population_role != "not_used"
    ):
        reasons.add("forbidden_trial_role")
    if manifest.replacement_of_trial_id is not None:
        reasons.add("replacement_not_authorized")
    if features.trial_id != manifest.trial_id:
        reasons.add("feature_trial_mismatch")
    try:
        validate_trial_feature_bundle_integrity(features)
    except FeatureValidationError:
        reasons.add("feature_bundle_integrity")
    if (
        features.acquisition_registry_sha256
        != manifest.acquisition_qc_registry_hash
        or features.measure_registry_sha256 != manifest.measure_registry_hash
    ):
        reasons.add("registry_mismatch")
    if (
        not features.calibration_eligible
        or features.ineligibility_reasons
        or features.acquisition_state != "phone_technical_pass"
        or features.acquisition_failure_codes
        or features.task_fidelity_status != "pass"
        or features.safety_related_missingness
    ):
        reasons.add("trial_ineligible")
    score = _task_score(features)
    if score is None:
        reasons.add("performance_measure_unavailable")

    load = trial.synthetic_test_load
    load_value: float | None = None
    if not isinstance(load, SyntheticTestLoadRecord):
        reasons.add("load_record_missing")
    else:
        if load.trial_id != manifest.trial_id:
            reasons.add("load_trial_mismatch")
        if (
            load.registry_id != registry.registry_id
            or load.registry_sha256 != registry.registry_sha256
            or load.processing_version != registry.processing_version
            or load.evidence_status != SYNTHETIC_EVIDENCE_STATUS
            or load.measure_name != SYNTHETIC_LOAD_MEASURE
            or load.unit != registry.unit
        ):
            reasons.add("load_registry_mismatch")
        if (
            not isinstance(load.record_hash, str)
            or SHA256_PATTERN.fullmatch(load.record_hash) is None
            or load.record_hash != _hash_payload(_load_record_payload(load))
        ):
            reasons.add("load_record_hash_mismatch")
        expected_sources = (manifest.trajectory_export.sha256,)
        if load.source_hashes != expected_sources:
            reasons.add("load_source_mismatch")
        if any(record.source_hashes != expected_sources for record in features.measurements):
            reasons.add("feature_source_mismatch")
        load_value_is_numeric = (
            not isinstance(load.value, bool)
            and isinstance(load.value, (int, float))
            and math.isfinite(load.value)
        )
        load_uncertainty_is_valid = (
            not isinstance(load.uncertainty, bool)
            and isinstance(load.uncertainty, (int, float))
            and math.isfinite(load.uncertainty)
            and load.uncertainty >= 0.0
        )
        if (
            not load_value_is_numeric
            or not load_uncertainty_is_valid
            or registry.minimum is None
            or registry.maximum is None
            or (
                load_value_is_numeric
                and not registry.minimum <= load.value <= registry.maximum
            )
        ):
            reasons.add("load_measure_invalid")
        else:
            load_value = load.value
    return reasons, score, load_value


def convert_to_trial_batch(
    trials: tuple[CalibrationTrialInput, ...], load_registry: LoadRegistryStatus
) -> TrialBatchConversionResult:
    """Create a batch only through the reserved synthetic test-load branch."""

    if not isinstance(load_registry, LoadRegistryStatus):
        return TrialBatchConversionResult(None, False, ("invalid_load_registry",))
    if not load_registry.measure_available:
        return TrialBatchConversionResult(None, False, ("load_measure_unavailable",))
    if not _authorized_synthetic_registry(load_registry):
        return TrialBatchConversionResult(
            None, False, ("load_registry_not_authorized",)
        )
    if not isinstance(trials, tuple) or not trials or any(
        not isinstance(trial, CalibrationTrialInput) for trial in trials
    ):
        return TrialBatchConversionResult(None, False, ("invalid_trial_input",))
    if any(
        not isinstance(trial.manifest, TrialManifest)
        or not isinstance(trial.features, TrialFeatureBundle)
        for trial in trials
    ):
        return TrialBatchConversionResult(None, False, ("invalid_trial_input",))

    reasons: set[str] = set()
    outcomes: dict[str, tuple[float | None, float | None]] = {}
    trial_ids: set[str] = set()
    for trial in trials:
        trial_reasons, score, load = _validate_trial(trial, load_registry)
        reasons.update(trial_reasons)
        if trial.manifest.trial_id in trial_ids:
            reasons.add("duplicate_trial_id")
        trial_ids.add(trial.manifest.trial_id)
        outcomes[trial.manifest.trial_id] = (score, load)

    groups: dict[tuple[str, str, int], list[CalibrationTrialInput]] = {}
    for trial in trials:
        manifest = trial.manifest
        groups.setdefault(
            (manifest.athlete_id, manifest.active_cue_id, manifest.block_index), []
        ).append(trial)

    pair_rows: list[tuple[TrialManifest, TrialManifest]] = []
    seen_sequences: dict[str, set[int]] = {}
    athlete_cue_blocks: dict[str, dict[str, set[int]]] = {}
    cue_first_counts: dict[tuple[str, str], int] = {}
    athlete_sports: dict[str, str] = {}
    seen_pair_ids: set[str] = set()
    for _, members in sorted(groups.items()):
        if len(members) != 2:
            reasons.add("pair_member_set")
            continue
        manifests = tuple(member.manifest for member in members)
        by_member = {manifest.pair_member: manifest for manifest in manifests}
        if set(by_member) != {"active", "control"} or len(by_member) != 2:
            reasons.add("pair_member_set")
            continue
        cue = by_member["active"]
        control = by_member["control"]
        shared_fields = (
            "study_id",
            "session_id",
            "athlete_id",
            "sport",
            "task_id",
            "active_cue_id",
            "plant_limb",
            "pair_id",
            "pair_replicate",
            "block_index",
            "pair_sequence_index",
            "phone_configuration_hash",
            "acquisition_qc_registry_hash",
            "measure_registry_hash",
        )
        if any(getattr(cue, name) != getattr(control, name) for name in shared_fields):
            reasons.add("pair_identity_mismatch")
        if cue.trial_id == control.trial_id:
            reasons.add("pair_identity_mismatch")
        if cue.pair_id in seen_pair_ids:
            reasons.add("duplicate_pair_id")
        seen_pair_ids.add(cue.pair_id)
        if (
            cue.assigned_condition_id != cue.active_cue_id
            or control.assigned_condition_id != "CTRL_NEUTRAL_V1"
        ):
            reasons.add("pair_condition_mismatch")
        if {cue.within_pair_period, control.within_pair_period} != {1, 2}:
            reasons.add("pair_period_set")
        pair_rows.append((cue, control))

        athlete = cue.athlete_id
        previous_sport = athlete_sports.setdefault(athlete, cue.sport)
        if previous_sport != cue.sport:
            reasons.add("athlete_sport_mismatch")
        sequence_set = seen_sequences.setdefault(athlete, set())
        if cue.pair_sequence_index in sequence_set:
            reasons.add("duplicate_sequence_index")
        sequence_set.add(cue.pair_sequence_index)
        athlete_cue_blocks.setdefault(athlete, {}).setdefault(
            cue.active_cue_id, set()
        ).add(cue.block_index)
        key = (athlete, cue.active_cue_id)
        cue_first_counts[key] = cue_first_counts.get(key, 0) + int(
            cue.within_pair_period == 1
        )

    reference_cues: set[str] | None = None
    reference_blocks: set[int] | None = None
    for athlete, cue_blocks in athlete_cue_blocks.items():
        cue_set = set(cue_blocks)
        if reference_cues is None:
            reference_cues = cue_set
        elif cue_set != reference_cues:
            reasons.add("incomplete_cue_set")
        athlete_blocks: set[int] | None = None
        for cue, blocks in cue_blocks.items():
            if len(blocks) < 2:
                reasons.add("insufficient_blocks")
            if athlete_blocks is None:
                athlete_blocks = set(blocks)
            elif blocks != athlete_blocks:
                reasons.add("incomplete_cue_block_cells")
            imbalance = abs(2 * cue_first_counts[(athlete, cue)] - len(blocks))
            if imbalance > 1:
                reasons.add("pair_order_imbalance")
        if athlete_blocks is not None:
            if reference_blocks is None:
                reference_blocks = athlete_blocks
            elif athlete_blocks != reference_blocks:
                reasons.add("incomplete_block_set")

    if reasons:
        return TrialBatchConversionResult(None, False, tuple(sorted(reasons)))

    policy = importlib.import_module("prototype.causal_move")
    pairs = []
    for cue, control in pair_rows:
        cue_score, cue_load = outcomes[cue.trial_id]
        control_score, control_load = outcomes[control.trial_id]
        assert cue_score is not None and cue_load is not None
        assert control_score is not None and control_load is not None
        pairs.append(
            policy.TrialPair(
                athlete_id=cue.athlete_id,
                sport=cue.sport,
                cue=cue.active_cue_id,
                block=cue.block_index,
                sequence_index=cue.pair_sequence_index,
                cue_period=cue.within_pair_period,
                control_period=control.within_pair_period,
                cue_outcome=(-cue_score, cue_load),
                control_outcome=(-control_score, control_load),
            )
        )
    return TrialBatchConversionResult(
        batch=policy.TrialBatch(phase="calibration", pairs=tuple(pairs)),
        eligible=True,
        reasons=(),
    )
