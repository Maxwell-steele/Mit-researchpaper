"""Strict parsing for one provider-neutral two-phone trial manifest."""

from __future__ import annotations

import hashlib
import hmac
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, NoReturn

from .errors import ManifestValidationError


SCHEMA_VERSION = "causalmove-phone-trial-v1"
REGISTERED_CAMERA_ROLES = frozenset({"frontal_oblique", "sagittal_oblique"})
REGISTERED_SPORTS = frozenset({"basketball", "soccer", "handball"})
REGISTERED_PHASES = frozenset(
    {
        "screening",
        "reliability_pilot",
        "model_development",
        "calibration",
        "policy_validation",
        "practice",
        "retention",
        "transfer",
    }
)
REGISTERED_ACTIVE_CUES = frozenset(
    {
        "FPA_ALIGN_EXIT_V1",
        "PLANT_OFFSET_REDUCE_V1",
        "BRAKE_EARLIER_V1",
        "TRUNK_TOWARD_EXIT_V1",
    }
)
REGISTERED_CONDITIONS = REGISTERED_ACTIVE_CUES | {"CTRL_NEUTRAL_V1"}
REGISTERED_OUTPUT_TIERS = frozenset(
    {"r1_controlled_raw", "r2_public_analysis", "r3_public_aggregate"}
)
REGISTERED_FACE_STATUSES = frozenset(
    {"not_required_restricted", "blurred_verified", "cropped_verified", "failed"}
)
REGISTERED_AUDIO_STATUSES = frozenset(
    {"absent", "removed_verified", "restricted", "failed"}
)
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")

TOP_LEVEL_FIELDS = frozenset(
    {
        "schema_version",
        "study_id",
        "athlete_id",
        "session_id",
        "trial_id",
        "athlete_record_hash",
        "processing_authorization_id",
        "intended_output_tier",
        "phase",
        "task_id",
        "sport",
        "assigned_condition_id",
        "active_cue_id",
        "plant_limb",
        "pair_id",
        "pair_replicate",
        "block_index",
        "pair_member",
        "pair_sequence_index",
        "within_pair_period",
        "previous_cue_id",
        "washout_trial_ids",
        "replacement_of_trial_id",
        "personal_update_role",
        "prospective_outcome_role",
        "response_population_role",
        "phone_configuration_hash",
        "acquisition_qc_registry_hash",
        "measure_registry_hash",
        "views",
        "trajectory_export",
    }
)
VIEW_FIELDS = frozenset(
    {
        "camera_role",
        "video_uri",
        "sha256",
        "device_id",
        "clock_domain",
        "sync_event_id",
        "intrinsic_calibration_id",
        "extrinsic_calibration_id",
        "face_deidentification_status",
        "audio_status",
    }
)
TRAJECTORY_EXPORT_FIELDS = frozenset(
    {
        "provider_id",
        "provider_version",
        "file_uri",
        "sha256",
        "coordinate_frame_id",
    }
)


@dataclass(frozen=True)
class ViewManifest:
    camera_role: str
    video_uri: str
    sha256: str
    device_id: str
    clock_domain: str
    sync_event_id: str
    intrinsic_calibration_id: str
    extrinsic_calibration_id: str
    face_deidentification_status: str
    audio_status: str


@dataclass(frozen=True)
class TrajectoryExportManifest:
    provider_id: str
    provider_version: str
    file_uri: str
    sha256: str
    coordinate_frame_id: str


@dataclass(frozen=True)
class TrialManifest:
    schema_version: str
    study_id: str
    athlete_id: str
    session_id: str
    trial_id: str
    athlete_record_hash: str
    processing_authorization_id: str
    intended_output_tier: str
    phase: str
    task_id: str
    sport: str
    assigned_condition_id: str
    active_cue_id: str
    plant_limb: str
    pair_id: str
    pair_replicate: int
    block_index: int
    pair_member: str
    pair_sequence_index: int
    within_pair_period: int
    previous_cue_id: str | None
    washout_trial_ids: tuple[str, ...]
    replacement_of_trial_id: str | None
    personal_update_role: str
    prospective_outcome_role: str
    response_population_role: str
    phone_configuration_hash: str
    acquisition_qc_registry_hash: str
    measure_registry_hash: str
    views: tuple[ViewManifest, ViewManifest]
    trajectory_export: TrajectoryExportManifest


@dataclass(frozen=True)
class VerifiedFile:
    """One hash-verified controlled input with a non-public resolved path."""

    relative_uri: str
    sha256: str
    size_bytes: int
    resolved_path: Path = field(repr=False)


@dataclass(frozen=True)
class VerifiedManifestFiles:
    views: tuple[VerifiedFile, VerifiedFile]
    trajectory_export: VerifiedFile


@dataclass(frozen=True)
class VerifiedTrialManifest:
    manifest: TrialManifest
    manifest_sha256: str
    files: VerifiedManifestFiles


class _DuplicateFieldError(ValueError):
    def __init__(self, field: str) -> None:
        self.field = field
        super().__init__(field)


def _reject_duplicate_fields(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateFieldError(key)
        result[key] = value
    return result


def _fail(code: str, field: str) -> NoReturn:
    raise ManifestValidationError(code, field)


def _mapping(value: object, field: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        _fail("invalid_type", field)
    return value


def _exact_fields(
    value: Mapping[str, object], expected: frozenset[str], field: str
) -> None:
    unknown = sorted(set(value) - expected)
    if unknown:
        _fail("unknown_field", field)
    missing = sorted(expected - set(value))
    if missing:
        _fail("missing_field", f"{field}.{missing[0]}")


def _string(
    value: object,
    field: str,
    *,
    allowed: frozenset[str] | None = None,
) -> str:
    if not isinstance(value, str):
        _fail("invalid_type", field)
    if not value:
        _fail("empty_value", field)
    if allowed is not None and value not in allowed:
        _fail("invalid_value", field)
    return value


def _optional_string(value: object, field: str) -> str | None:
    if value is None:
        return None
    return _string(value, field)


def _integer(value: object, field: str, *, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _fail("invalid_type", field)
    if value < minimum:
        _fail("invalid_integer_range", field)
    return value


def _sha256(value: object, field: str) -> str:
    parsed = _string(value, field)
    if SHA256_PATTERN.fullmatch(parsed) is None:
        _fail("invalid_sha256", field)
    return parsed


def _string_list(value: object, field: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        _fail("invalid_type", field)
    result: list[str] = []
    for index, item in enumerate(value):
        result.append(_string(item, f"{field}[{index}]"))
    if len(set(result)) != len(result):
        _fail("duplicate_value", field)
    return tuple(result)


def _parse_view(value: object, index: int) -> ViewManifest:
    field = f"manifest.views[{index}]"
    mapping = _mapping(value, field)
    _exact_fields(mapping, VIEW_FIELDS, field)
    return ViewManifest(
        camera_role=_string(
            mapping["camera_role"],
            f"{field}.camera_role",
            allowed=REGISTERED_CAMERA_ROLES,
        ),
        video_uri=_string(mapping["video_uri"], f"{field}.video_uri"),
        sha256=_sha256(mapping["sha256"], f"{field}.sha256"),
        device_id=_string(mapping["device_id"], f"{field}.device_id"),
        clock_domain=_string(mapping["clock_domain"], f"{field}.clock_domain"),
        sync_event_id=_string(mapping["sync_event_id"], f"{field}.sync_event_id"),
        intrinsic_calibration_id=_string(
            mapping["intrinsic_calibration_id"],
            f"{field}.intrinsic_calibration_id",
        ),
        extrinsic_calibration_id=_string(
            mapping["extrinsic_calibration_id"],
            f"{field}.extrinsic_calibration_id",
        ),
        face_deidentification_status=_string(
            mapping["face_deidentification_status"],
            f"{field}.face_deidentification_status",
            allowed=REGISTERED_FACE_STATUSES,
        ),
        audio_status=_string(
            mapping["audio_status"],
            f"{field}.audio_status",
            allowed=REGISTERED_AUDIO_STATUSES,
        ),
    )


def _parse_trajectory_export(value: object) -> TrajectoryExportManifest:
    field = "manifest.trajectory_export"
    mapping = _mapping(value, field)
    _exact_fields(mapping, TRAJECTORY_EXPORT_FIELDS, field)
    return TrajectoryExportManifest(
        provider_id=_string(mapping["provider_id"], f"{field}.provider_id"),
        provider_version=_string(
            mapping["provider_version"], f"{field}.provider_version"
        ),
        file_uri=_string(mapping["file_uri"], f"{field}.file_uri"),
        sha256=_sha256(mapping["sha256"], f"{field}.sha256"),
        coordinate_frame_id=_string(
            mapping["coordinate_frame_id"], f"{field}.coordinate_frame_id"
        ),
    )


def parse_trial_manifest(payload: bytes) -> TrialManifest:
    """Parse exact UTF-8 JSON without echoing input values on failure."""

    if not isinstance(payload, bytes):
        _fail("invalid_type", "payload")
    try:
        text = payload.decode("utf-8")
        raw = json.loads(text, object_pairs_hook=_reject_duplicate_fields)
    except _DuplicateFieldError:
        _fail("duplicate_field", "manifest")
    except (UnicodeDecodeError, json.JSONDecodeError):
        _fail("invalid_json", "manifest")

    mapping = _mapping(raw, "manifest")
    _exact_fields(mapping, TOP_LEVEL_FIELDS, "manifest")

    views_value = mapping["views"]
    if not isinstance(views_value, list):
        _fail("invalid_type", "manifest.views")
    if len(views_value) != 2:
        _fail("view_count", "manifest.views")
    parsed_views = tuple(_parse_view(value, index) for index, value in enumerate(views_value))
    if {view.camera_role for view in parsed_views} != REGISTERED_CAMERA_ROLES:
        _fail("camera_roles", "manifest.views")
    if len({view.device_id for view in parsed_views}) != 2:
        _fail("duplicate_device_id", "manifest.views")
    if len({view.video_uri for view in parsed_views}) != 2:
        _fail("duplicate_view_uri", "manifest.views")
    if len({view.sync_event_id for view in parsed_views}) != 1:
        _fail("sync_event_mismatch", "manifest.views")

    period = _integer(mapping["within_pair_period"], "manifest.within_pair_period", minimum=1)
    if period not in {1, 2}:
        _fail("invalid_value", "manifest.within_pair_period")

    schema_version = _string(mapping["schema_version"], "manifest.schema_version")
    if schema_version != SCHEMA_VERSION:
        _fail("invalid_value", "manifest.schema_version")

    assigned_condition_id = _string(
        mapping["assigned_condition_id"],
        "manifest.assigned_condition_id",
        allowed=REGISTERED_CONDITIONS,
    )
    active_cue_id = _string(
        mapping["active_cue_id"],
        "manifest.active_cue_id",
        allowed=REGISTERED_ACTIVE_CUES,
    )
    pair_member = _string(
        mapping["pair_member"],
        "manifest.pair_member",
        allowed=frozenset({"active", "control"}),
    )
    expected_condition = active_cue_id if pair_member == "active" else "CTRL_NEUTRAL_V1"
    if assigned_condition_id != expected_condition:
        _fail("pair_condition_mismatch", "manifest.assigned_condition_id")

    phase = _string(mapping["phase"], "manifest.phase", allowed=REGISTERED_PHASES)
    personal_update_role = _string(
        mapping["personal_update_role"],
        "manifest.personal_update_role",
        allowed=frozenset({"update_input", "not_used"}),
    )
    prospective_outcome_role = _string(
        mapping["prospective_outcome_role"],
        "manifest.prospective_outcome_role",
        allowed=frozenset({"evaluation", "not_used"}),
    )
    response_population_role = _string(
        mapping["response_population_role"],
        "manifest.response_population_role",
        allowed=frozenset(
            {"population_train", "model_selection", "internal_test", "not_used"}
        ),
    )
    roles = (
        personal_update_role,
        prospective_outcome_role,
        response_population_role,
    )
    if phase in {"screening", "reliability_pilot"}:
        valid_roles = roles == ("not_used", "not_used", "not_used")
    elif phase == "model_development":
        valid_roles = (
            personal_update_role == "not_used"
            and prospective_outcome_role == "not_used"
            and response_population_role != "not_used"
        )
    elif phase == "calibration":
        valid_roles = roles == ("update_input", "not_used", "not_used")
    else:
        valid_roles = roles == ("not_used", "evaluation", "not_used")
    if not valid_roles:
        _fail("phase_role_mismatch", "manifest.phase")

    sport = _string(
        mapping["sport"], "manifest.sport", allowed=REGISTERED_SPORTS
    )
    if sport == "handball" and response_population_role != "not_used":
        _fail("heldout_sport_role_mismatch", "manifest.response_population_role")

    return TrialManifest(
        schema_version=schema_version,
        study_id=_string(mapping["study_id"], "manifest.study_id"),
        athlete_id=_string(mapping["athlete_id"], "manifest.athlete_id"),
        session_id=_string(mapping["session_id"], "manifest.session_id"),
        trial_id=_string(mapping["trial_id"], "manifest.trial_id"),
        athlete_record_hash=_sha256(
            mapping["athlete_record_hash"], "manifest.athlete_record_hash"
        ),
        processing_authorization_id=_string(
            mapping["processing_authorization_id"],
            "manifest.processing_authorization_id",
        ),
        intended_output_tier=_string(
            mapping["intended_output_tier"],
            "manifest.intended_output_tier",
            allowed=REGISTERED_OUTPUT_TIERS,
        ),
        phase=phase,
        task_id=_string(
            mapping["task_id"], "manifest.task_id", allowed=frozenset({"cut_90"})
        ),
        sport=sport,
        assigned_condition_id=assigned_condition_id,
        active_cue_id=active_cue_id,
        plant_limb=_string(
            mapping["plant_limb"],
            "manifest.plant_limb",
            allowed=frozenset({"left", "right"}),
        ),
        pair_id=_string(mapping["pair_id"], "manifest.pair_id"),
        pair_replicate=_integer(
            mapping["pair_replicate"], "manifest.pair_replicate", minimum=1
        ),
        block_index=_integer(
            mapping["block_index"], "manifest.block_index", minimum=0
        ),
        pair_member=pair_member,
        pair_sequence_index=_integer(
            mapping["pair_sequence_index"],
            "manifest.pair_sequence_index",
            minimum=0,
        ),
        within_pair_period=period,
        previous_cue_id=_optional_string(
            mapping["previous_cue_id"], "manifest.previous_cue_id"
        ),
        washout_trial_ids=_string_list(
            mapping["washout_trial_ids"], "manifest.washout_trial_ids"
        ),
        replacement_of_trial_id=_optional_string(
            mapping["replacement_of_trial_id"],
            "manifest.replacement_of_trial_id",
        ),
        personal_update_role=personal_update_role,
        prospective_outcome_role=prospective_outcome_role,
        response_population_role=response_population_role,
        phone_configuration_hash=_sha256(
            mapping["phone_configuration_hash"],
            "manifest.phone_configuration_hash",
        ),
        acquisition_qc_registry_hash=_sha256(
            mapping["acquisition_qc_registry_hash"],
            "manifest.acquisition_qc_registry_hash",
        ),
        measure_registry_hash=_sha256(
            mapping["measure_registry_hash"], "manifest.measure_registry_hash"
        ),
        views=(parsed_views[0], parsed_views[1]),
        trajectory_export=_parse_trajectory_export(mapping["trajectory_export"]),
    )


def _controlled_root(controlled_root: Path) -> tuple[Path, Path]:
    if not isinstance(controlled_root, Path):
        _fail("invalid_type", "controlled_root")
    if controlled_root.is_symlink():
        _fail("symlink_not_allowed", "controlled_root")
    try:
        lexical_root = controlled_root.absolute()
        resolved_root = controlled_root.resolve(strict=True)
    except (FileNotFoundError, OSError):
        _fail("controlled_root_unavailable", "controlled_root")
    if not resolved_root.is_dir():
        _fail("controlled_root_not_directory", "controlled_root")
    return lexical_root, resolved_root


def _relative_uri(uri: str, field_name: str) -> Path:
    if "\\" in uri or "\x00" in uri:
        _fail("invalid_uri", field_name)
    relative = Path(uri)
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        _fail("path_outside_controlled_root", field_name)
    return relative


def _reject_symlink_components(
    lexical_root: Path, relative: Path, field_name: str
) -> None:
    candidate = lexical_root
    for part in relative.parts:
        candidate = candidate / part
        if candidate.is_symlink():
            _fail("symlink_not_allowed", field_name)


def _resolve_controlled_file(
    controlled_root: Path, uri: str, field_name: str
) -> tuple[str, Path]:
    lexical_root, resolved_root = _controlled_root(controlled_root)
    relative = _relative_uri(uri, field_name)
    _reject_symlink_components(lexical_root, relative, field_name)
    candidate = lexical_root / relative
    try:
        resolved = candidate.resolve(strict=True)
    except (FileNotFoundError, OSError):
        _fail("file_not_found", field_name)
    try:
        resolved.relative_to(resolved_root)
    except ValueError:
        _fail("path_outside_controlled_root", field_name)
    if not resolved.is_file():
        _fail("not_regular_file", field_name)
    return relative.as_posix(), resolved


def _sha256_file(path: Path, field_name: str) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
    except OSError:
        _fail("file_read_error", field_name)
    return digest.hexdigest()


def _verify_file(
    controlled_root: Path,
    uri: str,
    expected_sha256: str,
    field_name: str,
) -> VerifiedFile:
    relative_uri, resolved = _resolve_controlled_file(
        controlled_root, uri, field_name
    )
    digest = _sha256_file(resolved, field_name)
    if not hmac.compare_digest(digest, expected_sha256):
        _fail("sha256_mismatch", f"{field_name}.sha256")
    try:
        size_bytes = resolved.stat().st_size
    except OSError:
        _fail("file_read_error", field_name)
    return VerifiedFile(
        relative_uri=relative_uri,
        sha256=digest,
        size_bytes=size_bytes,
        resolved_path=resolved,
    )


def verify_manifest_files(
    manifest: TrialManifest, controlled_root: Path
) -> VerifiedManifestFiles:
    """Verify all three referenced inputs without disclosing controlled paths."""

    if not isinstance(manifest, TrialManifest):
        _fail("invalid_type", "manifest")
    if any(view.face_deidentification_status == "failed" for view in manifest.views):
        _fail("deidentification_failed", "manifest.views")
    if any(view.audio_status == "failed" for view in manifest.views):
        _fail("audio_processing_failed", "manifest.views")
    verified_views = tuple(
        _verify_file(
            controlled_root,
            view.video_uri,
            view.sha256,
            f"manifest.views[{index}].video_uri",
        )
        for index, view in enumerate(manifest.views)
    )
    trajectory = _verify_file(
        controlled_root,
        manifest.trajectory_export.file_uri,
        manifest.trajectory_export.sha256,
        "manifest.trajectory_export.file_uri",
    )
    return VerifiedManifestFiles(
        views=(verified_views[0], verified_views[1]),
        trajectory_export=trajectory,
    )


def _require_stage_one_synthetic_manifest(manifest: TrialManifest) -> None:
    synthetic_ids = (
        manifest.athlete_id,
        manifest.session_id,
        manifest.trial_id,
        manifest.pair_id,
    )
    authorized = (
        manifest.study_id == "SYNTHETIC-STUDY"
        and all(value.startswith("SYNTHETIC-") for value in synthetic_ids)
        and manifest.processing_authorization_id.startswith("SYNTHETIC-AUTH-")
        and manifest.intended_output_tier == "r1_controlled_raw"
        and manifest.trajectory_export.provider_id == "synthetic_fixture"
        and manifest.trajectory_export.provider_version == "synthetic-v1"
    )
    if not authorized:
        _fail("real_data_not_authorized", "manifest")


def load_and_verify_trial_manifest(
    manifest_path: Path, controlled_root: Path
) -> VerifiedTrialManifest:
    """Load one controlled manifest, parse it, and verify every referenced file."""

    if not isinstance(manifest_path, Path):
        _fail("invalid_type", "manifest_path")
    lexical_root, _ = _controlled_root(controlled_root)
    try:
        relative_manifest = manifest_path.absolute().relative_to(lexical_root)
    except ValueError:
        _fail("path_outside_controlled_root", "manifest_path")
    relative_uri, resolved_manifest = _resolve_controlled_file(
        controlled_root,
        relative_manifest.as_posix(),
        "manifest_path",
    )
    del relative_uri
    try:
        payload = resolved_manifest.read_bytes()
    except OSError:
        _fail("file_read_error", "manifest_path")
    manifest = parse_trial_manifest(payload)
    _require_stage_one_synthetic_manifest(manifest)
    return VerifiedTrialManifest(
        manifest=manifest,
        manifest_sha256=hashlib.sha256(payload).hexdigest(),
        files=verify_manifest_files(manifest, controlled_root),
    )
