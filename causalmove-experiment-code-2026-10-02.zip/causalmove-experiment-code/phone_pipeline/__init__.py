"""Local, provider-neutral scaffolding for CausalMove phone inputs.

This package is synthetic-software-only. It is not a validated measurement
system and must not be used to recommend movement cues to athletes.
"""

from .errors import ManifestValidationError
from .manifest import (
    TrialManifest,
    VerifiedTrialManifest,
    load_and_verify_trial_manifest,
    parse_trial_manifest,
    verify_manifest_files,
)

__all__ = (
    "ManifestValidationError",
    "TrialManifest",
    "VerifiedTrialManifest",
    "load_and_verify_trial_manifest",
    "parse_trial_manifest",
    "verify_manifest_files",
)
