# Machine-Learning Evidence and Ablation Plan

## Question the ML component must answer

Randomized cue probes already reveal some athlete-specific response. A reviewer can therefore ask whether a hierarchical model or phone-derived context adds anything beyond choosing the cue with the best observed sample mean. The paper must answer that question directly.

The main scientific claim remains policy-level and prospective:

> Does the frozen athlete-specific response policy choose a better eligible cue than the frozen population ranking, while meeting the registered load requirement?

Model accuracy is supporting evidence. It cannot replace the randomized policy comparison.

## Frozen model ladder

Every method receives the same development athletes, cue versions, outcomes, athlete-level folds, target-construction rules, candidate support, and evaluation blocks. A method cannot gain an advantage through a different safety screen or easier opportunity to recommend.

| ID | Method | Purpose | Permitted claim |
|---|---|---|---|
| `M0_POP` | Frozen population cue order applied to the common athlete-specific eligible set | Primary policy comparator | Whether personalization improves on one-size-fits-all ranking |
| `M1_PERSONAL_RAW` | Rank cues by that athlete's randomized calibration sample means, without population pooling or video context | Strong non-ML personalization baseline | Whether the model adds value beyond noisy within-athlete A/B estimates |
| `M2_HIER_NO_VIDEO` | Hierarchical multi-output response model using cue assignment and permitted non-video baseline variables, but no phone-derived movement features | Partial-pooling ablation | Whether shrinkage across athletes improves prediction and ranking |
| `M3_FULL` | Frozen hierarchical multi-output model with registered phone-derived pre-assignment and calibration features | Main CausalMove model | Whether video-conditioned personalized ranking has prospective policy value |
| `M4_RANDOM_ELIGIBLE` | Uniform random choice from the same eligible cue set | Diagnostic lower baseline | Whether the guard alone creates apparent performance value |

An expert-coach choice is useful only if coach availability, blinding, and an additional randomized validation action are feasible. It must not be inserted after outcomes are inspected.

## Separation of confirmatory and diagnostic evidence

### Confirmatory prospective evidence

The registered acute crossover delivers `M3_FULL`, `M0_POP`, and matched neutral instruction. It estimates:

1. active recommendation coverage for `M3_FULL`;
2. `M3_FULL` minus neutral on the registered load outcome;
3. `M3_FULL` minus `M0_POP` on the registered performance score.

These are the three gates in the abstract. Identical planned actions are collected once and mapped to both policy labels with an exact zero contrast.

### Development-only ablation evidence

`M1_PERSONAL_RAW`, `M2_HIER_NO_VIDEO`, and `M4_RANDOM_ELIGIBLE` are compared on development athletes using outer athlete-held-out folds and temporally unseen B-val blocks. Their results are diagnostic unless their actions are also prospectively randomized. Do not describe a shadow-policy comparison as a causal athlete benefit.

No prospective outcome may be used to choose the model ladder, features, hyperparameters, thresholds, or favorable ablation.

## Evaluation contract

### Prediction and interval quality

Report separately for performance and load:

- mean absolute error and root mean squared error on unseen athlete-block means;
- signed calibration error;
- empirical coverage and average width of the registered predictive bounds;
- Brier score and reliability curve only for quantities still described as probabilities;
- results by cue and sport with athlete-level uncertainty.

Frame- or trial-level confidence intervals are prohibited. Resampling and folds use athletes as the independent unit.

### Ranking and decision quality

On development-only outer folds, report:

- top-cue agreement with the best eligible action on unseen blocks;
- regret relative to the best eligible unseen action;
- recommendation coverage and abstention;
- false load clearance and false performance benefit with registered exact bounds;
- pairwise action concordance among `M0` through `M4`;
- performance conditional on recommendation and unconditional policy value, with both denominators shown.

If a method always abstains, its conditional outcome is undefined rather than zero. Unconditional policy value retains abstention as the neutral action.

## Four ablations that matter

### 1. Does partial pooling help?

Compare `M2_HIER_NO_VIDEO` with `M1_PERSONAL_RAW` on the same held-out athletes and blocks. The model earns a shrinkage claim only if it improves unseen-block error or regret without materially increasing false clearance.

### 2. Do phone movement features help?

Compare `M3_FULL` with `M2_HIER_NO_VIDEO`. The phone layer earns an incremental-prediction claim only if the difference and its athlete-level uncertainty are reported. Pose accuracy alone is not evidence of decision value.

### 3. Does joint load modeling change decisions?

Compare the full constrained policy with a performance-only shadow policy. Report which athletes or cues the load constraint removes and their unseen reference loads. The performance-only policy is never delivered when it violates the registered safety process.

### 4. Does abstention create the apparent gain?

Report unconditional policy value, active recommendation coverage, and conditional value together. Compare `M3_FULL` with `M4_RANDOM_ELIGIBLE` under the same guard. A high conditional gain with negligible coverage is not a successful coaching technology.

## Kill and simplification rules

- If `M3_FULL` does not beat `M0_POP` on the prospective registered outcome, do not claim that personalized AI helps athletes.
- If `M3_FULL` does not improve on `M1_PERSONAL_RAW` or `M2_HIER_NO_VIDEO` in locked development ablations, remove the unsupported ML-complexity claim and report the simpler selector.
- If phone features do not improve decision-relevant prediction or action agreement, do not claim the phone model adds personalization value. Phones may remain a lower-cost measurement interface if their agreement gate passes.
- If the load-constrained policy rarely recommends, do not hide this behind conditional results. Improve measurement reliability or redesign the study in a new preregistration.
- If handball performance differs materially from development sports, report transport failure or uncertainty rather than retuning on held-out outcomes.

## Minimal paper presentation

The abstract names only `M3_FULL` and `M0_POP`. The manuscript uses one ablation table:

| Method | Unseen performance MAE | Unseen load MAE | Regret | Coverage | Load false-clearance UCB |
|---|---:|---:|---:|---:|---:|
| Population | [result] | [result] | [result] | [result] | [result] |
| Personal raw | [result] | [result] | [result] | [result] | [result] |
| Hierarchical, no video | [result] | [result] | [result] | [result] | [result] |
| Full CausalMove | [result] | [result] | [result] | [result] | [result] |
| Random eligible | [result] | [result] | [result] | [result] | [result] |

The main table still reports the three prospective gates. This keeps the story centered on one coaching decision while making the contribution of ML falsifiable.
