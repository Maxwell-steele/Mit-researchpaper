# Public Data Integration Plan

## Decision

No verified public dataset contains the full CausalMove evidence chain:

> synchronized two-phone RGB + 90-degree cutting + laboratory kinetics + randomized corrective cues + prospective athlete outcomes.

Public data can accelerate the perception and physics layers. It cannot supply the paper's causal cue-response labels or prove that the recommendation helps athletes. The primary intervention dataset must therefore be newly collected under the registered protocol.

## Recommended stack

| Priority | Dataset | Verified role | Access and constraint | Explicit non-claim |
|---|---|---|---|---|
| 1 | [OpenCap laboratory validation](https://simtk.org/frs/?group_id=2385), [paper](https://doi.org/10.1371/journal.pcbi.1011462) | Start the two-phone perception pipeline. Evaluate event timing, 3D kinematics, ground-reaction force, and joint-moment estimation using participant-held-out splits and two of the available iPhone views. | Immediate approximately 19 GB video-inclusive download; Apache 2.0. Ten adults, five iPhones, optical motion capture, force plates, and EMG. | No cutting, athlete cohort, reactive decision, or randomized cue response. |
| 2 | [MMVP](https://metaverse-ai-lab-thu.github.io/MMVP-Dataset/), [paper](https://doi.org/10.48550/arXiv.2403.17610) | Pretrain foot-contact, pressure-distribution, and foot-sliding representations from RGB-D and pressure insoles. Side-stepping provides the closest public motion family in this set. | Request-gated, noncommercial, no redistribution. Sixteen participants, official 13/3 participant split, more than 44,000 frames. | One RGB-D camera rather than two phones; no optical reference, force-plate joint moments, exact 90-degree cut, or cue intervention. |
| 3 | [BadmintonGRF](https://github.com/KenyaNiu/BadmintonGRF), [paper](https://doi.org/10.48550/arXiv.2605.01876), [data record](https://doi.org/10.5281/zenodo.19277566) | Athlete-domain fine-tuning for impact timing and pose-to-vertical-GRF prediction under court footwork. Use leave-one-athlete-out evaluation. | Tier 1 is described as CC BY-NC 4.0; raw RGB and C3D require controlled access. The Zenodo record was restricted with no downloadable files on September 3, 2026. | No guaranteed cutting label, two-phone input, randomized cue, or validated knee abduction moment. This recent release requires access and metadata verification before use. |
| 4 | [BioCV](https://doi.org/10.15125/BATH-01258), [paper](https://doi.org/10.1038/s41597-024-04077-3) | Controlled-access fallback for independent RGB-to-motion and RGB-to-force validation. Construct registered two-view subsets and hold out participants. | Free request under bespoke ethical terms; no redistribution. Fifteen participants, nine calibrated high-speed RGB cameras, optical motion capture, and four force plates. | Industrial cameras, no cutting, and no intervention labels. |
| 5 | [AddBiomechanics 1.0](https://addbiomechanics.org/download_data.html), [paper](https://doi.org/10.1007/978-3-031-73223-2_27) | Optional physics prior for motion-to-force and motion-to-torque learning before fine-tuning on video-derived pose. | Direct CC BY 4.0 download. 273 participants and more than 24 million motion frames; no RGB. | Cannot validate camera inference, cutting performance, or a coaching response. |

The [UWA planned/unplanned sidestepping release](https://doi.org/10.26182/9gq2-h314) includes processed outcomes from 60 amateur Australian-football players under randomized planned and unplanned trial order. It is a useful external descriptive reference, but its small processed spreadsheet does not include raw video, motion capture, or force records. Planning condition is not a randomized corrective cue, so it cannot train or validate the treatment-response policy.

## Frozen use by system layer

### Layer 1: contact and event detector

- Pretrain on MMVP side-stepping and impact tasks if access is granted.
- Test initial contact and toe-off timing against OpenCap and the new CausalMove laboratory labels.
- Report milliseconds of timing error, failure rate, and uncertainty by task and participant.

### Layer 2: two-view kinematics

- Develop on participant-grouped OpenCap views and, if permitted, BioCV two-view subsets.
- Never split frames or trials from the same participant across training and testing.
- Evaluate the exact registered features, not only generic pose error: foot-to-exit alignment, plant offset, trunk lean, contact events, and uncertainty.
- Cutting-specific accuracy comes only from the new instrumented 90-degree-cut data.

### Layer 3: force and load proxy

- Use AddBiomechanics only as a physics prior and BadmintonGRF only as athlete-domain auxiliary data.
- Fine-tune and test the registered external knee-moment or approved pressure proxy on new cutting trials with reference instruments.
- A model trained on walking, jumping, or badminton impacts cannot be described as validated for cutting knee load without that new test.

### Layer 4: treatment-response policy

- Use no public dataset as if it contained a coaching treatment effect.
- Train only from randomized cue-control pairs with athlete IDs, assigned cue, achieved movement, task performance, measured load, and subsequent prospective outcome.
- Freeze the public-data feature extractor and all preprocessing before prospective policy testing.

## New dataset that the paper must create

The analysis-ready release needs, at minimum:

1. pseudonymous athlete, sport, team-cluster, session, and trial identifiers;
2. synchronized phone-video hashes and consent-compatible derived features;
3. camera, synchronization, frame-loss, occlusion, and task-QC records;
4. randomized cue assignment and allocation probability;
5. exact cue version, target, delivery, and achieved dose stored separately;
6. timing-gate performance and registered failure score;
7. force-plate and 3D kinematic reference outcomes or the approved pressure proxy;
8. model-development role and frozen split hash;
9. planned policy action, realized delivery, abstention reason, and policy hash;
10. prospective outcomes, missingness reason, adverse events, and retention/transfer outcomes.

This new release is the defensible dataset contribution. It is not merely another pose collection: it links a randomized movement instruction to an athlete-specific mechanical and performance response, then records whether the frozen decision helped on a later session.

## Immediate acquisition order

1. Download OpenCap only after confirming storage and compute capacity for the approximately 19 GB archive.
2. Submit the MMVP and BioCV access requests immediately because approval is not instant.
3. Contact the BadmintonGRF authors and verify which athlete-level RGB, C3D, force, and license files are actually available before writing it into a frozen training plan.
4. Do not wait for controlled-access data to run the new-study dry capture and reliability pilot.
5. Record the exact dataset version, retrieval date, license, participant split, excluded files, and SHA-256 manifest for every source used.

No public-data benchmark result may fill the SSAC abstract's personalized-policy Results fields. Those fields require the new prospective athlete cohort.
