# CausalMove Technology Specification

## Product claim under test

CausalMove is a proposed two-phone decision system for a shared athletic task: the 90-degree sidestep cut. It does not classify an athlete as having a good or bad movement style. It is designed to estimate how that athlete responds to a small set of registered coaching cues, recommend at most one cue under a mechanical-load constraint, or abstain.

The scientific question is not whether the system can describe movement. It is whether athlete-specific ranking selects a better action than a frozen population ranking from the same eligible set while satisfying the registered load-proxy requirement.

## Evidence and transport boundary

The study design and reference-prototype scaffold are complete. Real athlete intervention outcomes and validated phone-video measurements have not been collected, so the current artifacts are not deployment evidence and are not ready for SSAC submission.

The development guard has no formal guarantee for held-out handball or another out-of-distribution population. Its calibration argument depends on development-to-deployment exchangeability. Handball is therefore an empirical prospective transport stress test of the already frozen pipeline, not a population covered automatically by the basketball-and-soccer guard.

## Research and field modes

| Mode | Inputs | Reference instruments | Permitted output |
|---|---|---|---|
| Measurement development | Two synchronized phone videos plus force plates and validated 3D kinematics | Required | Feature estimates, uncertainty, and failure reason |
| Cue-response development | Randomized cue-control pairs plus reference outcomes | Required | Population response prior and population cue ranking |
| Prospective validation | Phone videos and that athlete's randomized calibration data | Reference outcomes sealed until decision lock | One registered cue and target, or abstention |
| Later field deployment | Two phone videos and a completed field calibration | None during use | One registered cue and target, or abstention |

Field deployment is not claimed unless a pre-pilot candidate configuration passes the registered pilot acceptance rule and phone-only decisions then agree with the reference-instrument pipeline inside the frozen decision tolerance during prospective evaluation.

## End-to-end system

```mermaid
flowchart LR
    A[Two synchronized phones] --> B[Technical acquisition QC]
    B -->|usable acquisition| C[Pose, contact, and event estimation]
    B -->|technical failure| Q[Retain technical-missing attempt]
    Q --> R[Apply only an approved phase-specific replacement rule]
    R --> S{Required policy inputs complete?}
    S -->|yes| E
    S -->|no| Z[Abstain with reason]
    C --> D[Performance, load-proxy, cue-dose, and task-fidelity features]
    D -->|uncertainty acceptable| E[Randomized cue-response update]
    D -->|uncertainty too high| Z
    E --> F[Personal benefit and load model scores]
    F --> G{Registered eligibility conditions pass?}
    G -->|yes| H[Select highest-value eligible cue]
    G -->|no| Z
    H --> I[Coach delivers exact registered cue]
    I --> J[Independent prospective outcome block]
    J --> K[Locked policy-value analysis]
```

The force-plate and 3D outcomes used to judge a recommendation do not flow back into the policy during prospective validation.

## Components and frozen interfaces

### 1. Capture and synchronization

Two phones record the applicable candidate or final registered oblique views. The capture service stores video hashes, intrinsic and extrinsic calibration IDs, measured frame rate, synchronization offset, clock drift, dropped-frame fraction, and occlusion fraction. A trial cannot enter perception when a frozen technical-acquisition requirement fails. Task fidelity is classified separately after assignment; when acquisition remains usable, task-fidelity failure does not block feature extraction, remove the attempt, or authorize replacement.

**Input:** two timestamped video streams and calibration records.

**Output:** an acquisition-valid synchronized trial bundle or a controlled acquisition-failure code. Task-fidelity failure is retained as an assigned outcome under the registered performance composite rather than being discarded here.

### 2. Perception model

The perception layer estimates 2D observations, reconstructs the registered task frame, detects penultimate contact, plant initial contact, weight acceptance, toe-off, and exit, then computes only versioned measures from `measure_registry.tsv`.

Its outputs include the feature value, prediction interval or uncertainty score, source hashes, model hash, event-detector version, and QC status. Missing or uncertain features remain missing. They are never imputed silently to make a cue eligible.

The primary phone-reference evaluation is decision-focused:

- error and limits of agreement for each primary measure;
- event-timing error;
- agreement on whether each cue clears the load and uncertainty eligibility thresholds;
- agreement on the final cue or abstention decision;
- failure rate by sport, side, camera, sex, and occlusion stratum when privacy permits.

Pose accuracy alone cannot validate this layer for intervention use.

### 3. Randomized calibration engine

For each eligible active cue, the engine creates cue-control pairs with counterbalanced within-pair order and randomized pair order. The engine saves allocation probabilities and timestamps before the block begins. Assigned policy, planned action, per-trial realized delivery, and achieved kinematic dose remain distinct.

The calibration engine returns athlete-cue contrasts for performance and measured load. Post-assignment achieved dose may describe adherence but does not replace randomized assignment in the primary model.

### 4. Treatment-response model

The response model has two outcomes for athlete (i) and cue (a):

\[
\theta_{ia}=\begin{bmatrix}\Delta Y_{ia}\\\Delta L_{ia}\end{bmatrix},
\]

where favorable performance is coded consistently and larger load is coded as worse. Development athletes estimate a cue-specific population distribution. A new athlete's randomized paired contrasts update that frozen prior. Development and prospective athlete IDs are disjoint.

The NumPy prototype uses an empirical-Bayes Gaussian approximation. It multiplies the personal sampling covariance by the squared ratio of the two-sided 95% Student-t critical value to 1.96, then performs a Gaussian precision update. This scaling is a heuristic small-sample correction, not a Student-t likelihood or a Student-t posterior. Its Gaussian tail areas are diagnostics, not decision probabilities. A seeded sport-stratified split assigns development athletes before fitting to three disjoint roles: population-prior fitting, conformal calibration, and untouched audit. Calibration and audit athletes use exactly the registered B-cal blocks for personal updating and B-val unseen blocks for checking; B-val must match the prospective validation mean. The worst residual across candidate cues calibrates one-sided future-block bounds. The untouched audit applies the personalized, population-ranked, and random selectors separately. For every selector, load false clearance uses an exact one-sided 95% Clopper-Pearson upper confidence bound compared with a frozen load-error limit, and performance false benefit uses its own exact one-sided 95% Clopper-Pearson upper confidence bound compared with a separately frozen performance-error limit. If any selector has too few clearances or exceeds either corresponding limit, the entire policy abstains.

That guard covers a noisy future block mean only under athlete exchangeability. It does not provide a finite-sample bound for a latent causal effect or any formal held-out-handball/OOD transport guarantee. A held-out-handball result is an empirical prospective transport stress test and must not be described as distribution-free transport, individual safety validation, or proof of injury-risk reduction.

### Synthetic policy-equivalence check

The `deployable_null` scenario assigns every cue the same positive performance effect and a load effect below the safety boundary. It uses the same explicitly low-noise measurement regime as the high-signal positive control so the guard can recommend an action, while the true personalized-minus-population policy contrast remains zero. This checks whether the downstream comparison falsely declares a personalization advantage in a setting where deployment is possible; it complements the exact-zero-performance null, which can pass through universal abstention.

### 5. Constrained policy

For every active cue, the policy evaluates four frozen conditions:

1. the cue target lies inside the athlete's rehearsed envelope;
2. required phone measures and calibration support are present;
3. the development-calibrated load upper bound is below the registered margin;
4. the development-calibrated performance lower bound exceeds the registered minimum.

Among eligible cues, the personalized policy selects the largest expected personal performance gain. The comparator is one development-estimated population performance ranking that is frozen before prospective validation and applied only within the same athlete-specific eligible cue set used by the personalized policy. Both policies therefore receive identical athlete-specific performance, load, uncertainty, support, safety-veto, and abstention screens. If no cue qualifies, both outputs are `abstain`.

This comparison isolates the value of personalized benefit ranking. It does not give the personalized policy an easier safety screen.

### 6. Human delivery

The interface renders the exact versioned cue text, target, demonstration ID, and stop rules from `cue-library.md`. Before P/G finalization, a qualified reviewer sees candidate actions under neutral codes and may veto an action without seeing its policy source or predicted benefit. The veto removes that candidate from both policies before their frozen fallback rules rerun. The model cannot invent text, combine cues, or increase a dose outside the approved envelope.

### 7. Outcome firewall and audit log

Before prospective outcomes are opened, the system saves:

- perception, response-model, and policy hashes;
- both personalized and population freeze bundles;
- candidate set and population ranking hashes;
- athlete calibration trial IDs and cutoff time;
- selected cue or abstention, all candidate scores, and reason codes;
- the P/G/N-to-planned-action map, planned-action hashes, pregenerated slots, and per-trial realized-delivery records;
- random seeds, environment, and analysis-plan hash.

Reference outcomes are released to the analysis process only after this manifest validates.

## Proposed deployment output contract

```json
{
  "athlete_id": "<pseudonymous ID>",
  "raw_model_decision": "recommend",
  "final_system_decision": "recommend",
  "selected_cue_id": "BRAKE_EARLIER_V1",
  "selected_cue_version": "<frozen version>",
  "target_value": "<pilot-locked athlete target>",
  "target_unit": "<registered unit>",
  "performance_lower_bound": "<value>",
  "load_upper_bound": "<value>",
  "development_guard_hash": "<sha256>",
  "policy_freeze_hash": "<sha256>"
}
```

The abstention form replaces cue and target fields with a controlled `abstention_reason`.

## Failure behavior

| Failure | Required behavior |
|---|---|
| Missing or unsynchronized video | Retain as technical-missing; activate only an approved phase-specific replacement when available, and do not infer a replacement value |
| Event detector disagreement | Mark required measures invalid and abstain if policy inputs are incomplete |
| Athlete target outside rehearsed range | Remove that cue from the candidate set |
| Load or uncertainty eligibility condition fails | Remove that cue regardless of predicted performance |
| Every cue is removed | Deliver neutral control and record abstention |
| Coach safety veto | Stop or substitute neutral only under the registered rule; retain the deviation |
| P and G share one planned action ID and matching complete hash | Collect one planned action block and set the P-minus-G athlete contrast to zero |
| P, G, or N share one planned action ID and matching complete hash | Map all matching labels to one planned action; never duplicate its outcome |
| Prospective outcome accessed before lock | Quarantine the cohort and investigate as a major protocol deviation |

## Evidence required before an SSAC claim

Prospective phone-reference agreement is a secondary engineering analysis and a prerequisite for any phone-only field-deployment claim. It is not a fourth confirmatory statistical gate, and failure does not erase the policy estimates.

The combined confirmatory policy claim requires three gates, in order:

1. **Gate 0 — coverage:** the lower confidence bound for active personalized recommendations reaches the externally justified \(C_{min}\).
2. **Gate 1 — load:** the personalized policy is noninferior to neutral on `policy_load_contrast_analysis_value`.
3. **Gate 2 — performance:** after Gates 0 and 1 pass, the personalized policy is superior to the population-ranked policy on `task_performance_score`.

Useful secondary evidence includes prospective phone-reference agreement, abstention reasons, false clearance, model-score calibration, policy concordance, retained benefit, reactive transfer, processing time, and subgroup uncertainty.

No acute experiment supports an injury-prevention claim. No simulation supports an athlete-benefit claim. No movement cue is a universal ideal.

## Unresolved values and executable registries

- pre-pilot candidate phone configurations and acceptance rules, followed by one pilot-qualified final configuration frozen before model development;
- a completed executable registry row for `task_performance_score`; its canonical name, log-time definition, and lower-is-better direction are selected, while event, QC, aggregation, and computed \(F_Y\) details remain unresolved;
- completed executable registry rows for raw-reference `peak_external_knee_abduction_moment_normalized` and derived-primary `policy_load_contrast_analysis_value`; their roles are selected, while extraction, QC, missingness, and numerical-margin details remain unresolved;
- cue increments, adherence bands, and athlete envelope rules;
- minimum meaningful performance gain;
- score and uncertainty thresholds;
- maximum exact one-sided audit bound for load false clearance;
- a separately justified maximum exact one-sided audit bound for performance false benefit;
- required calibration and validation block counts;
- measurement QC tolerances and decision tolerance;
- sample size from nuisance-parameter simulation;
- runtime and turnaround requirements.

Each field must be frozen at the stage registered for it. Some require external justification before pilot outcomes are reviewed, some use pilot reliability, safety, or feasibility evidence, and model artifacts use development data. Filling any of them from preference would weaken the study rather than complete it.
