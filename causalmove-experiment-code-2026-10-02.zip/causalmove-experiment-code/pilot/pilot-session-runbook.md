# CausalMove Reliability Pilot: Session Runbook

**Status:** Operational draft. **Do not use with athletes until `pilot-approval-record.md` is complete and signed.**  
**Applies to:** Visits 1 and 2 of the basketball/soccer reliability pilot  
**Does not apply to:** model development, prospective policy validation, training, retention, reactive transfer, or game deployment

This runbook translates the canonical protocol into operator checkpoints. It never authorizes an unresolved value. Where this document says “locked,” use the exact version/hash in `pilot-approval-record.md`.

## Roles at the console

- **Session operator:** sees only the current released event and its exact wording.
- **Coach:** delivers only the frozen cue demonstration and checks comprehension during the registered rehearsal stage.
- **Safety lead:** controls readiness, effort progression, stopping, and adverse-event response.
- **Acquisition-QC reviewer:** sees event identity and modality status, not performance/load magnitudes or apparent cue benefit.
- **Biomechanics lead:** controls equipment calibration and masked reference processing.
- **Custodian:** controls enrollment/randomization slots, seed, state store, seal, and complete exports.

If the approved separation cannot be maintained, do not open the visit.

## A. Day-before release checklist

- [ ] `pilot-approval-record.md` says `READY FOR APPROVED PILOT`; verify its hash.
- [ ] Ethics approval, consent, emergency plan, cue registry, safety registry, acquisition-QC registry, washout map, recovery table, workload ceilings, and operator script match their recorded hashes.
- [ ] The custodian has initialized and hash-committed the concealed schedule under the approved configuration. The operator cannot read future actions. Final pilot sealing occurs only after all participant states are terminal.
- [ ] The athlete has a pseudonymous `athlete_id`; the roster-linkage file is stored separately.
- [ ] Visit date obeys the approved interval and time-of-day rules.
- [ ] Force area covers the full approved plant envelope without asking the athlete to target a plate.
- [ ] Two phones, timing gates, force, and 3D systems pass the known-event synchronization dry run.
- [ ] Storage, clocks, backup, calibration objects, surface, corridor marks, footwear rule, and emergency equipment are ready.
- [ ] No unapproved software, cue text, camera setting, or analysis threshold changed after freeze.

Any failed item closes the checklist as `NO-GO`; record the controlled reason and notify the responsible lead.

## B. Arrival and pre-exposure gate

1. Confirm identity outside the analysis system and retrieve only the pseudonymous study key.
2. On Visit 1, obtain the current approved consent before collecting identifiable data. On Visit 2, reconfirm continued participation and consent status.
3. Complete the approved health/readiness screen, baseline pain score, RPE/wellness fields, footwear, and recent training/injury check.
4. The safety lead records `continue`, `modify only if the registry permits`, or `stop`. Free-text clinical notes remain in the restricted clinical record, not the pilot CSV.
5. Confirm the visit's total-physical-attempt and maximal-attempt counters start from zero and that their approved ceilings are displayed.
6. Complete the frozen warm-up and familiarization ledger. Increment counters for every started physical attempt, including resets and unsuccessful attempts.
7. Begin submaximally. Maximal effort is permitted only after the registered progression criteria pass.

Do not register or reveal randomized cue events before required baseline QC and target binding are complete.

## C. Baseline acquisition and target binding

1. The custodian/session system releases the next `BASE_NATURAL_V1` event only.
2. Before each attempt, verify current equipment readiness and the minimum recovery for the preceding effort transition.
3. On `start-attempt`, increment total and maximal counters as applicable. A started attempt always receives one row in the canonical attempt record.
4. Record timing, task fidelity, phone acquisition, reference acquisition, and the controlled attempt/failure state. Never discard an unfavorable movement.
5. Masked acquisition QC classifies each required baseline as acquisition-complete or one registered technical state.
6. Genuine technical failure may activate only the next pregenerated anchor reserve within \(R_0\). Task, adherence, performance, load, or safety outcomes cannot activate a reserve.
7. After exactly the locked number of valid anchors, compute each active cue target from the frozen rule and accepted baseline event IDs. Save the source hashes, center/dispersion inputs, bounded target, unit, rehearsed envelope, and target-calculation hash.
8. The target authorizer verifies direction, finite value, approved envelope, and hash. If any target cannot be bound, close as `baseline_incomplete`; do not improvise a cue value.
9. Only after all four active targets are valid may the custodian bind the next concealed randomization slot.

## D. Cue rehearsal

For each active cue in the concealed family order:

1. Apply the exact pre-family washout boundary from \(\mathcal W_{pilot}\).
2. Deliver the frozen wording and demonstration for the lowest registered dose.
3. Rehearse at the registered submaximal effort. Every started rehearsal/reset is counted even when excluded from reliability analysis.
4. Escalate only when target execution, task corridor, balance, pain, and safety criteria pass. Never exceed the approved maximum dose or the athlete's pain-free rehearsed envelope.
5. Record achieved dose, effort level, delivery hash, task state, pain/RPE, and whether the cue remains eligible.
6. If no registered dose passes, retire/stop that cue under the approved rule. Do not substitute a new cue or dose.

The pilot records executability and safety. Rehearsal performance direction cannot select the dose or alter later order unless the predeclared rule explicitly permits it without using efficacy outcomes.

## E. Randomized paired probes

For each active cue family, complete the locked number of root pairs. A root pair contains one active-cue attempt and one `CTRL_NEUTRAL_V1` attempt in the concealed within-pair order.

For every released member:

1. Verify the current event, exact delivery, target, effort, remaining workload capacity, equipment readiness, and minimum recovery.
2. Reveal only the current instruction. Do not state whether it is active/control, its pair position, predicted benefit, or measured performance/load.
3. Record delivery before movement starts. If the instruction is wrong or partial, preserve the realized-delivery hash and classify the deviation; do not rewrite the assignment.
4. Record `start-attempt` before movement. Increment physical/maximal counters.
5. Resolve attempt, task fidelity, safety, and modality-acquisition states using controlled codes.
6. After both pair members resolve, masked QC must return one terminal disposition within the approved QC window before progression.
7. `acquisition_complete` closes the pair gate.
8. A genuine eligible technical failure may activate only the next pregenerated same-cue replacement pair, if the cue window remains open and the athlete-wide \(R_{max}\) is not exhausted. Store root, failed-pair, replacement-pair, and member lineage atomically.
9. Do not replace task/path/speed/angle failure, wrong limb, nonadherence, high load, slow time, pain, safety stop, or any value outside a desired outcome range.
10. Apply the exact between-member and post-pair washout/recovery event before the next exposure.

If capacity is exhausted, retain the incomplete pair as `technical_failure_no_reserve` and continue or stop according to the approved schedule. Never add an off-schedule “extra good trial.”

## F. Stop, pause, equipment, and withdrawal actions

### Safety stop or withdrawal

The safety lead may stop at any time. Atomically record whether the current instruction was delivered, whether an attempt started, and the compatible terminal state. Close pending QC without activating replacement, preserve all started attempts, classify unreached events, and follow the clinical/adverse-event plan. No one may reveal future events after closure.

### Equipment interruption

- Before an attempt starts: record `no_attempt_started`; after approved repair and calibration, re-release the same assignment. This is not a replacement.
- After an attempt starts: create the attempt row and submit masked acquisition QC.
- If readiness cannot be restored or the safety registry requires termination: close operationally and retain the complete reached-boundary record.

### Pilot pause or cue suspension

Only the authorized safety role can invoke these states. A pause blocks new registration, allocation, and reveal while permitting safe resolution of an active attempt. Cue suspension closes that cue version; resumption requires the registered safety/ethics clearance or a new approved version.

## G. Visit closeout

- [ ] Every released event has delivery, attempt/rest, safety, and required QC resolution.
- [ ] Every started physical attempt appears once in the canonical attempt record and contributes to workload counters.
- [ ] No unreleased or inactive replacement appears as an attempt.
- [ ] Every deviation uses a controlled category and affected IDs; outcome values did not drive structural classification.
- [ ] Final pain, RPE/fatigue, adverse-event, usability, and equipment states are recorded under their approved instruments.
- [ ] The final cue family's dormant replacement window is sealed.
- [ ] The visit is complete, safety-stopped, operationally stopped, withdrawn, or baseline-incomplete—never left ambiguously open.
- [ ] Visit 2 appointment remains inside the approved 3–7-day window or receives the registered deviation state.
- [ ] Restricted clinical and linkage material is separated from the analysis records.

## H. Visit 2 differences

- Verify the existing athlete-slot binding; never allocate a new slot.
- Recompute visit-specific baselines and targets from Visit 2's accepted anchor events under the same frozen rule.
- Use the separately generated Visit 2 family and pair orders; they cannot be chosen from Visit 1 results.
- Apply the same attempt ceilings, athlete-wide replacement-pair cap, cue versions, washout rule, measurement settings, QC rules, and stopping criteria unless a formally approved amendment has closed the current version.
- A missed Visit 2 is a terminal participant-flow state, not permission to recruit beyond the fixed enrollment cap.

## I. Pilot seal and handoff

After the last participant reaches a terminal Visit 2 state or registered early-stop boundary, the custodian:

1. verifies no open event, QC gate, visit, dormant window, or enrollment state remains;
2. seals the pilot before final export;
3. exports the schedule master, participant flow, allocation/release audit, deliveries, attempts, workload, QC, deviations, safety states, and analysis-ready pilot table;
4. hashes every file and records the seed commitment without exposing seed bytes;
5. reconciles every started attempt and legitimate absent row against the sealed schedule;
6. preserves all enrolled, stopped, withdrawn, baseline-incomplete, and missed-Visit-2 participants in the flow report; and
7. releases masked analysis data only under the signed access plan.

Run the existing flat-file checks only as a limited structural screen:

```bash
python3 -B pilot/validate_pilot.py pilot/FROZEN_PILOT.csv
python3 -B pilot/analyze_reliability.py pilot/FROZEN_PILOT.csv > pilot/FROZEN_PILOT.reliability.json
```

The current tools do not validate the randomization lifecycle, workload, partial sessions, carryover, or inferential thresholds. Until the approved audit-bundle extension exists, passing these commands cannot declare the scientific pilot complete.

## J. Pilot decision meeting

Using masked, prespecified outputs, make one decision for each item:

| Decision | Required output | Allowed conclusion |
|---|---|---|
| Reliable replicate count | ICC(A,k), SEM, MDC95, complete-athlete counts by measure/source/visit | Smallest feasible `k`, or no feasible count |
| Phone/reference feasibility | Bias, MAE, RMSE, CCC, calibration, limits, event agreement | Candidate passes/revises/fails; not athlete benefit |
| Cue dose | Reliability, executability, achieved dose, task fidelity, and safety under frozen rule | Select one registered dose or retire cue |
| Washout | Previous-cue estimate and confidence interval against locked limit | Pass, advance predeclared ladder, or abandon crossover |
| Workload | Completed/stopped visits, all attempt counts, fatigue, missingness, adverse events | Feasible schedule or redesign |
| Camera configuration | Predeclared measurement criteria | Freeze one candidate or stop phone claim |
| Main-study simulation inputs | Pilot measurement error, missingness, concordance, workload, withdrawal | Inputs only; no efficacy estimate |

Do not inspect cue efficacy direction to rewrite thresholds, choose the most favorable outcome, or remove an inconvenient cue. The pilot enables the next study; it is not the prospective athlete-benefit test.
