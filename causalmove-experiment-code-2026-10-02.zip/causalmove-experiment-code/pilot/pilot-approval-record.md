# CausalMove Reliability Pilot: Approval and Freeze Record

**Status:** Restricted fillable template. **Not approved for athlete exposure.**  
**Pilot population:** 12–15 adults from basketball and soccer only  
**Visits:** two visits separated by 3–7 days  
**Canonical design sources:** `study-protocol.md`, `cue-library.md`, `athlete-workload-audit.md`, `protocol-reconciliation-proposal.md`, and `docs/superpowers/specs/2026-09-03-pilot-randomization-design.md`

This record is the short operational gate for the reliability pilot. A blank value, missing evidence path, unsigned authority, or hash mismatch means **NO-GO**. Completing this document does not replace institutional ethics approval or the approved protocol.

Keep the signed record in the restricted study archive. Publish only a disclosure-reviewed version.

## 1. Pilot identity

| Field | Locked value |
|---|---|
| Study title | CausalMove cross-sport cutting reliability pilot |
| Protocol version and hash | `[REQUIRED]` |
| Ethics approval ID, approval date, and amendment version | `[REQUIRED]` |
| Approved pilot start and end dates | `[REQUIRED]` |
| Site and room | `[REQUIRED]` |
| Principal investigator | `[REQUIRED]` |
| Pilot registration URL/identifier and timestamp | `[REQUIRED BEFORE FIRST EXPOSURE]` |
| Restricted archive location | `[REQUIRED]` |
| Public-release plan version and approval | `[REQUIRED]` |

## 2. Evidence gate

Enter one inspectable path or identifier for every row. Statements of intent do not pass.

| Required evidence | Path / identifier | Verified by | Date | Pass? |
|---|---|---|---|:---:|
| Ethics approval covers randomized maximal cutting, all cues, two visits, adverse-event follow-up, video, force/3D measurement, and intended release | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Separate consent choices cover participation, public analysis tables, derived biometric data, and raw/processed video | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Basketball/soccer recruitment agreement and dated two-visit schedule for 12–15 adults | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Force plates ≥1,000 Hz, validated 3D kinematics ≥200 Hz, timing gates, two phones, calibration/synchronization materials, controlled surface, and operators booked | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Full approved plant envelope captured without force-plate targeting | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Emergency plan, clinical screening, and adverse-event process | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Secure pseudonymous-ID, linkage, access-log, encryption, backup, and privacy-incident procedures | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Real consent-safe dry run from two videos and references through checksummed masked output | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| Independent randomization/data custodian and outcome-unmasking procedure | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |

## 3. Named roles and access separation

One person may hold multiple roles only when the separation-of-duties review explicitly permits it. Record conflicts and compensating controls.

| Role | Name and qualification | Allowed information | Prohibited information | Signed? |
|---|---|---|---|:---:|
| Principal investigator | `[REQUIRED]` | Protocol and oversight records | Unscheduled outcome-driven changes | [ ] |
| Safety lead / clinician | `[REQUIRED]` | Screening, readiness, adverse events, stop state | Hidden efficacy summaries during exposure | [ ] |
| Biomechanics lead | `[REQUIRED]` | Calibration, task validity, masked reference processing | Policy source during masked processing | [ ] |
| Qualified coach | `[REQUIRED]` | Frozen cue wording, demonstrations, comprehension | Predicted performance or load during delivery | [ ] |
| Session operator | `[REQUIRED]` | Current released event only | Future allocations, policy source, outcome summaries | [ ] |
| Acquisition-QC reviewer | `[REQUIRED]` | Event identity and modality status | Performance/load magnitude and cue efficacy | [ ] |
| Randomization/data custodian | `[REQUIRED]` | Seed, allocation state, restricted complete export | Coaching or outcome-driven alteration | [ ] |
| ML/processing lead | `[REQUIRED]` | Approved development tools and masked pilot inputs | Prospective outcomes; direct identifiers | [ ] |
| Data steward/privacy reviewer | `[REQUIRED]` | Linkage controls and proposed release | Unapproved disclosure | [ ] |

**Separation-of-duties exception and compensating control:** `[NONE or REQUIRED DETAILS]`

## 4. Frozen pilot configuration

The qualified team supplies these values. No value may be chosen from favorable cue-response results.

### 4.1 Cohort, visits, and task

| Parameter | Locked value | Basis / evidence | Authority initials |
|---|---|---|---|
| Total enrollment cap, within 12–15 | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Basketball and soccer allocation | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Visit interval, within 3–7 days | `[REQUIRED]` | Protocol | `[REQUIRED]` |
| Permitted time-of-day difference | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Approach distance and entry-speed corridor | `[REQUIRED WITH UNITS]` | `[REQUIRED]` | `[REQUIRED]` |
| Exit corridor and accepted cut-angle band | `[REQUIRED WITH UNITS]` | `[REQUIRED]` | `[REQUIRED]` |
| Plant limb selection rule | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Footwear and surface rule | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |

### 4.2 Attempt and recovery ledger

| Parameter | Locked value | Basis / evidence | Authority initials |
|---|---|---|---|
| Valid natural anchors per visit, \(B_{0,pilot}\) | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Natural-anchor reserve cap per visit, \(R_0\) | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Primary active-control pairs per cue per visit, \(B_{pair,pilot}\), minimum 2 | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Athlete-wide technical replacement-pair cap across both visits, \(R_{max}\) | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Warm-up and familiarization attempt ledger | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Cue-by-dose rehearsal attempt ledger | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Maximum total physical attempts per visit | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Maximum maximal-effort attempts per visit | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Minimum recovery by effort transition | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Fatigue/RPE and performance-decline stop rules | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |

The planned and worst-case workloads must be recomputed from the approved event graph. Phase changes, equipment retries, resets, reserves, and replacements cannot reset cumulative counters.

### 4.3 Cue and dose registry

| Cue | Exact wording/demo hash | Dose grid and units | Start / maximum | Escalation and stop rule | Approved? |
|---|---|---|---|---|:---:|
| `FPA_ALIGN_EXIT_V1` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| `PLANT_OFFSET_REDUCE_V1` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| `BRAKE_EARLIER_V1` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| `TRUNK_TOWARD_EXIT_V1` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [ ] |
| `CTRL_NEUTRAL_V1` | `[REQUIRED]` | Not applicable | Not applicable | Attention-match rule `[REQUIRED]` | [ ] |

Each active target must be a bounded change from the athlete's accepted natural baseline and clipped to that athlete's pain-free rehearsed envelope. No cue is scientific ground truth.

### 4.4 Washout and carryover

| Parameter | Locked value | Basis / evidence | Authority initials |
|---|---|---|---|
| Complete washout-boundary map, \(\mathcal W_{pilot}\) | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Minimum rest at each boundary | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Neutral reset wording and reset-attempt count/rule | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Maximum acceptable previous-cue effect | `[REQUIRED WITH UNITS]` | External/statistical basis `[REQUIRED]` | `[REQUIRED]` |
| Confidence rule for passing washout | `[REQUIRED]` | Statistician specification `[REQUIRED]` | `[REQUIRED]` |
| Predeclared washout adaptation ladder | `[REQUIRED or NONE]` | `[REQUIRED]` | `[REQUIRED]` |

If no feasible schedule passes the locked carryover rule, the paired crossover is abandoned or amended prospectively; a sensitivity analysis does not rescue it.

### 4.5 Capture, calibration, QC, and measurement

| Parameter | Locked value | Basis / evidence | Authority initials |
|---|---|---|---|
| Two-phone roles, models/range, frame rate, resolution, placement, orientation tolerance | `[REQUIRED VERSION/HASH]` | Dry run `[REQUIRED]` | `[REQUIRED]` |
| Intrinsic/extrinsic calibration method and acceptance threshold | `[REQUIRED]` | Dry run `[REQUIRED]` | `[REQUIRED]` |
| Synchronization event, method, and maximum error | `[REQUIRED]` | Dry run `[REQUIRED]` | `[REQUIRED]` |
| Force/3D/timing preprocessing and event definitions | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Acquisition-QC registry and terminal decision deadline | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Feature/measure registry and units | `[REQUIRED VERSION/HASH]` | `[REQUIRED]` | `[REQUIRED]` |
| Reliability registry, aggregation, transforms, and minimum complete-athlete counts | `[REQUIRED VERSION/HASH]` | Statistician approval `[REQUIRED]` | `[REQUIRED]` |
| External load noninferiority margin \(\delta_L\), locked before pilot outcomes | `[REQUIRED WITH UNITS]` | External biomechanical basis `[REQUIRED]` | `[REQUIRED]` |

## 5. Replacement and missing-attempt truth table

| Event | Keep original attempt? | Replacement allowed? | Required action |
|---|:---:|:---:|---|
| Genuine technical failure confirmed by timely masked QC | Yes | Only the next pregenerated same-cue pair, within \(R_{max}\) | Preserve pair/member/root lineage and failure code |
| Natural-anchor technical failure | Yes | Only a pregenerated anchor reserve, within \(R_0\) | Preserve original anchor and reserve lineage |
| Task/path/speed/angle/wrong-limb failure | Yes | No | Record as task outcome |
| Cue nonadherence or unfavorable performance/load | Yes | No | Retain assigned attempt; do not expose magnitude to QC |
| Pain, safety stop, withdrawal, fall, instability, or unsafe execution | Yes, if started | No | Apply clinical stop/closure process and adverse-event record |
| Equipment outage before attempt starts | No fabricated attempt row | Re-release same assignment after approved readiness; not a replacement | Preserve release and outage audit |
| Late-discovered technical problem after progression | Yes | No retrospective replacement | Record deviation/missingness |

## 6. Required pre-pilot rehearsal

The masked rehearsal must use synthetic or non-athlete system-test identifiers and must demonstrate:

- enrollment without early allocation;
- baseline acquisition, QC, and target binding before randomization-slot assignment;
- current-event-only reveal;
- one normal pair, one genuine technical replacement, one task failure without replacement, one equipment interruption, and one safety closure;
- cumulative workload counters that never reset;
- complete attempt-to-CSV reconciliation;
- seal refusal while a state is unresolved;
- immutable export, checksum verification, and a tamper rejection; and
- no direct identifiers, raw seed, future actions, or outcome magnitudes in operator/QC output.

| Rehearsal bundle | Date | Witnesses | Deviations closed? | Pass? |
|---|---|---|:---:|:---:|
| `[REQUIRED PATH/HASH]` | `[REQUIRED]` | `[REQUIRED]` | [ ] | [ ] |

## 7. Authority sign-off

Each signature approves only the stated domain. Ethics approval remains controlling.

| Authority | Domain | Name | Signature / approved digital record | Date |
|---|---|---|---|---|
| Principal investigator | Scientific scope and accountability | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Independent statistician | Estimands, randomization, reliability, carryover, and lock timing | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Coach | Cue wording, delivery, and executability | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Biomechanist | Targets, capture, reference measurement, and interpretation | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Safety lead / clinician | Screening, effort, workload, recovery, and stop rules | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Data steward | Privacy, access, linkage, retention, and release | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` |
| Ethics authority | Approved protocol and amendments | `[REQUIRED ID/RECORD]` | `[REQUIRED]` | `[REQUIRED]` |

## 8. Final readiness determination

| Check | Result |
|---|---|
| Every Section 2 evidence row passed | `[YES/NO]` |
| Every required Section 4 value frozen and hashed | `[YES/NO]` |
| Planned and worst-case workload within signed ceilings | `[YES/NO]` |
| All cue versions approved | `[YES/NO]` |
| Masked rehearsal passed with deviations closed | `[YES/NO]` |
| All Section 7 authorities signed | `[YES/NO]` |
| Hash verification repeated immediately before first exposure | `[YES/NO]` |

**Pilot state:** `[NO-GO / READY FOR APPROVED PILOT]`  
**Determined by:** `[REQUIRED]`  
**UTC timestamp:** `[REQUIRED]`  
**Record hash:** `[REQUIRED]`

The only valid default is `NO-GO`. `READY FOR APPROVED PILOT` is valid only when every required cell above is complete, internally consistent, inspectable, and signed.
