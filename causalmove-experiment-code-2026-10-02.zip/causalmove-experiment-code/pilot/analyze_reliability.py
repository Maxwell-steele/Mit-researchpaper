#!/usr/bin/env python3
"""Compute descriptive reliability and phone-reference pilot estimates."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from validate_pilot import ALLOWED_CUES, validate as validate_pilot


SCHEMA_VERSION = "causalmove-reliability-v1"
ANALYSIS_ROLES = frozenset({"natural_anchor", "paired_probe"})
SOURCES = ("reference", "phone")
MEASURES = (
    "task_performance_score",
    "foot_exit_alignment_error_at_initial_contact",
    "plant_lateral_offset_normalized",
    "penultimate_deceleration_share",
    "trunk_lean_toward_exit_at_initial_contact",
    "peak_external_knee_abduction_moment_normalized",
)
LIMITATIONS = (
    "Descriptive pilot estimates without cluster or bootstrap confidence intervals; "
    "no reliability, agreement, safety, or efficacy threshold is applied."
)
ICC_NAME = "icc_a_1_two_way_absolute_agreement_single_measure"


def _finite(value: float | None) -> float | None:
    if value is None or not math.isfinite(value):
        return None
    return 0.0 if value == 0 else value


def _mean(values: list[float]) -> float | None:
    if not values:
        return None
    try:
        return _finite(math.fsum(sorted(values)) / len(values))
    except OverflowError:
        return None


def _sample_sd(values: list[float]) -> float | None:
    if len(values) < 2:
        return None
    center = _mean(values)
    if center is None:
        return None
    scale = max((abs(value - center) for value in values), default=0.0)
    if scale == 0:
        return 0.0
    try:
        scaled_ss = math.fsum(
            sorted(((value - center) / scale) ** 2 for value in values)
        )
        return _finite(scale * math.sqrt(scaled_ss / (len(values) - 1)))
    except (OverflowError, ValueError):
        return None


def _icc_a_1(pairs: list[tuple[float, float]]) -> float | None:
    """Two-way random-effects, absolute-agreement, single-measure ICC(A,1)."""
    n = len(pairs)
    if n < 2:
        return None
    scale = max((abs(value) for pair in pairs for value in pair), default=0.0)
    if scale == 0:
        return None
    normalized = [(visit_1 / scale, visit_2 / scale) for visit_1, visit_2 in pairs]
    visit_1_values = [pair[0] for pair in normalized]
    visit_2_values = [pair[1] for pair in normalized]
    visit_1_mean = _mean(visit_1_values)
    visit_2_mean = _mean(visit_2_values)
    if visit_1_mean is None or visit_2_mean is None:
        return None
    grand = (visit_1_mean + visit_2_mean) / 2.0
    subject_means = [(visit_1 + visit_2) / 2.0 for visit_1, visit_2 in normalized]
    try:
        ss_subject = 2.0 * math.fsum(
            sorted((subject_mean - grand) ** 2 for subject_mean in subject_means)
        )
        ss_visit = n * (
            (visit_1_mean - grand) ** 2 + (visit_2_mean - grand) ** 2
        )
        ss_error = math.fsum(
            sorted(
                (
                    value
                    - subject_means[subject_index]
                    - (visit_1_mean if visit_index == 0 else visit_2_mean)
                    + grand
                )
                ** 2
                for subject_index, pair in enumerate(normalized)
                for visit_index, value in enumerate(pair)
            )
        )
        ms_subject = ss_subject / (n - 1)
        ms_visit = ss_visit
        ms_error = ss_error / (n - 1)
        denominator = (
            ms_subject + ms_error + 2.0 * (ms_visit - ms_error) / n
        )
        if denominator == 0:
            return None
        return _finite((ms_subject - ms_error) / denominator)
    except (OverflowError, ValueError, ZeroDivisionError):
        return None


def _test_retest_stats(pairs: list[tuple[float, float]]) -> dict[str, int | float | None]:
    visit_1 = [pair[0] for pair in pairs]
    visit_2 = [pair[1] for pair in pairs]
    differences = [second - first for first, second in pairs]
    bias = _mean(differences)
    sd_difference = _sample_sd(differences)
    typical_error = (
        _finite(sd_difference / math.sqrt(2.0)) if sd_difference is not None else None
    )
    sdc95 = _finite(1.96 * sd_difference) if sd_difference is not None else None
    return {
        "paired_athlete_count": len(pairs),
        "visit_1_mean": _mean(visit_1),
        "visit_2_mean": _mean(visit_2),
        "visit_2_minus_visit_1_bias": bias,
        "sd_visit_differences": sd_difference,
        "typical_error_sd_diff_over_sqrt_2": typical_error,
        "sdc95_1_96_times_sd_diff": sdc95,
        ICC_NAME: _icc_a_1(pairs),
    }


def _lin_ccc(phone: list[float], reference: list[float]) -> float | None:
    if len(phone) != len(reference) or len(phone) < 2:
        return None
    scale = max((abs(value) for value in phone + reference), default=0.0)
    if scale == 0:
        return None
    phone_scaled = [value / scale for value in phone]
    reference_scaled = [value / scale for value in reference]
    phone_mean = _mean(phone_scaled)
    reference_mean = _mean(reference_scaled)
    if phone_mean is None or reference_mean is None:
        return None
    n = len(phone)
    try:
        phone_variance = math.fsum(
            sorted((value - phone_mean) ** 2 for value in phone_scaled)
        ) / n
        reference_variance = math.fsum(
            sorted((value - reference_mean) ** 2 for value in reference_scaled)
        ) / n
        covariance = math.fsum(
            sorted(
                (phone_value - phone_mean) * (reference_value - reference_mean)
                for phone_value, reference_value in zip(
                    phone_scaled, reference_scaled, strict=True
                )
            )
        ) / n
        denominator = (
            phone_variance
            + reference_variance
            + (phone_mean - reference_mean) ** 2
        )
        if denominator == 0:
            return None
        return _finite(2.0 * covariance / denominator)
    except (OverflowError, ValueError, ZeroDivisionError):
        return None


def _agreement_stats(rows: list[dict[str, str]], measure: str) -> dict[str, object]:
    phone = [float(row[f"phone_{measure}"]) for row in rows]
    reference = [float(row[f"reference_{measure}"]) for row in rows]
    differences = [phone_value - reference_value for phone_value, reference_value in zip(phone, reference, strict=True)]
    bias = _mean(differences)
    sd_difference = _sample_sd(differences)
    mae = _mean([abs(value) for value in differences])
    try:
        rmse = _finite(math.hypot(*differences) / math.sqrt(len(differences))) if differences else None
    except (OverflowError, ValueError):
        rmse = None
    loa_lower = (
        _finite(bias - 1.96 * sd_difference)
        if bias is not None and sd_difference is not None
        else None
    )
    loa_upper = (
        _finite(bias + 1.96 * sd_difference)
        if bias is not None and sd_difference is not None
        else None
    )
    return {
        "n_attempts": len(rows),
        "athlete_count": len({row["athlete_id"] for row in rows}),
        "bias_phone_minus_reference": bias,
        "mean_absolute_error": mae,
        "root_mean_squared_error": rmse,
        "sd_phone_minus_reference": sd_difference,
        "loa_95_lower": loa_lower,
        "loa_95_upper": loa_upper,
        "lin_concordance_correlation_coefficient": _lin_ccc(phone, reference),
    }


def _read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [
            {key: (value or "").strip() for key, value in row.items()}
            for row in csv.DictReader(handle)
        ]


def _completeness(rows: list[dict[str, str]], analysis_rows: list[dict[str, str]]) -> dict[str, object]:
    complete_rows = [row for row in rows if row["record_status"] == "complete"]
    role_counts = Counter(row["trial_role"] for row in complete_rows)
    return {
        "total_input_rows": len(rows),
        "record_status_counts": dict(sorted(Counter(row["record_status"] for row in rows).items())),
        "complete_rows": len(complete_rows),
        "excluded_noncomplete_rows": len(rows) - len(complete_rows),
        "complete_natural_anchor_rows": role_counts["natural_anchor"],
        "complete_paired_probe_rows": role_counts["paired_probe"],
        "excluded_complete_active_practice_rows": role_counts["active_practice"],
        "excluded_complete_washout_reset_rows": role_counts["washout_reset"],
        "analysis_attempt_rows": len(analysis_rows),
        "analysis_athlete_count": len({row["athlete_id"] for row in analysis_rows}),
    }


def _test_retest(rows: list[dict[str, str]]) -> dict[str, object]:
    grouped: dict[tuple[str, int, str, str, str], list[float]] = defaultdict(list)
    for row in rows:
        athlete_id = row["athlete_id"]
        visit = int(row["visit_number"])
        cue_id = row["cue_id"]
        for measure in MEASURES:
            for source in SOURCES:
                grouped[(athlete_id, visit, cue_id, measure, source)].append(
                    float(row[f"{source}_{measure}"])
                )

    aggregated = {
        key: _mean(values)
        for key, values in grouped.items()
    }
    athlete_ids = sorted({row["athlete_id"] for row in rows})
    output: dict[str, object] = {}
    for cue_id in sorted(ALLOWED_CUES):
        output[cue_id] = {}
        for measure in MEASURES:
            output[cue_id][measure] = {}
            for source in SOURCES:
                pairs = []
                for athlete_id in athlete_ids:
                    first = aggregated.get((athlete_id, 1, cue_id, measure, source))
                    second = aggregated.get((athlete_id, 2, cue_id, measure, source))
                    if first is not None and second is not None:
                        pairs.append((first, second))
                output[cue_id][measure][source] = _test_retest_stats(pairs)
    return output


def analyze(path: Path) -> dict[str, object]:
    input_validation = validate_pilot(path)
    if not input_validation["valid"]:
        return {
            "schema_version": SCHEMA_VERSION,
            "analysis_status": "refused_invalid_input",
            "input_validation": input_validation,
            "limitations": LIMITATIONS,
        }

    rows = _read_rows(path)
    analysis_rows = [
        row
        for row in rows
        if row["record_status"] == "complete" and row["trial_role"] in ANALYSIS_ROLES
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "analysis_status": "descriptive_only",
        "input_validation": input_validation,
        "difference_directions": {
            "test_retest": "visit_2_minus_visit_1",
            "phone_reference": "phone_minus_reference",
        },
        "aggregation_unit": "athlete_by_visit_by_cue_before_test_retest",
        "completeness": _completeness(rows, analysis_rows),
        "test_retest": _test_retest(analysis_rows),
        "phone_reference_agreement": {
            measure: _agreement_stats(analysis_rows, measure) for measure in MEASURES
        },
        "limitations": LIMITATIONS,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path, help="structurally valid pilot CSV")
    args = parser.parse_args(argv)
    report = analyze(args.csv_path)
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0 if report["analysis_status"] == "descriptive_only" else 1


if __name__ == "__main__":
    raise SystemExit(main())
