import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PILOT_DIR = Path(__file__).resolve().parents[1]
VALIDATOR = PILOT_DIR / "validate_pilot.py"
TEMPLATE = PILOT_DIR / "pilot-data-template.csv"

FIELDNAMES = [
    "athlete_id",
    "session_id",
    "visit_number",
    "study_day",
    "phase",
    "sport",
    "plant_limb",
    "pair_id",
    "cue_id",
    "trial_role",
    "replicate",
    "record_status",
    "attempt_status",
    "task_fidelity_status",
    "performance_acquisition_valid",
    "load_acquisition_valid",
    "failure_code",
    "phone_task_performance_score",
    "reference_task_performance_score",
    "phone_foot_exit_alignment_error_at_initial_contact",
    "reference_foot_exit_alignment_error_at_initial_contact",
    "phone_plant_lateral_offset_normalized",
    "reference_plant_lateral_offset_normalized",
    "phone_penultimate_deceleration_share",
    "reference_penultimate_deceleration_share",
    "phone_trunk_lean_toward_exit_at_initial_contact",
    "reference_trunk_lean_toward_exit_at_initial_contact",
    "phone_peak_external_knee_abduction_moment_normalized",
    "reference_peak_external_knee_abduction_moment_normalized",
]

ACTIVE_CUES = (
    "FPA_ALIGN_EXIT_V1",
    "PLANT_OFFSET_REDUCE_V1",
    "BRAKE_EARLIER_V1",
    "TRUNK_TOWARD_EXIT_V1",
)


def complete_row(**overrides):
    row = {
        "athlete_id": "P001",
        "session_id": "P001-V1",
        "visit_number": "1",
        "study_day": "0",
        "phase": "reliability_pilot",
        "sport": "basketball",
        "plant_limb": "left",
        "pair_id": "",
        "cue_id": "BASE_NATURAL_V1",
        "trial_role": "natural_anchor",
        "replicate": "1",
        "record_status": "complete",
        "attempt_status": "completed",
        "task_fidelity_status": "pass",
        "performance_acquisition_valid": "true",
        "load_acquisition_valid": "true",
        "failure_code": "",
        "phone_task_performance_score": "0.182",
        "reference_task_performance_score": "0.180",
        "phone_foot_exit_alignment_error_at_initial_contact": "12.1",
        "reference_foot_exit_alignment_error_at_initial_contact": "11.8",
        "phone_plant_lateral_offset_normalized": "0.232",
        "reference_plant_lateral_offset_normalized": "0.225",
        "phone_penultimate_deceleration_share": "0.551",
        "reference_penultimate_deceleration_share": "0.545",
        "phone_trunk_lean_toward_exit_at_initial_contact": "8.2",
        "reference_trunk_lean_toward_exit_at_initial_contact": "8.0",
        "phone_peak_external_knee_abduction_moment_normalized": "0.312",
        "reference_peak_external_knee_abduction_moment_normalized": "0.305",
    }
    row.update(overrides)
    return row


def valid_rows(athlete_count=12):
    rows = []
    for athlete_index in range(1, athlete_count + 1):
        athlete_id = f"P{athlete_index:03d}"
        sport = "basketball" if athlete_index % 2 else "soccer"
        plant_limb = "left" if athlete_index % 2 else "right"
        for visit_number, study_day in ((1, 0), (2, 4)):
            session_id = f"{athlete_id}-V{visit_number}"
            rows.append(
                complete_row(
                    athlete_id=athlete_id,
                    session_id=session_id,
                    visit_number=str(visit_number),
                    study_day=str(study_day),
                    sport=sport,
                    plant_limb=plant_limb,
                )
            )
            for cue_index, active_cue in enumerate(ACTIVE_CUES, start=1):
                pair_id = f"{session_id}-PAIR-{cue_index}"
                rows.append(
                    complete_row(
                        athlete_id=athlete_id,
                        session_id=session_id,
                        visit_number=str(visit_number),
                        study_day=str(study_day),
                        sport=sport,
                        plant_limb=plant_limb,
                        cue_id=active_cue,
                        trial_role="active_practice",
                        replicate="1",
                    )
                )
                rows.append(
                    complete_row(
                        athlete_id=athlete_id,
                        session_id=session_id,
                        visit_number=str(visit_number),
                        study_day=str(study_day),
                        sport=sport,
                        plant_limb=plant_limb,
                        pair_id=pair_id,
                        cue_id=active_cue,
                        trial_role="paired_probe",
                        replicate="2",
                    )
                )
                rows.append(
                    complete_row(
                        athlete_id=athlete_id,
                        session_id=session_id,
                        visit_number=str(visit_number),
                        study_day=str(study_day),
                        sport=sport,
                        plant_limb=plant_limb,
                        pair_id=pair_id,
                        cue_id="CTRL_NEUTRAL_V1",
                        trial_role="paired_probe",
                        replicate=str(cue_index),
                    )
                )
    return rows


def run_validator(rows, fieldnames=FIELDNAMES):
    with tempfile.TemporaryDirectory() as temp_dir:
        csv_path = Path(temp_dir) / "pilot.csv"
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        completed = subprocess.run(
            [sys.executable, str(VALIDATOR), str(csv_path)],
            capture_output=True,
            check=False,
            text=True,
        )
        report = json.loads(completed.stdout) if completed.stdout.strip() else None
        return completed, report


class PilotValidatorTests(unittest.TestCase):
    def assert_error(self, rows, code, fieldnames=FIELDNAMES):
        completed, report = run_validator(rows, fieldnames)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIsNotNone(report, completed.stderr)
        self.assertFalse(report["valid"])
        self.assertIn(code, {item["code"] for item in report["errors"]})

    def test_complete_two_visit_pilot_is_valid_and_reports_counts(self):
        completed, report = run_validator(valid_rows())

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertTrue(report["valid"])
        self.assertEqual(report["row_count"], 312)
        self.assertEqual(report["athlete_count"], 12)
        self.assertEqual(report["session_count"], 24)
        self.assertEqual(report["errors"], [])
        self.assertEqual(report["warnings"], [])

    def test_unpaired_neutral_washout_attempt_is_allowed(self):
        rows = valid_rows()
        rows.append(
            complete_row(
                athlete_id="P001",
                session_id="P001-V1",
                visit_number="1",
                study_day="0",
                sport="basketball",
                plant_limb="left",
                cue_id="CTRL_NEUTRAL_V1",
                trial_role="washout_reset",
                replicate="5",
            )
        )

        completed, report = run_validator(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertTrue(report["valid"])

    def test_trial_role_must_match_the_delivered_cue(self):
        rows = valid_rows()
        rows[0]["trial_role"] = "paired_probe"

        self.assert_error(rows, "invalid_trial_role_cue")

    def test_shipped_template_has_the_schema_but_no_fabricated_rows(self):
        completed = subprocess.run(
            [sys.executable, str(VALIDATOR), str(TEMPLATE)],
            capture_output=True,
            check=False,
            text=True,
        )
        report = json.loads(completed.stdout)
        codes = {item["code"] for item in report["errors"]}

        self.assertEqual(completed.returncode, 1)
        self.assertEqual(report["row_count"], 0)
        self.assertIn("empty_dataset", codes)
        self.assertNotIn("missing_required_columns", codes)

    def test_non_utf8_file_still_returns_machine_readable_error_json(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            csv_path = Path(temp_dir) / "pilot.csv"
            csv_path.write_bytes(b"athlete_id\n\xff\xfe")
            completed = subprocess.run(
                [sys.executable, str(VALIDATOR), str(csv_path)],
                capture_output=True,
                check=False,
                text=True,
            )

        self.assertEqual(completed.returncode, 1)
        self.assertTrue(completed.stdout.strip(), completed.stderr)
        report = json.loads(completed.stdout)
        self.assertIn("file_read_error", {item["code"] for item in report["errors"]})

    def test_row_with_more_cells_than_headers_is_error(self):
        rows = valid_rows()
        with tempfile.TemporaryDirectory() as temp_dir:
            csv_path = Path(temp_dir) / "pilot.csv"
            with csv_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(FIELDNAMES)
                for index, row in enumerate(rows):
                    values = [row[field] for field in FIELDNAMES]
                    writer.writerow(values + (["unexpected"] if index == 0 else []))
            completed = subprocess.run(
                [sys.executable, str(VALIDATOR), str(csv_path)],
                capture_output=True,
                check=False,
                text=True,
            )
            report = json.loads(completed.stdout)

        self.assertEqual(completed.returncode, 1)
        self.assertIn("malformed_row", {item["code"] for item in report["errors"]})

    def test_missing_required_column_is_error(self):
        fieldnames = [name for name in FIELDNAMES if name != "plant_limb"]

        self.assert_error(valid_rows(), "missing_required_columns", fieldnames)

    def test_empty_header_only_file_is_not_mistaken_for_completed_data(self):
        self.assert_error([], "empty_dataset")

    def test_pilot_requires_12_to_15_athletes(self):
        for athlete_count in (11, 16):
            with self.subTest(athlete_count=athlete_count):
                self.assert_error(valid_rows(athlete_count), "invalid_athlete_count")

    def test_handball_is_rejected_from_the_development_sport_pilot(self):
        rows = valid_rows()
        for row in rows:
            if row["athlete_id"] == "P001":
                row["sport"] = "handball"

        self.assert_error(rows, "invalid_sport")

    def test_unregistered_cue_id_is_error(self):
        rows = valid_rows()
        rows[1]["cue_id"] = "GOATA_V1"

        self.assert_error(rows, "invalid_cue_id")

    def test_nonfinite_numeric_value_is_error(self):
        for value in ("NaN", "inf", "-Infinity"):
            with self.subTest(value=value):
                rows = valid_rows()
                rows[0]["phone_task_performance_score"] = value
                self.assert_error(rows, "nonfinite_numeric")

    def test_duplicate_athlete_session_cue_replicate_key_is_error(self):
        rows = valid_rows()
        rows.append(rows[0].copy())

        self.assert_error(rows, "duplicate_observation")

    def test_each_athlete_requires_visits_one_and_two_in_distinct_sessions(self):
        rows = [
            row
            for row in valid_rows()
            if not (row["athlete_id"] == "P001" and row["visit_number"] == "2")
        ]

        self.assert_error(rows, "invalid_visit_structure")

    def test_sport_must_be_consistent_for_an_athlete(self):
        rows = valid_rows()
        for row in rows:
            if row["athlete_id"] == "P001" and row["visit_number"] == "2":
                row["sport"] = "soccer"

        self.assert_error(rows, "inconsistent_sport")

    def test_plant_limb_must_be_consistent_for_an_athlete(self):
        rows = valid_rows()
        for row in rows:
            if row["athlete_id"] == "P001" and row["visit_number"] == "2":
                row["plant_limb"] = "right"

        self.assert_error(rows, "inconsistent_plant_limb")

    def test_every_visit_requires_all_four_active_cues(self):
        rows = [
            row
            for row in valid_rows()
            if not (
                row["athlete_id"] == "P001"
                and row["visit_number"] == "1"
                and row["pair_id"] == "P001-V1-PAIR-4"
            )
        ]

        self.assert_error(rows, "missing_active_cue")

    def test_every_visit_requires_one_practice_attempt_for_each_active_cue(self):
        rows = [
            row
            for row in valid_rows()
            if not (
                row["athlete_id"] == "P001"
                and row["visit_number"] == "1"
                and row["cue_id"] == "FPA_ALIGN_EXIT_V1"
                and row["trial_role"] == "active_practice"
            )
        ]

        self.assert_error(rows, "missing_active_practice")

    def test_every_visit_rejects_a_second_practice_attempt_for_the_same_cue(self):
        rows = valid_rows()
        duplicate_practice = next(
            row.copy()
            for row in rows
            if row["athlete_id"] == "P001"
            and row["visit_number"] == "1"
            and row["cue_id"] == "FPA_ALIGN_EXIT_V1"
            and row["trial_role"] == "active_practice"
        )
        duplicate_practice["replicate"] = "3"
        rows.append(duplicate_practice)

        self.assert_error(rows, "invalid_active_practice_count")

    def test_each_active_observation_requires_one_matched_control(self):
        rows = [
            row
            for row in valid_rows()
            if not (
                row["athlete_id"] == "P001"
                and row["pair_id"] == "P001-V1-PAIR-1"
                and row["cue_id"] == "CTRL_NEUTRAL_V1"
                and row["trial_role"] == "paired_probe"
            )
        ]

        self.assert_error(rows, "invalid_matched_pair")

    def test_every_visit_requires_a_natural_baseline_observation(self):
        rows = [
            row
            for row in valid_rows()
            if not (
                row["athlete_id"] == "P001"
                and row["visit_number"] == "1"
                and row["cue_id"] == "BASE_NATURAL_V1"
            )
        ]

        self.assert_error(rows, "missing_natural_baseline")

    def test_only_registered_completeness_and_failure_statuses_are_allowed(self):
        mutations = {
            "record_status": "almost_complete",
            "attempt_status": "discarded",
            "task_fidelity_status": "looks_okay",
        }
        for field, value in mutations.items():
            with self.subTest(field=field):
                rows = valid_rows()
                rows[0][field] = value
                self.assert_error(rows, f"invalid_{field}")

    def test_complete_record_requires_all_four_paired_measurements(self):
        rows = valid_rows()
        rows[0]["reference_task_performance_score"] = ""

        self.assert_error(rows, "incomplete_complete_record")

    def test_complete_record_requires_all_registered_target_measurements(self):
        rows = valid_rows()
        rows[0]["reference_trunk_lean_toward_exit_at_initial_contact"] = ""

        self.assert_error(rows, "incomplete_complete_record")

    def test_failed_record_requires_a_failure_code(self):
        rows = valid_rows()
        rows[0].update(
            {
                "record_status": "technical_failure",
                "attempt_status": "equipment_failure",
                "performance_acquisition_valid": "false",
                "phone_task_performance_score": "",
                "reference_task_performance_score": "",
                "failure_code": "",
            }
        )

        self.assert_error(rows, "missing_failure_code")

    def test_failure_code_cannot_contain_free_text(self):
        rows = valid_rows()
        rows[0].update(
            {
                "record_status": "safety_failure",
                "attempt_status": "stopped_by_staff",
                "failure_code": "athlete reports sharp pain in right knee",
            }
        )

        self.assert_error(rows, "invalid_failure_code")

    def test_unknown_columns_are_rejected_to_fail_closed_on_private_data(self):
        rows = valid_rows()
        rows[0]["athlete_name"] = "Jane Doe"

        self.assert_error(rows, "unexpected_columns", [*FIELDNAMES, "athlete_name"])

    def test_boolean_acquisition_flags_are_canonical(self):
        rows = valid_rows()
        rows[0]["load_acquisition_valid"] = "yes"

        self.assert_error(rows, "invalid_boolean")

    def test_development_and_prospective_roles_are_rejected(self):
        for phase in ("model_development", "calibration", "policy_validation"):
            with self.subTest(phase=phase):
                rows = valid_rows()
                rows[0]["phase"] = phase
                self.assert_error(rows, "invalid_phase")

    def test_visit_interval_must_be_three_to_seven_days(self):
        rows = valid_rows()
        for row in rows:
            if row["athlete_id"] == "P001" and row["visit_number"] == "2":
                row["study_day"] = "9"

        self.assert_error(rows, "invalid_visit_interval")


if __name__ == "__main__":
    unittest.main()
