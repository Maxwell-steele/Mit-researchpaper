import csv
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from test_validate_pilot import ACTIVE_CUES, FIELDNAMES, complete_row, valid_rows


PILOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PILOT_DIR))

from analyze_reliability import _agreement_stats, _test_retest_stats


ANALYZER = PILOT_DIR / "analyze_reliability.py"
TEMPLATE = PILOT_DIR / "pilot-data-template.csv"

MEASURES = (
    "task_performance_score",
    "foot_exit_alignment_error_at_initial_contact",
    "plant_lateral_offset_normalized",
    "penultimate_deceleration_share",
    "trunk_lean_toward_exit_at_initial_contact",
    "peak_external_knee_abduction_moment_normalized",
)


def set_measurements(rows, reference_value, phone_value=None):
    for row in rows:
        reference = float(reference_value(row))
        phone = float(phone_value(row, reference) if phone_value else reference)
        for measure in MEASURES:
            row[f"reference_{measure}"] = str(reference)
            row[f"phone_{measure}"] = str(phone)


def run_analyzer(rows):
    with tempfile.TemporaryDirectory() as temp_dir:
        csv_path = Path(temp_dir) / "pilot.csv"
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
            writer.writeheader()
            writer.writerows(rows)
        completed = subprocess.run(
            [sys.executable, str(ANALYZER), str(csv_path)],
            capture_output=True,
            check=False,
            text=True,
        )
        report = None
        if completed.stdout.strip():
            report = json.loads(
                completed.stdout,
                parse_constant=lambda value: (_ for _ in ()).throw(
                    AssertionError(f"non-finite JSON constant: {value}")
                ),
            )
        return completed, report


def athlete_number(row):
    return int(row["athlete_id"][1:])


class ReliabilityAnalysisTests(unittest.TestCase):
    def test_hand_calculated_nontrivial_reliability_and_agreement_values(self):
        reliability = _test_retest_stats([(1.0, 2.0), (2.0, 4.0), (4.0, 5.0)])
        difference_stats = _test_retest_stats(
            [(0.0, 1.0), (0.0, 2.0), (0.0, 3.0)]
        )
        agreement_rows = [
            {
                "athlete_id": f"P{index}",
                "reference_task_performance_score": str(reference),
                "phone_task_performance_score": str(2.0 * reference),
            }
            for index, reference in enumerate((1.0, 2.0, 3.0), start=1)
        ]
        agreement = _agreement_stats(agreement_rows, "task_performance_score")

        self.assertAlmostEqual(
            reliability["icc_a_1_two_way_absolute_agreement_single_measure"],
            13.0 / 19.0,
        )
        self.assertEqual(difference_stats["visit_2_minus_visit_1_bias"], 2.0)
        self.assertEqual(difference_stats["sd_visit_differences"], 1.0)
        self.assertAlmostEqual(
            difference_stats["typical_error_sd_diff_over_sqrt_2"],
            1.0 / math.sqrt(2.0),
        )
        self.assertEqual(difference_stats["sdc95_1_96_times_sd_diff"], 1.96)
        self.assertEqual(agreement["bias_phone_minus_reference"], 2.0)
        self.assertEqual(agreement["mean_absolute_error"], 2.0)
        self.assertAlmostEqual(
            agreement["root_mean_squared_error"], math.sqrt(14.0 / 3.0)
        )
        self.assertEqual(agreement["sd_phone_minus_reference"], 1.0)
        self.assertAlmostEqual(agreement["loa_95_lower"], 0.04)
        self.assertAlmostEqual(agreement["loa_95_upper"], 3.96)
        self.assertAlmostEqual(
            agreement["lin_concordance_correlation_coefficient"], 4.0 / 11.0
        )

    def test_perfect_test_retest_and_phone_reference_agreement_equal_one(self):
        rows = valid_rows()
        set_measurements(rows, lambda row: athlete_number(row))

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        stats = report["test_retest"]["BASE_NATURAL_V1"][
            "task_performance_score"
        ]["phone"]
        self.assertEqual(stats["paired_athlete_count"], 12)
        self.assertEqual(stats["visit_1_mean"], 6.5)
        self.assertEqual(stats["visit_2_mean"], 6.5)
        self.assertEqual(stats["visit_2_minus_visit_1_bias"], 0.0)
        self.assertEqual(stats["sd_visit_differences"], 0.0)
        self.assertEqual(stats["typical_error_sd_diff_over_sqrt_2"], 0.0)
        self.assertEqual(stats["sdc95_1_96_times_sd_diff"], 0.0)
        self.assertEqual(
            stats["icc_a_1_two_way_absolute_agreement_single_measure"], 1.0
        )
        agreement = report["phone_reference_agreement"]["task_performance_score"]
        self.assertEqual(agreement["bias_phone_minus_reference"], 0.0)
        self.assertEqual(agreement["mean_absolute_error"], 0.0)
        self.assertEqual(agreement["root_mean_squared_error"], 0.0)
        self.assertEqual(
            agreement["lin_concordance_correlation_coefficient"], 1.0
        )

    def test_lin_ccc_penalizes_a_constant_phone_offset(self):
        rows = valid_rows()
        set_measurements(
            rows,
            lambda row: athlete_number(row) + int(row["visit_number"]) / 10,
            lambda _row, reference: reference + 2.0,
        )

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        stats = report["phone_reference_agreement"]["task_performance_score"]
        self.assertAlmostEqual(stats["bias_phone_minus_reference"], 2.0)
        self.assertAlmostEqual(stats["mean_absolute_error"], 2.0)
        self.assertAlmostEqual(stats["root_mean_squared_error"], 2.0)
        self.assertGreater(stats["lin_concordance_correlation_coefficient"], 0.0)
        self.assertLess(stats["lin_concordance_correlation_coefficient"], 1.0)

    def test_zero_variance_reliability_and_ccc_are_null(self):
        rows = valid_rows()
        set_measurements(rows, lambda _row: 5.0)

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        reliability = report["test_retest"]["BASE_NATURAL_V1"][
            "task_performance_score"
        ]["reference"]
        self.assertIsNone(
            reliability["icc_a_1_two_way_absolute_agreement_single_measure"]
        )
        self.assertEqual(reliability["sd_visit_differences"], 0.0)
        agreement = report["phone_reference_agreement"]["task_performance_score"]
        self.assertIsNone(
            agreement["lin_concordance_correlation_coefficient"]
        )

    def test_invalid_input_is_refused_before_analysis(self):
        completed = subprocess.run(
            [sys.executable, str(ANALYZER), str(TEMPLATE)],
            capture_output=True,
            check=False,
            text=True,
        )
        self.assertEqual(completed.returncode, 1, completed.stderr)
        report = json.loads(completed.stdout)
        self.assertEqual(report["analysis_status"], "refused_invalid_input")
        self.assertFalse(report["input_validation"]["valid"])
        self.assertNotIn("test_retest", report)
        self.assertIn(
            "empty_dataset",
            {item["code"] for item in report["input_validation"]["errors"]},
        )

    def test_practice_and_washout_rows_do_not_leak_into_estimates(self):
        rows = valid_rows()
        for athlete_index in range(1, 13):
            athlete_id = f"P{athlete_index:03d}"
            sport = "basketball" if athlete_index % 2 else "soccer"
            plant_limb = "left" if athlete_index % 2 else "right"
            for visit_number, study_day in ((1, 0), (2, 4)):
                rows.append(
                    complete_row(
                        athlete_id=athlete_id,
                        session_id=f"{athlete_id}-V{visit_number}",
                        visit_number=str(visit_number),
                        study_day=str(study_day),
                        sport=sport,
                        plant_limb=plant_limb,
                        cue_id="CTRL_NEUTRAL_V1",
                        trial_role="washout_reset",
                        replicate="5",
                    )
                )
        set_measurements(rows, lambda row: athlete_number(row))
        for row in rows:
            if row["trial_role"] in {"active_practice", "washout_reset"}:
                for measure in MEASURES:
                    row[f"reference_{measure}"] = "-1000000000"
                    row[f"phone_{measure}"] = "1000000000"

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        completeness = report["completeness"]
        self.assertEqual(completeness["total_input_rows"], 336)
        self.assertEqual(completeness["analysis_attempt_rows"], 216)
        self.assertEqual(completeness["complete_natural_anchor_rows"], 24)
        self.assertEqual(completeness["complete_paired_probe_rows"], 192)
        self.assertEqual(completeness["excluded_complete_active_practice_rows"], 96)
        self.assertEqual(completeness["excluded_complete_washout_reset_rows"], 24)
        agreement = report["phone_reference_agreement"]["task_performance_score"]
        self.assertEqual(agreement["n_attempts"], 216)
        self.assertEqual(agreement["bias_phone_minus_reference"], 0.0)

    def test_repeated_trials_are_aggregated_within_athlete_visit_cue_first(self):
        rows = valid_rows()
        set_measurements(rows, lambda _row: 0.0)
        for visit_number in (1, 2):
            active = next(
                row
                for row in rows
                if row["athlete_id"] == "P001"
                and row["visit_number"] == str(visit_number)
                and row["cue_id"] == "FPA_ALIGN_EXIT_V1"
                and row["trial_role"] == "paired_probe"
            )
            control = next(
                row
                for row in rows
                if row["athlete_id"] == "P001"
                and row["visit_number"] == str(visit_number)
                and row["cue_id"] == "CTRL_NEUTRAL_V1"
                and row["trial_role"] == "paired_probe"
            )
            extra_active = active.copy()
            extra_control = control.copy()
            extra_active.update(
                pair_id=f"P001-V{visit_number}-PAIR-FPA-2", replicate="3"
            )
            extra_control.update(
                pair_id=f"P001-V{visit_number}-PAIR-FPA-2", replicate="5"
            )
            rows.extend((extra_active, extra_control))

        for row in rows:
            if row["cue_id"] != "FPA_ALIGN_EXIT_V1" or row["trial_role"] != "paired_probe":
                continue
            athlete_index = athlete_number(row)
            visit = int(row["visit_number"])
            if athlete_index == 1:
                value = 10.0 if visit == 1 and row["replicate"] == "3" else 0.0
                if visit == 2:
                    value = 6.0
            else:
                value = float(visit - 1)
            row["phone_task_performance_score"] = str(value)
            row["reference_task_performance_score"] = str(value)

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        stats = report["test_retest"]["FPA_ALIGN_EXIT_V1"][
            "task_performance_score"
        ]["phone"]
        self.assertEqual(stats["paired_athlete_count"], 12)
        self.assertAlmostEqual(stats["visit_1_mean"], 5.0 / 12.0)
        self.assertAlmostEqual(stats["visit_2_mean"], 17.0 / 12.0)
        self.assertAlmostEqual(stats["visit_2_minus_visit_1_bias"], 1.0)

    def test_noncomplete_analysis_row_is_excluded_and_counted(self):
        rows = valid_rows()
        set_measurements(rows, lambda row: athlete_number(row))
        failed = next(
            row
            for row in rows
            if row["athlete_id"] == "P001"
            and row["visit_number"] == "2"
            and row["trial_role"] == "natural_anchor"
        )
        failed.update(
            record_status="technical_failure",
            attempt_status="equipment_failure",
            performance_acquisition_valid="false",
            load_acquisition_valid="false",
            failure_code="sensor_failure",
        )
        for measure in MEASURES:
            failed[f"phone_{measure}"] = ""
            failed[f"reference_{measure}"] = ""

        completed, report = run_analyzer(rows)

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(report["completeness"]["excluded_noncomplete_rows"], 1)
        self.assertEqual(report["completeness"]["analysis_attempt_rows"], 215)
        stats = report["test_retest"]["BASE_NATURAL_V1"][
            "task_performance_score"
        ]["phone"]
        self.assertEqual(stats["paired_athlete_count"], 11)

    def test_json_is_deterministic_and_contains_no_nonfinite_numbers(self):
        rows = valid_rows()
        set_measurements(rows, lambda _row: 0.0)

        with tempfile.TemporaryDirectory() as temp_dir:
            csv_path = Path(temp_dir) / "pilot.csv"
            with csv_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
                writer.writeheader()
                writer.writerows(rows)
            command = [sys.executable, str(ANALYZER), str(csv_path)]
            first = subprocess.run(
                command, capture_output=True, check=False, text=True
            )
            second = subprocess.run(
                command, capture_output=True, check=False, text=True
            )
        first_report = json.loads(first.stdout)
        second_report = json.loads(second.stdout)

        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(first.stdout, second.stdout)
        self.assertEqual(first_report, second_report)

        def assert_finite(value):
            if isinstance(value, dict):
                for child in value.values():
                    assert_finite(child)
            elif isinstance(value, list):
                for child in value:
                    assert_finite(child)
            elif isinstance(value, float):
                self.assertTrue(math.isfinite(value))

        assert_finite(first_report)
        self.assertEqual(first_report["analysis_status"], "descriptive_only")
        self.assertIn("without cluster or bootstrap confidence intervals", first_report["limitations"])


if __name__ == "__main__":
    unittest.main()
