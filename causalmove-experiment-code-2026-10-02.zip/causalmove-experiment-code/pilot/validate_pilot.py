#!/usr/bin/env python3
"""Validate the flattened CausalMove reliability-pilot CSV."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable


SCHEMA_VERSION = "causalmove-pilot-v1"

REQUIRED_COLUMNS = (
    "athlete_id",
    "session_id",
    "visit_number",
    "study_day",
    "phase",
    "sport",
    "plant_limb",
    "pair_id",
    "cue_id",
    "trial_role",
    "replicate",
    "record_status",
    "attempt_status",
    "task_fidelity_status",
    "performance_acquisition_valid",
    "load_acquisition_valid",
    "failure_code",
    "phone_task_performance_score",
    "reference_task_performance_score",
    "phone_foot_exit_alignment_error_at_initial_contact",
    "reference_foot_exit_alignment_error_at_initial_contact",
    "phone_plant_lateral_offset_normalized",
    "reference_plant_lateral_offset_normalized",
    "phone_penultimate_deceleration_share",
    "reference_penultimate_deceleration_share",
    "phone_trunk_lean_toward_exit_at_initial_contact",
    "reference_trunk_lean_toward_exit_at_initial_contact",
    "phone_peak_external_knee_abduction_moment_normalized",
    "reference_peak_external_knee_abduction_moment_normalized",
)

ACTIVE_CUES = frozenset(
    {
        "FPA_ALIGN_EXIT_V1",
        "PLANT_OFFSET_REDUCE_V1",
        "BRAKE_EARLIER_V1",
        "TRUNK_TOWARD_EXIT_V1",
    }
)
NATURAL_CUE = "BASE_NATURAL_V1"
CONTROL_CUE = "CTRL_NEUTRAL_V1"
ALLOWED_CUES = ACTIVE_CUES | {NATURAL_CUE, CONTROL_CUE}
ALLOWED_SPORTS = frozenset({"basketball", "soccer"})
ALLOWED_PLANT_LIMBS = frozenset({"left", "right"})
ALLOWED_RECORD_STATUSES = frozenset(
    {"complete", "technical_failure", "task_failure", "safety_failure"}
)
ALLOWED_ATTEMPT_STATUSES = frozenset(
    {"completed", "aborted_before_contact", "stopped_by_staff", "equipment_failure"}
)
ALLOWED_TASK_FIDELITY_STATUSES = frozenset(
    {
        "pass",
        "speed_deviation",
        "path_deviation",
        "angle_deviation",
        "wrong_execution",
        "not_assessable",
    }
)
BOOLEAN_VALUES = frozenset({"true", "false"})
ALLOWED_TRIAL_ROLES = frozenset(
    {"natural_anchor", "active_practice", "paired_probe", "washout_reset"}
)
FAILURE_CODES_BY_STATUS = {
    "technical_failure": frozenset(
        {
            "not_collected",
            "sensor_failure",
            "sync_failure",
            "occlusion",
            "outside_valid_range",
            "processing_failure",
            "calibration_failure",
            "signal_failure",
            "external_interruption",
        }
    ),
    "task_failure": frozenset({"task_induced"}),
    "safety_failure": frozenset({"safety_stop", "withdrawal"}),
}

INTEGER_FIELDS = ("visit_number", "study_day", "replicate")
MEASUREMENT_FIELDS = (
    "phone_task_performance_score",
    "reference_task_performance_score",
    "phone_foot_exit_alignment_error_at_initial_contact",
    "reference_foot_exit_alignment_error_at_initial_contact",
    "phone_plant_lateral_offset_normalized",
    "reference_plant_lateral_offset_normalized",
    "phone_penultimate_deceleration_share",
    "reference_penultimate_deceleration_share",
    "phone_trunk_lean_toward_exit_at_initial_contact",
    "reference_trunk_lean_toward_exit_at_initial_contact",
    "phone_peak_external_knee_abduction_moment_normalized",
    "reference_peak_external_knee_abduction_moment_normalized",
)
PERFORMANCE_FIELDS = (
    "phone_task_performance_score",
    "reference_task_performance_score",
)
LOAD_FIELDS = (
    "phone_peak_external_knee_abduction_moment_normalized",
    "reference_peak_external_knee_abduction_moment_normalized",
)
ROW_REQUIRED_FIELDS = tuple(
    column
    for column in REQUIRED_COLUMNS
    if column not in {"pair_id", "failure_code", *MEASUREMENT_FIELDS}
)


def _issue(code: str, message: str, row: int | None = None) -> dict[str, object]:
    item: dict[str, object] = {"code": code, "message": message}
    if row is not None:
        item["row"] = row
    return item


def _base_report(path: Path) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "file": str(path),
        "valid": False,
        "row_count": 0,
        "athlete_count": 0,
        "session_count": 0,
        "record_status_counts": {},
        "errors": [],
        "warnings": [],
    }


def _add_enum_error(
    errors: list[dict[str, object]],
    row_number: int,
    field: str,
    value: str,
    allowed: Iterable[str],
) -> None:
    if value not in allowed:
        errors.append(
            _issue(
                f"invalid_{field}",
                f"{field} must be one of: {', '.join(sorted(allowed))}",
                row_number,
            )
        )


def _parse_integer(
    errors: list[dict[str, object]], row_number: int, field: str, value: str
) -> int | None:
    try:
        parsed = int(value)
    except ValueError:
        errors.append(_issue("invalid_integer", f"{field} must be an integer", row_number))
        return None
    return parsed


def _validate_numeric(
    errors: list[dict[str, object]], row_number: int, field: str, value: str
) -> None:
    if not value:
        return
    try:
        parsed = float(value)
    except ValueError:
        errors.append(_issue("invalid_numeric", f"{field} must be numeric", row_number))
        return
    if not math.isfinite(parsed):
        errors.append(_issue("nonfinite_numeric", f"{field} must be finite", row_number))


def _validate_complete_record(
    errors: list[dict[str, object]], row_number: int, row: dict[str, str]
) -> None:
    if row["record_status"] != "complete":
        failure_code = row["failure_code"]
        if not failure_code:
            errors.append(
                _issue(
                    "missing_failure_code",
                    "failure_code is required when record_status is not complete",
                    row_number,
                )
            )
        elif row["record_status"] in FAILURE_CODES_BY_STATUS:
            allowed = FAILURE_CODES_BY_STATUS[row["record_status"]]
            if failure_code not in allowed:
                errors.append(
                    _issue(
                        "invalid_failure_code",
                        f"failure_code is not allowed for {row['record_status']}",
                        row_number,
                    )
                )
        return

    if row["failure_code"]:
        errors.append(
            _issue(
                "invalid_failure_code",
                "failure_code must be blank when record_status is complete",
                row_number,
            )
        )

    complete = (
        row["attempt_status"] == "completed"
        and row["task_fidelity_status"] == "pass"
        and row["performance_acquisition_valid"] == "true"
        and row["load_acquisition_valid"] == "true"
        and all(row[field] for field in MEASUREMENT_FIELDS)
    )
    if not complete:
        errors.append(
            _issue(
                "incomplete_complete_record",
                "complete records require a completed/pass attempt, both acquisition flags true, and all registered phone/reference measurements",
                row_number,
            )
        )


def _validate_acquisition_fields(
    errors: list[dict[str, object]], row_number: int, row: dict[str, str]
) -> None:
    requirements = (
        ("performance_acquisition_valid", PERFORMANCE_FIELDS),
        ("load_acquisition_valid", LOAD_FIELDS),
    )
    for flag, fields in requirements:
        if row[flag] == "true" and any(not row[field] for field in fields):
            errors.append(
                _issue(
                    "acquisition_value_missing",
                    f"{flag}=true requires both corresponding phone and reference measurements",
                    row_number,
                )
            )


def _read_csv(
    path: Path, report: dict[str, object]
) -> tuple[list[str], list[dict[str, str]]] | None:
    errors = report["errors"]
    assert isinstance(errors, list)
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            headers = reader.fieldnames or []
            rows = []
            for row_number, raw_row in enumerate(reader, start=2):
                if None in raw_row:
                    errors.append(
                        _issue(
                            "malformed_row",
                            "row has more cells than the header",
                            row_number,
                        )
                    )
                rows.append(
                    {
                        key: (value or "").strip()
                        for key, value in raw_row.items()
                        if key is not None
                    }
                )
    except (OSError, UnicodeError, csv.Error) as exc:
        errors.append(_issue("file_read_error", f"could not read CSV: {exc}"))
        return None
    return headers, rows


def validate(path: Path) -> dict[str, object]:
    report = _base_report(path)
    loaded = _read_csv(path, report)
    if loaded is None:
        return _finish_report(report)

    headers, rows = loaded
    errors: list[dict[str, object]] = report["errors"]  # type: ignore[assignment]
    warnings: list[dict[str, object]] = report["warnings"]  # type: ignore[assignment]
    report["row_count"] = len(rows)

    duplicate_headers = sorted({name for name in headers if headers.count(name) > 1})
    if duplicate_headers:
        errors.append(
            _issue("duplicate_columns", f"duplicate columns: {', '.join(duplicate_headers)}")
        )

    missing = sorted(set(REQUIRED_COLUMNS) - set(headers))
    if missing:
        errors.append(
            _issue("missing_required_columns", f"missing columns: {', '.join(missing)}")
        )
        return _finish_report(report)

    unexpected = sorted(set(headers) - set(REQUIRED_COLUMNS))
    if unexpected:
        errors.append(
            _issue(
                "unexpected_columns",
                f"unexpected columns are rejected to prevent unvalidated private data: {', '.join(unexpected)}",
            )
        )

    if not rows:
        errors.append(_issue("empty_dataset", "the template header is present but no pilot rows exist"))
        return _finish_report(report)

    athlete_ids = {row["athlete_id"] for row in rows if row["athlete_id"]}
    session_ids = {row["session_id"] for row in rows if row["session_id"]}
    report["athlete_count"] = len(athlete_ids)
    report["session_count"] = len(session_ids)
    report["record_status_counts"] = dict(
        sorted(Counter(row["record_status"] for row in rows).items())
    )

    if not 12 <= len(athlete_ids) <= 15:
        errors.append(
            _issue(
                "invalid_athlete_count",
                f"reliability pilot requires 12-15 athletes; found {len(athlete_ids)}",
            )
        )

    observations: dict[tuple[str, str, str, str], int] = {}
    athlete_sports: dict[str, set[str]] = defaultdict(set)
    athlete_limbs: dict[str, set[str]] = defaultdict(set)
    athlete_visits: dict[str, dict[int, set[tuple[str, int]]]] = defaultdict(
        lambda: defaultdict(set)
    )
    session_owners: dict[str, set[tuple[str, int, int]]] = defaultdict(set)
    visit_rows: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    pairs: dict[tuple[str, str, str], list[tuple[int, dict[str, str]]]] = defaultdict(list)

    for row_number, row in enumerate(rows, start=2):
        for field in ROW_REQUIRED_FIELDS:
            if not row[field]:
                errors.append(
                    _issue("blank_required_field", f"{field} cannot be blank", row_number)
                )

        _add_enum_error(errors, row_number, "phase", row["phase"], {"reliability_pilot"})
        _add_enum_error(errors, row_number, "sport", row["sport"], ALLOWED_SPORTS)
        _add_enum_error(
            errors, row_number, "plant_limb", row["plant_limb"], ALLOWED_PLANT_LIMBS
        )
        _add_enum_error(errors, row_number, "cue_id", row["cue_id"], ALLOWED_CUES)
        _add_enum_error(
            errors, row_number, "trial_role", row["trial_role"], ALLOWED_TRIAL_ROLES
        )
        _add_enum_error(
            errors,
            row_number,
            "record_status",
            row["record_status"],
            ALLOWED_RECORD_STATUSES,
        )
        _add_enum_error(
            errors,
            row_number,
            "attempt_status",
            row["attempt_status"],
            ALLOWED_ATTEMPT_STATUSES,
        )
        _add_enum_error(
            errors,
            row_number,
            "task_fidelity_status",
            row["task_fidelity_status"],
            ALLOWED_TASK_FIDELITY_STATUSES,
        )
        for field in ("performance_acquisition_valid", "load_acquisition_valid"):
            if row[field] not in BOOLEAN_VALUES:
                errors.append(
                    _issue("invalid_boolean", f"{field} must be true or false", row_number)
                )

        parsed_integers = {
            field: _parse_integer(errors, row_number, field, row[field])
            for field in INTEGER_FIELDS
            if row[field]
        }
        visit_number = parsed_integers.get("visit_number")
        study_day = parsed_integers.get("study_day")
        replicate = parsed_integers.get("replicate")
        if visit_number is not None and visit_number not in {1, 2}:
            errors.append(
                _issue("invalid_visit_number", "visit_number must be 1 or 2", row_number)
            )
        if study_day is not None and study_day < 0:
            errors.append(_issue("invalid_study_day", "study_day cannot be negative", row_number))
        if replicate is not None and replicate < 1:
            errors.append(_issue("invalid_replicate", "replicate must be positive", row_number))
        for field in MEASUREMENT_FIELDS:
            _validate_numeric(errors, row_number, field, row[field])

        _validate_complete_record(errors, row_number, row)
        _validate_acquisition_fields(errors, row_number, row)

        key = (row["athlete_id"], row["session_id"], row["cue_id"], row["replicate"])
        if key in observations:
            errors.append(
                _issue(
                    "duplicate_observation",
                    f"duplicate athlete/session/cue/replicate key; first seen on row {observations[key]}",
                    row_number,
                )
            )
        else:
            observations[key] = row_number

        athlete_id = row["athlete_id"]
        session_id = row["session_id"]
        if athlete_id:
            athlete_sports[athlete_id].add(row["sport"])
            athlete_limbs[athlete_id].add(row["plant_limb"])
        if athlete_id and session_id and visit_number in {1, 2} and study_day is not None:
            athlete_visits[athlete_id][visit_number].add((session_id, study_day))
            session_owners[session_id].add((athlete_id, visit_number, study_day))
            visit_rows[(athlete_id, session_id)].append(row)

        expected_cues_by_role = {
            "natural_anchor": {NATURAL_CUE},
            "active_practice": ACTIVE_CUES,
            "paired_probe": ACTIVE_CUES | {CONTROL_CUE},
            "washout_reset": {CONTROL_CUE},
        }
        trial_role = row["trial_role"]
        if trial_role in expected_cues_by_role and row["cue_id"] not in expected_cues_by_role[trial_role]:
            errors.append(
                _issue(
                    "invalid_trial_role_cue",
                    f"{trial_role} is incompatible with cue_id {row['cue_id']}",
                    row_number,
                )
            )

        if trial_role == "paired_probe":
            if not row["pair_id"]:
                errors.append(
                    _issue(
                        "missing_pair_id",
                        "active and CTRL_NEUTRAL_V1 observations require pair_id",
                        row_number,
                    )
                )
            else:
                pairs[(athlete_id, session_id, row["pair_id"])].append((row_number, row))
        elif row["pair_id"]:
            errors.append(
                _issue(
                    "unexpected_pair_id",
                    "pair_id must be blank unless trial_role is paired_probe",
                    row_number,
                )
            )

    for athlete_id, sports in athlete_sports.items():
        if len(sports) != 1:
            errors.append(
                _issue("inconsistent_sport", f"athlete {athlete_id} has multiple sport values")
            )
    for athlete_id, limbs in athlete_limbs.items():
        if len(limbs) != 1:
            errors.append(
                _issue(
                    "inconsistent_plant_limb",
                    f"athlete {athlete_id} has multiple plant_limb values",
                )
            )

    for session_id, owners in session_owners.items():
        if len(owners) != 1:
            errors.append(
                _issue(
                    "inconsistent_session",
                    f"session {session_id} maps to multiple athlete, visit, or study-day values",
                )
            )

    for athlete_id in sorted(athlete_ids):
        visits = athlete_visits.get(athlete_id, {})
        visit_one = visits.get(1, set())
        visit_two = visits.get(2, set())
        session_names = {session for values in visits.values() for session, _ in values}
        if (
            set(visits) != {1, 2}
            or len(visit_one) != 1
            or len(visit_two) != 1
            or len(session_names) != 2
        ):
            errors.append(
                _issue(
                    "invalid_visit_structure",
                    f"athlete {athlete_id} must have visits 1 and 2 in two distinct sessions",
                )
            )
            continue
        first_day = next(iter(visit_one))[1]
        second_day = next(iter(visit_two))[1]
        if not 3 <= second_day - first_day <= 7:
            errors.append(
                _issue(
                    "invalid_visit_interval",
                    f"athlete {athlete_id} visit interval must be 3-7 study days",
                )
            )

    for (athlete_id, session_id), grouped_rows in visit_rows.items():
        probe_cues = {
            row["cue_id"] for row in grouped_rows if row["trial_role"] == "paired_probe"
        }
        missing_active = sorted(ACTIVE_CUES - probe_cues)
        if missing_active:
            errors.append(
                _issue(
                    "missing_active_cue",
                    f"{athlete_id}/{session_id} lacks active cues: {', '.join(missing_active)}",
                )
            )
        natural_cues = {
            row["cue_id"] for row in grouped_rows if row["trial_role"] == "natural_anchor"
        }
        if NATURAL_CUE not in natural_cues:
            errors.append(
                _issue(
                    "missing_natural_baseline",
                    f"{athlete_id}/{session_id} lacks {NATURAL_CUE}",
                )
            )
        practice_counts = Counter(
            row["cue_id"] for row in grouped_rows if row["trial_role"] == "active_practice"
        )
        missing_practice = sorted(cue for cue in ACTIVE_CUES if practice_counts[cue] == 0)
        if missing_practice:
            errors.append(
                _issue(
                    "missing_active_practice",
                    f"{athlete_id}/{session_id} lacks practice cues: {', '.join(missing_practice)}",
                )
            )
        repeated_practice = sorted(cue for cue in ACTIVE_CUES if practice_counts[cue] > 1)
        if repeated_practice:
            errors.append(
                _issue(
                    "invalid_active_practice_count",
                    f"{athlete_id}/{session_id} has more than one practice attempt for: {', '.join(repeated_practice)}",
                )
            )

    for (athlete_id, session_id, pair_id), pair_rows in pairs.items():
        cue_ids = [row["cue_id"] for _, row in pair_rows]
        active_ids = [cue_id for cue_id in cue_ids if cue_id in ACTIVE_CUES]
        valid_pair = (
            len(pair_rows) == 2
            and cue_ids.count(CONTROL_CUE) == 1
            and len(active_ids) == 1
        )
        if not valid_pair:
            errors.append(
                _issue(
                    "invalid_matched_pair",
                    f"{athlete_id}/{session_id}/{pair_id} must contain exactly one active cue and one {CONTROL_CUE}",
                )
            )

    return _finish_report(report)


def _finish_report(report: dict[str, object]) -> dict[str, object]:
    errors = report["errors"]
    warnings = report["warnings"]
    assert isinstance(errors, list) and isinstance(warnings, list)
    report["error_count"] = len(errors)
    report["warning_count"] = len(warnings)
    report["valid"] = not errors
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path, help="pilot CSV to validate")
    args = parser.parse_args(argv)
    report = validate(args.csv_path)
    print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
