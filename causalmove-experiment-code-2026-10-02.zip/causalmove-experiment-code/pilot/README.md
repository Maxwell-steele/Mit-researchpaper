# CausalMove reliability-pilot data check

This folder provides a header-only CSV template and a standard-library validator for the preregistered two-visit reliability pilot. It is intentionally separate from model-development and prospective-validation data.

The folder currently contains only the strict flat-CSV validator and descriptive analyzer. The proposed randomization runtime, immutable audit bundle, partial-session reconciliation, and `--audit-bundle` analysis mode are not implemented and must not be represented as available field controls.

## Files

- `pilot-approval-record.md`: restricted fillable gate for ethics, resources, roles, constants, registries, rehearsal evidence, and domain-specific signatures. Its default state is `NO-GO`.
- `pilot-session-runbook.md`: operator-facing visit sequence and failure-handling guide; it cannot be used until the approval record is complete and signed.
- `pilot-data-template.csv`: the required columns, with no example or fabricated athlete rows.
- `validate_pilot.py`: structural validation with machine-readable JSON output.
- `analyze_reliability.py`: descriptive test-retest and phone-reference estimates after structural validation.
- `tests/test_validate_pilot.py`: behavioral tests for accepted and rejected files.
- `tests/test_analyze_reliability.py`: hand-checkable analytic, aggregation, and leakage tests.

Copy the template before entering data. Do not add names, dates of birth, team names, contact details, free-text medical history, or other direct identifiers. `athlete_id` and `session_id` must be de-identified study keys.

## Row and visit contract

One row represents one attempted cut, including an unsuccessful or technically incomplete attempt. Do not delete a failed attempt and replace it with only a later successful attempt.

The validator requires:

- 12-15 athletes from the development sports `basketball` and `soccer`. `handball` is excluded because it is the held-out sport.
- `phase=reliability_pilot` on every row. Development, calibration, and prospective-validation roles are rejected.
- visits `1` and `2` in distinct sessions for every athlete, separated by 3-7 `study_day` units.
- one consistent `sport` and assigned anatomical `plant_limb` (`left` or `right`) per athlete. An observed wrong-limb execution remains in the canonical attempt log and is represented here through the task-failure fields.
- at least one `BASE_NATURAL_V1` anchor observation in each visit.
- one unpaired practice attempt for each active cue in each visit.
- all four active cues as paired probes in each visit: `FPA_ALIGN_EXIT_V1`, `PLANT_OFFSET_REDUCE_V1`, `BRAKE_EARLIER_V1`, and `TRUNK_TOWARD_EXIT_V1`.
- exactly one `CTRL_NEUTRAL_V1` paired-probe row matched to each active paired-probe row by `athlete_id`, `session_id`, and `pair_id`.
- a unique (`athlete_id`, `session_id`, `cue_id`, `replicate`) key. Because controls repeat, give each control row a distinct positive `replicate` within a session.
- a `trial_role` compatible with the cue: `natural_anchor` for `BASE_NATURAL_V1`, `active_practice` for an active cue, `paired_probe` for an active cue or `CTRL_NEUTRAL_V1`, and `washout_reset` for unpaired `CTRL_NEUTRAL_V1` reset attempts.
- a `pair_id` only for `paired_probe` rows. Every other role leaves it blank.

The file does not encode the locked values of `B_0,pilot` or `B_pair,pilot`. Before collection, the study team must separately lock those counts and verify that the observed replicate counts match them.

## Status fields

`record_status` is the pilot-flat-file summary status:

- `complete`
- `technical_failure`
- `task_failure`
- `safety_failure`

`attempt_status` uses the trial dictionary values:

- `completed`
- `aborted_before_contact`
- `stopped_by_staff`
- `equipment_failure`

`task_fidelity_status` must be one of `pass`, `speed_deviation`, `path_deviation`, `angle_deviation`, `wrong_execution`, or `not_assessable`. Acquisition flags must be the literal lowercase values `true` or `false`.

A `complete` row requires `attempt_status=completed`, `task_fidelity_status=pass`, both acquisition flags set to `true`, every registered phone/reference measurement, and a blank `failure_code`.

Failed rows require one controlled `failure_code` compatible with their status:

- `technical_failure`: `not_collected`, `sensor_failure`, `sync_failure`, `occlusion`, `outside_valid_range`, `processing_failure`, `calibration_failure`, `signal_failure`, or `external_interruption`;
- `task_failure`: `task_induced`;
- `safety_failure`: `safety_stop` or `withdrawal`.

Do not place symptoms, medical narratives, or other free text in `failure_code`. The validator checks the code, but it cannot decide whether the original clinical or procedural classification was correct.

All supplied numeric values must be finite. The paired phone/reference measurements cover:

- dimensionless log task-performance score;
- foot-to-exit alignment error in degrees;
- stature-normalized lateral plant offset;
- dimensionless penultimate deceleration share;
- trunk lean toward the exit in degrees;
- normalized peak external knee abduction moment in N*m/kg.

The `reference_peak_external_knee_abduction_moment_normalized` value is valid only when synchronized force and validated 3D kinematics exist. The phone field is a model estimate, not a direct joint-moment measurement.

## Run

From the project root:

```bash
python3 athlete-movement-ssac27/pilot/validate_pilot.py path/to/filled-pilot.csv
```

The script writes one JSON report to standard output. It exits `0` when there are no errors and `1` when structural errors exist. Each issue has a stable `code`, a message, and a CSV row number when applicable. Unexpected columns are errors, rather than warnings, so an unreviewed field cannot silently carry identifying or medical text. The JSON always includes both `errors` and `warnings` arrays.

The shipped header-only template intentionally returns `empty_dataset` until real rows are added.

## Descriptive reliability analysis

Run the analyzer only after entering pilot data:

```bash
python3 athlete-movement-ssac27/pilot/analyze_reliability.py path/to/filled-pilot.csv
```

The analyzer calls `validate_pilot.py` first. Invalid input is refused with exit code `1`, `analysis_status=refused_invalid_input`, and the complete structural validation report. A structurally valid file returns exit code `0` and `analysis_status=descriptive_only`.

Only rows with `record_status=complete` and `trial_role` equal to `natural_anchor` or `paired_probe` enter the estimates. Active-practice and washout-reset rows never enter them. For test-retest analysis, repeated attempts are first averaged within athlete, visit, and cue. Visit means therefore use the athletes who have an aggregate at both visits for that cue, measure, and source.

For every cue and registered measure, phone and reference output separately reports:

- paired-athlete count and paired-sample means for Visits 1 and 2;
- mean Visit 2 minus Visit 1 difference;
- sample SD of the athlete-level visit differences;
- typical error, defined as `SD difference / sqrt(2)`;
- SDC95, defined as `1.96 * SD difference`;
- `icc_a_1_two_way_absolute_agreement_single_measure`, the two-way absolute-agreement single-measure ICC(A,1).

ICC is `null` when fewer than two athletes are paired or its variance denominator is zero. It is an absolute-agreement coefficient, so a systematic visit shift is not treated as perfect reliability.

Phone-versus-reference agreement is calculated across the eligible complete attempts, without prior athlete-level averaging. For each measure it reports attempt and athlete counts, phone-minus-reference bias, MAE, RMSE, sample SD of differences, 95% limits of agreement (`bias +/- 1.96 * SD difference`), and Lin's concordance correlation coefficient. Lin CCC is `null` when fewer than two paired attempts exist or its denominator is zero. Unlike correlation alone, Lin CCC penalizes a constant phone-reference offset.

The JSON also reports completeness and exclusion counts. It is deterministic for the same file and uses strict JSON: undefined or non-finite derived statistics are `null`, never `NaN` or `Infinity`.

Run the analyzer on an immutable, access-controlled snapshot. The validator and analyzer read the path sequentially; concurrent replacement of that file is unsupported.

These are descriptive pilot estimates only. The analyzer applies no reliability, agreement, safety, efficacy, or SSAC readiness threshold and provides no cluster-adjusted or bootstrap confidence interval. Do not convert its output into a pass/fail claim before thresholds and the inferential analysis are frozen.

Run the tests with:

```bash
python3 -m unittest discover -s athlete-movement-ssac27/pilot/tests -v
```

## Boundary

Passing this validator means only that the file conforms to the current strict completed-cohort flat-file checks. It does **not** establish scientific pilot completion and does **not** establish or replace:

- ethics approval, consent, medical screening, emergency procedures, or participant safety;
- coach, biomechanist, or safety-lead approval of cues and dose grids;
- correct randomization, allocation concealment, workload limits, washout, or stopping decisions;
- camera, timing-gate, force-plate, synchronization, calibration, or 3D-kinematic validity;
- test-retest reliability, agreement, smallest detectable change, carryover, margin measurability, or statistical power;
- athlete benefit, injury reduction, diagnostic validity, live-game effectiveness, or evidence sufficient for an SSAC submission.

The script cannot determine whether an opaque-looking ID is truly de-identified. A human data steward must inspect source and linkage files before release. The scientific conclusions require the approved protocol, source-file audit, reliability analyses, blinded reference processing, and real prospective results.

The JSON report repeats the input path and may repeat de-identified study keys in issue messages, so keep it restricted until disclosure review. The validator also does not enforce a basketball-versus-soccer allocation because that allocation is not yet locked, and it cannot rule out every contradiction among a failure code, acquisition flags, and partially retained measurements. Freeze the sport allocation and perform a masked failure-state audit before analysis.
