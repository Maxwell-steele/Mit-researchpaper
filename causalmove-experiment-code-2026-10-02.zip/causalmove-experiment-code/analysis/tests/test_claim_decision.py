import unittest

from analysis.claim_decision import ClaimInputError, build_primary_claim_decision


class ClaimDecisionTests(unittest.TestCase):
    @staticmethod
    def payload(*, coverage_lower=0.66, coverage_minimum=0.60, load_upper=0.03,
                load_margin=0.05, performance_upper=-0.03, practical_margin=0.02):
        return {
            "schema_version": "causalmove-claim-input-v1",
            "gate0": {
                "coverage_lower_95": coverage_lower,
                "coverage_minimum": coverage_minimum,
            },
            "gate1": {"load_upper_97_5": load_upper, "load_margin": load_margin},
            "gate2": {
                "performance_upper_95": performance_upper,
                "practical_margin": practical_margin,
            },
        }

    def test_all_boundaries_and_practical_margin_pass(self):
        decision = build_primary_claim_decision(self.payload())

        self.assertEqual(
            decision,
            {
                "schema_version": "causalmove-claim-decision-v1",
                "gate0_pass": True,
                "gate1_boundary_pass": True,
                "gate2_boundary_pass": True,
                "practical_margin_pass": True,
                "confirmatory_claim_pass": True,
                "failed_gates": [],
                "lead_conclusion": (
                    "The personalized policy achieved a practically meaningful improvement "
                    "in the registered acute task-performance score while satisfying "
                    "coverage and load gates."
                ),
            },
        )

    def test_gate0_failure_controls_lead_conclusion(self):
        decision = build_primary_claim_decision(self.payload(coverage_lower=0.59))

        self.assertFalse(decision["confirmatory_claim_pass"])
        self.assertFalse(decision["practical_margin_pass"])
        self.assertEqual(decision["failed_gates"], ["gate0"])
        self.assertEqual(
            decision["lead_conclusion"],
            "The athlete-specific ranking policy was not confirmed because "
            "active-recommendation coverage did not exceed the registered minimum.",
        )

    def test_gate1_failure_controls_lead_conclusion(self):
        decision = build_primary_claim_decision(self.payload(load_upper=0.06))

        self.assertFalse(decision["confirmatory_claim_pass"])
        self.assertFalse(decision["practical_margin_pass"])
        self.assertEqual(decision["failed_gates"], ["gate1"])
        self.assertEqual(
            decision["lead_conclusion"],
            "The athlete-specific ranking policy was not confirmed because "
            "mechanical-load noninferiority to neutral instruction was not established.",
        )

    def test_gate2_failure_controls_lead_conclusion(self):
        decision = build_primary_claim_decision(self.payload(performance_upper=0.01))

        self.assertFalse(decision["confirmatory_claim_pass"])
        self.assertFalse(decision["practical_margin_pass"])
        self.assertEqual(decision["failed_gates"], ["gate2"])
        self.assertEqual(
            decision["lead_conclusion"],
            "The athlete-specific ranking policy was not confirmed because it did not "
            "outperform the frozen population ranking on the registered "
            "task-performance score.",
        )

    def test_statistical_pass_without_practical_margin_uses_narrower_wording(self):
        decision = build_primary_claim_decision(self.payload(performance_upper=-0.01))

        self.assertTrue(decision["confirmatory_claim_pass"])
        self.assertFalse(decision["practical_margin_pass"])
        self.assertEqual(decision["failed_gates"], [])
        self.assertEqual(
            decision["lead_conclusion"],
            "The personalized policy achieved a lower registered acute "
            "task-performance score while satisfying coverage and load gates; the "
            "result did not establish the prespecified practically meaningful margin.",
        )

    def test_gate_and_practical_boundaries_are_strict(self):
        equality_cases = [
            (self.payload(coverage_lower=0.60), "gate0"),
            (self.payload(load_upper=0.05), "gate1"),
            (self.payload(performance_upper=0.0), "gate2"),
        ]
        for payload, failed_gate in equality_cases:
            with self.subTest(failed_gate=failed_gate):
                decision = build_primary_claim_decision(payload)
                self.assertFalse(decision["confirmatory_claim_pass"])
                self.assertEqual(decision["failed_gates"], [failed_gate])

        practical_equality = build_primary_claim_decision(
            self.payload(performance_upper=-0.02)
        )
        self.assertTrue(practical_equality["confirmatory_claim_pass"])
        self.assertFalse(practical_equality["practical_margin_pass"])

    def test_multiple_boundary_failures_are_listed_in_gate_order(self):
        decision = build_primary_claim_decision(
            self.payload(coverage_lower=0.50, load_upper=0.10, performance_upper=0.01)
        )

        self.assertEqual(decision["failed_gates"], ["gate0", "gate1", "gate2"])
        self.assertIn("coverage", decision["lead_conclusion"])

    def test_rejects_unsupported_schema_version(self):
        payload = self.payload()
        payload["schema_version"] = "future-version"

        with self.assertRaises(ClaimInputError) as caught:
            build_primary_claim_decision(payload)

        self.assertEqual(caught.exception.code, "unsupported_schema_version")

    def test_rejects_missing_and_unexpected_fields(self):
        missing = self.payload()
        del missing["gate1"]["load_margin"]
        with self.assertRaises(ClaimInputError) as caught_missing:
            build_primary_claim_decision(missing)
        self.assertEqual(caught_missing.exception.code, "missing_field")

        unexpected = self.payload()
        unexpected["gate2"]["p_value"] = 0.001
        with self.assertRaises(ClaimInputError) as caught_unexpected:
            build_primary_claim_decision(unexpected)
        self.assertEqual(caught_unexpected.exception.code, "unexpected_field")

    def test_rejects_nonfinite_boolean_and_out_of_domain_numbers(self):
        cases = [
            ("nonfinite", {"gate1": {"load_upper_97_5": float("nan")}}, "nonfinite_number"),
            ("boolean", {"gate2": {"performance_upper_95": True}}, "invalid_number"),
            ("huge_integer", {"gate1": {"load_upper_97_5": 10 ** 1000}}, "invalid_number"),
            ("coverage", {"gate0": {"coverage_lower_95": 1.01}}, "invalid_probability"),
            ("coverage_minimum", {"gate0": {"coverage_minimum": -0.01}}, "invalid_probability"),
            ("load_margin", {"gate1": {"load_margin": 0.0}}, "invalid_positive_number"),
            ("practical_margin", {"gate2": {"practical_margin": -0.01}}, "invalid_positive_number"),
        ]
        for name, replacement, expected_code in cases:
            with self.subTest(name=name):
                payload = self.payload()
                for section, values in replacement.items():
                    payload[section].update(values)
                with self.assertRaises(ClaimInputError) as caught:
                    build_primary_claim_decision(payload)
                self.assertEqual(caught.exception.code, expected_code)

    def test_rejects_non_object_root_and_gate(self):
        with self.assertRaises(ClaimInputError) as caught_root:
            build_primary_claim_decision([])
        self.assertEqual(caught_root.exception.code, "invalid_object")

        payload = self.payload()
        payload["gate0"] = []
        with self.assertRaises(ClaimInputError) as caught_gate:
            build_primary_claim_decision(payload)
        self.assertEqual(caught_gate.exception.code, "invalid_object")


if __name__ == "__main__":
    unittest.main()
