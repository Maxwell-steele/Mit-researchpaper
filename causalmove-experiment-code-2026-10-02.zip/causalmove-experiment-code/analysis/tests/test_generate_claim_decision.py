import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPOSITORY_ROOT / "analysis" / "generate_claim_decision.py"


class GenerateClaimDecisionCliTests(unittest.TestCase):
    VALID_INPUT = (
        '{\n'
        '  "schema_version": "causalmove-claim-input-v1",\n'
        '  "gate0": {"coverage_lower_95": 0.66, "coverage_minimum": 0.60},\n'
        '  "gate1": {"load_upper_97_5": 0.03, "load_margin": 0.05},\n'
        '  "gate2": {"performance_upper_95": -0.03, "practical_margin": 0.02}\n'
        '}\n'
    )

    @staticmethod
    def run_cli(input_path, output_path):
        return subprocess.run(
            [
                sys.executable,
                "-B",
                str(SCRIPT),
                "--input",
                str(input_path),
                "--output",
                str(output_path),
            ],
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
            check=False,
        )

    def test_writes_exact_deterministic_decision_with_input_digest(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            input_path = directory / "gate-estimates.json"
            output_a = directory / "decision-a.json"
            output_b = directory / "decision-b.json"
            input_path.write_text(self.VALID_INPUT, encoding="utf-8")

            first = self.run_cli(input_path, output_a)
            second = self.run_cli(input_path, output_b)

            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertEqual(second.returncode, 0, second.stderr)
            self.assertEqual(first.stderr, "")
            self.assertEqual(second.stderr, "")
            self.assertEqual(output_a.read_bytes(), output_b.read_bytes())

            expected = {
                "schema_version": "causalmove-claim-decision-v1",
                "input_sha256": hashlib.sha256(self.VALID_INPUT.encode("utf-8")).hexdigest(),
                "gate0_pass": True,
                "gate1_boundary_pass": True,
                "gate2_boundary_pass": True,
                "practical_margin_pass": True,
                "confirmatory_claim_pass": True,
                "failed_gates": [],
                "lead_conclusion": (
                    "The personalized policy achieved a practically meaningful improvement "
                    "in the registered acute task-performance score while satisfying "
                    "coverage and load gates."
                ),
            }
            expected_bytes = (
                json.dumps(expected, indent=2, sort_keys=True, allow_nan=False) + "\n"
            ).encode("utf-8")
            self.assertEqual(output_a.read_bytes(), expected_bytes)

    def test_refuses_to_overwrite_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            input_path = directory / "gate-estimates.json"
            output_path = directory / "claim-decision.json"
            input_path.write_text(self.VALID_INPUT, encoding="utf-8")
            output_path.write_text("sentinel\n", encoding="utf-8")

            result = self.run_cli(input_path, output_path)

            self.assertEqual(result.returncode, 2)
            self.assertEqual(json.loads(result.stderr)["code"], "output_exists")
            self.assertEqual(output_path.read_text(encoding="utf-8"), "sentinel\n")

    def test_rejects_malformed_duplicate_and_nonfinite_json_without_output(self):
        invalid_cases = [
            ("malformed", "{\n", "invalid_json"),
            (
                "duplicate",
                self.VALID_INPUT.replace(
                    '"schema_version": "causalmove-claim-input-v1",',
                    '"schema_version": "causalmove-claim-input-v1",\n'
                    '  "schema_version": "causalmove-claim-input-v1",',
                ),
                "duplicate_field",
            ),
            ("nonfinite", self.VALID_INPUT.replace("0.03", "NaN", 1), "nonfinite_number"),
            (
                "oversized_integer",
                self.VALID_INPUT.replace("0.03", "1" * 5000, 1),
                "invalid_number",
            ),
        ]
        for name, raw_input, expected_code in invalid_cases:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                directory = Path(directory)
                input_path = directory / "gate-estimates.json"
                output_path = directory / "claim-decision.json"
                input_path.write_text(raw_input, encoding="utf-8")

                result = self.run_cli(input_path, output_path)

                self.assertEqual(result.returncode, 2)
                error = json.loads(result.stderr)
                self.assertEqual(error["status"], "error")
                self.assertEqual(error["code"], expected_code)
                self.assertFalse(output_path.exists())


if __name__ == "__main__":
    unittest.main()
