"""Analysis helpers that are safe to exercise only with synthetic fixtures before data lock."""
