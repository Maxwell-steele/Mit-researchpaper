#!/usr/bin/env python3
"""Generate one deterministic primary-claim decision from locked gate estimates."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile


if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from analysis.claim_decision import ClaimInputError, build_primary_claim_decision


def _reject_nonfinite_constant(token):
    raise ClaimInputError("nonfinite_number", f"JSON constant {token} is not finite")


def _reject_duplicate_fields(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ClaimInputError("duplicate_field", f"duplicate JSON field: {key}")
        result[key] = value
    return result


def _load_strict_json(input_path):
    try:
        raw_input = input_path.read_bytes()
    except OSError as error:
        raise ClaimInputError("input_read_error", "input file could not be read") from error

    try:
        text = raw_input.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ClaimInputError("invalid_encoding", "input must be UTF-8") from error

    try:
        payload = json.loads(
            text,
            object_pairs_hook=_reject_duplicate_fields,
            parse_constant=_reject_nonfinite_constant,
        )
    except ClaimInputError:
        raise
    except json.JSONDecodeError as error:
        raise ClaimInputError("invalid_json", "input is not valid JSON") from error
    except ValueError as error:
        raise ClaimInputError(
            "invalid_number", "input contains a number outside the supported range"
        ) from error

    return raw_input, payload


def _write_new_file(output_path, payload):
    output_directory = output_path.parent
    if not output_directory.is_dir():
        raise ClaimInputError(
            "output_directory_missing", "output directory does not exist"
        )

    temporary_path = None
    try:
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=".claim-decision-", suffix=".tmp", dir=output_directory
        )
        temporary_path = Path(temporary_name)
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary_path, output_path)
    except FileExistsError as error:
        raise ClaimInputError("output_exists", "output file already exists") from error
    except OSError as error:
        raise ClaimInputError("output_write_error", "output file could not be written") from error
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass


def generate(input_path, output_path):
    raw_input, payload = _load_strict_json(input_path)
    decision = build_primary_claim_decision(payload)
    decision["input_sha256"] = hashlib.sha256(raw_input).hexdigest()
    _write_new_file(output_path, decision)


def _arguments(argv=None):
    parser = argparse.ArgumentParser(
        description="Generate a deterministic primary-claim decision."
    )
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args(argv)


def main(argv=None):
    arguments = _arguments(argv)
    try:
        generate(arguments.input, arguments.output)
    except ClaimInputError as error:
        json.dump(
            {"status": "error", "code": error.code, "message": str(error)},
            sys.stderr,
            sort_keys=True,
        )
        sys.stderr.write("\n")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
