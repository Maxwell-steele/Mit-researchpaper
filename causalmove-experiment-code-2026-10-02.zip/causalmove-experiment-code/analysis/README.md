# Primary Claim-Decision Tool

## Status and scope

This directory contains the deterministic decision boundary for the registered acute primary claim. It is executable software, not a statistical estimator and not athlete evidence. It does not calculate confidence intervals from trial data. It accepts only the already locked Gate 0–2 boundary estimates and converts them into one prespecified conclusion.

The tool controls no independent claim about retention, reactive transfer, phone validity, safety, injury prevention, handball generalization, or training benefit. Those claims require their own registered analyses and evidence.

## Input contract

The input must be UTF-8 JSON with schema version `causalmove-claim-input-v1` and exactly these fields:

```json
{
  "schema_version": "causalmove-claim-input-v1",
  "gate0": {
    "coverage_lower_95": 0.66,
    "coverage_minimum": 0.60
  },
  "gate1": {
    "load_upper_97_5": 0.03,
    "load_margin": 0.05
  },
  "gate2": {
    "performance_upper_95": -0.03,
    "practical_margin": 0.02
  }
}
```

These numbers are an interface example only. They are not CausalMove results and must not enter the paper. In a real locked bundle, `claim-input.json` is generated from the canonical Gate 0–2 files; the reproduction audit must verify field equality before running this tool.

The parser rejects duplicate fields, unknown or missing fields, Boolean values in numeric positions, non-finite numbers, probabilities outside `[0, 1]`, and non-positive margins.

## Decision rules

- Gate 0 passes only when `coverage_lower_95 > coverage_minimum`.
- The Gate 1 boundary passes only when `load_upper_97_5 < load_margin`.
- The Gate 2 boundary passes only when `performance_upper_95 < 0`.
- The registered acute confirmatory claim passes only when all three boundaries pass.
- Practical importance passes only when all three boundaries pass and `performance_upper_95 < -practical_margin`.

Equality fails every strict boundary. `failed_gates` reports all failed numeric boundaries in Gate 0, Gate 1, Gate 2 order; `lead_conclusion` is controlled by the earliest failed gate.

## Run after database lock

```bash
cd "/Users/caokhanhngoc/Documents/ChatGPT/mit sloan sport/athlete-movement-ssac27"
python3 -B analysis/generate_claim_decision.py \
  --input /path/to/locked/results_bundle/claim-input.json \
  --output /path/to/locked/results_bundle/claim-decision.json
```

The output is canonical, sorted JSON with a SHA-256 digest of the exact input bytes. The command refuses an existing output path and returns a single machine-readable JSON error on invalid data or a write failure. `claim-decision.json` must not be edited by hand.

## Test

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest \
  analysis.tests.test_claim_decision \
  analysis.tests.test_generate_claim_decision -v
```

The tests use fabricated boundary values. Passing them establishes only the software decision contract.
