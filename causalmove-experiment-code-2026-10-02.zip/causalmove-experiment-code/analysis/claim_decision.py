"""Deterministic primary-claim decision boundary."""

import math


INPUT_SCHEMA_VERSION = "causalmove-claim-input-v1"
DECISION_SCHEMA_VERSION = "causalmove-claim-decision-v1"


class ClaimInputError(ValueError):
    """Controlled invalid-input error for the claim boundary."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


PRACTICAL_CONCLUSION = (
    "The personalized policy achieved a practically meaningful improvement "
    "in the registered acute task-performance score while satisfying "
    "coverage and load gates."
)

COVERAGE_FAILURE_CONCLUSION = (
    "The athlete-specific ranking policy was not confirmed because "
    "active-recommendation coverage did not exceed the registered minimum."
)

LOAD_FAILURE_CONCLUSION = (
    "The athlete-specific ranking policy was not confirmed because "
    "mechanical-load noninferiority to neutral instruction was not established."
)

PERFORMANCE_FAILURE_CONCLUSION = (
    "The athlete-specific ranking policy was not confirmed because it did not "
    "outperform the frozen population ranking on the registered "
    "task-performance score."
)

STATISTICAL_ONLY_CONCLUSION = (
    "The personalized policy achieved a lower registered acute task-performance "
    "score while satisfying coverage and load gates; the result did not establish "
    "the prespecified practically meaningful margin."
)


def _require_exact_keys(value, expected_keys, path):
    if not isinstance(value, dict):
        raise ClaimInputError("invalid_object", f"{path} must be a JSON object")

    missing = sorted(set(expected_keys) - set(value))
    if missing:
        raise ClaimInputError(
            "missing_field", f"{path} is missing required field: {missing[0]}"
        )

    unexpected = sorted(set(value) - set(expected_keys))
    if unexpected:
        raise ClaimInputError(
            "unexpected_field", f"{path} has unexpected field: {unexpected[0]}"
        )


def _finite_number(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ClaimInputError("invalid_number", f"{path} must be a number")
    try:
        finite = math.isfinite(value)
    except OverflowError as error:
        raise ClaimInputError(
            "invalid_number", f"{path} is outside the supported numeric range"
        ) from error
    if not finite:
        raise ClaimInputError("nonfinite_number", f"{path} must be finite")
    return value


def _probability(value, path):
    value = _finite_number(value, path)
    if not 0 <= value <= 1:
        raise ClaimInputError("invalid_probability", f"{path} must be between 0 and 1")
    return value


def _positive_number(value, path):
    value = _finite_number(value, path)
    if value <= 0:
        raise ClaimInputError("invalid_positive_number", f"{path} must be greater than 0")
    return value


def _validate_payload(payload):
    _require_exact_keys(payload, {"schema_version", "gate0", "gate1", "gate2"}, "input")
    if payload["schema_version"] != INPUT_SCHEMA_VERSION:
        raise ClaimInputError(
            "unsupported_schema_version",
            f"schema_version must be {INPUT_SCHEMA_VERSION}",
        )

    _require_exact_keys(
        payload["gate0"], {"coverage_lower_95", "coverage_minimum"}, "gate0"
    )
    _require_exact_keys(payload["gate1"], {"load_upper_97_5", "load_margin"}, "gate1")
    _require_exact_keys(
        payload["gate2"], {"performance_upper_95", "practical_margin"}, "gate2"
    )

    return {
        "coverage_lower_95": _probability(
            payload["gate0"]["coverage_lower_95"], "gate0.coverage_lower_95"
        ),
        "coverage_minimum": _probability(
            payload["gate0"]["coverage_minimum"], "gate0.coverage_minimum"
        ),
        "load_upper_97_5": _finite_number(
            payload["gate1"]["load_upper_97_5"], "gate1.load_upper_97_5"
        ),
        "load_margin": _positive_number(
            payload["gate1"]["load_margin"], "gate1.load_margin"
        ),
        "performance_upper_95": _finite_number(
            payload["gate2"]["performance_upper_95"], "gate2.performance_upper_95"
        ),
        "practical_margin": _positive_number(
            payload["gate2"]["practical_margin"], "gate2.practical_margin"
        ),
    }


def build_primary_claim_decision(payload):
    values = _validate_payload(payload)
    gate0_pass = values["coverage_lower_95"] > values["coverage_minimum"]
    gate1_pass = values["load_upper_97_5"] < values["load_margin"]
    gate2_pass = values["performance_upper_95"] < 0
    practical_pass = (
        gate0_pass
        and gate1_pass
        and gate2_pass
        and values["performance_upper_95"] < -values["practical_margin"]
    )
    failed_gates = []
    if not gate0_pass:
        failed_gates.append("gate0")
    if not gate1_pass:
        failed_gates.append("gate1")
    if not gate2_pass:
        failed_gates.append("gate2")

    if not gate0_pass:
        lead_conclusion = COVERAGE_FAILURE_CONCLUSION
    elif not gate1_pass:
        lead_conclusion = LOAD_FAILURE_CONCLUSION
    elif not gate2_pass:
        lead_conclusion = PERFORMANCE_FAILURE_CONCLUSION
    elif practical_pass:
        lead_conclusion = PRACTICAL_CONCLUSION
    else:
        lead_conclusion = STATISTICAL_ONLY_CONCLUSION

    return {
        "schema_version": DECISION_SCHEMA_VERSION,
        "gate0_pass": gate0_pass,
        "gate1_boundary_pass": gate1_pass,
        "gate2_boundary_pass": gate2_pass,
        "practical_margin_pass": practical_pass,
        "confirmatory_claim_pass": gate0_pass and gate1_pass and gate2_pass,
        "failed_gates": failed_gates,
        "lead_conclusion": lead_conclusion,
    }
