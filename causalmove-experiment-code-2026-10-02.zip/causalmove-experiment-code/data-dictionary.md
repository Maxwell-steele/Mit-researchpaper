# CausalMove Intervention Dataset: Data Dictionary

## Status and purpose

This is a prospective schema. It contains no observations and no simulated results. It defines the data required to test whether an athlete-specific policy can select a 90-degree cutting cue that improves performance relative to a population cue while satisfying a preregistered mechanical-load constraint.

The unit of randomization is recorded explicitly. The primary causal exposure is the assigned policy or sequence, analysed by intention to treat. Policy output, randomization, physical delivery, and achieved movement are separate entities. Achieved kinematic dose is reserved for adherence, dose-response, and mediation analyses.

## Non-negotiable design rules

1. All camera views, sensor files, and repeated trials from one athlete share one `athlete_id` and remain in the same model-evaluation split.
2. Each assignment and policy-action map is generated and timestamped before its randomized unit starts. Trial outcomes cannot alter either record.
3. Personalized, population, and neutral policy definitions are frozen before the first prospective-validation athlete is enrolled or measured. Their code commit, model hash, candidate cue set, thresholds, population ranking, mapping rules, and training-data cutoff are saved.
4. Natural-baseline trials define athlete-specific feature anchors. Validation trials never update those anchors.
5. Invalid and incomplete trials remain in the release with an explicit status and reason. They are not silently deleted.
6. Joint-moment outcomes require synchronized force and 3D kinematic measurements. Pressure-only measures are labeled plantar-load proxies.
7. Primary outcome definitions, noninferiority margins, QC thresholds, missing-data rules, and analysis populations are locked before validation.
8. No participant is labeled by a commercial movement category. A proprietary framework may be recorded only as optional cue-source provenance when written permission exists.
9. Post-assignment entry speed, path error, achieved angle, plate strike, and cue adherence cannot determine membership in the primary intention-to-treat estimand. Acquisition failure and task-fidelity failure are separate states.
10. An eligible prospective athlete who begins calibration remains in the deployable-policy denominator. Calibration failure creates P, G, and N decision records that all map to one registered structural-neutral planned action; it is a Gate-0 inactive output, not an exclusion or an undefined coverage-failure state.
11. Consent for the public analysis-ready tables and derived inputs required by SSAC is resolved before prospective enrollment. Raw identifiable-video consent remains a separate choice.
12. Every prospective action has a fixed number of pregenerated validation slots. A slot not reached because an earlier action stopped the session is never relabeled as a failure of the unreceived action.
13. Safety review occurs at the candidate-action level while the reviewer is blind to whether P, G, or both selected it. A veto removes that candidate from both policies before their frozen fallback rules run.
14. If a cue-wide suspension occurs after prospective enrollment begins, that validation version closes. Later athletes evaluated under a revised candidate set require a new registry, policy hash, amendment, and validation cohort.

## Canonical release structure

Canonical tabular files are UTF-8 Parquet. TSV mirrors may be supplied for inspection. Time-series arrays remain in their native lossless format and are indexed by `sensor_files.parquet`. Every released file receives a SHA-256 checksum in `release_manifest.tsv`.

| File | One row per | Purpose |
|---|---|---|
| `study_manifest.json` | dataset version | Frozen protocol, outcome, model, and randomization metadata |
| `athletes.parquet` | athlete | De-identified cohort and consent attributes |
| `sessions.parquet` | athlete-session | Session context and readiness |
| `trials.parquet` | attempted cut | Task, order, status, and raw trial context |
| `assignments.parquet` | randomization event | Allocation only; never overwrites delivery or achieved dose |
| `policy_decisions.parquet` | athlete-policy-decision occasion | P, G, and N outputs with separate freeze provenance |
| `safety_action_reviews.parquet` | athlete-candidate-action review | Policy-source-blind veto applied before frozen fallback |
| `planned_actions.parquet` | distinct planned condition block | Registered cue or control action; shared when policies coincide |
| `realized_deliveries.parquet` | attempted trial | Cue text and action actually delivered on that trial |
| `policy_action_map.parquet` | policy label-action mapping | Maps P, G, and N to planned actions without duplicating outcomes |
| `scheduled_action_slots.parquet` | pregenerated validation slot | Fixed denominators and observed, failed, technical, or unexposed status |
| `phone_views.parquet` | trial-camera view | Video metadata, synchronization, calibration, and file link |
| `sensor_files.parquet` | sensor stream | Reference-system and wearable stream metadata |
| `measurements.parquet` | trial-feature | Raw or derived performance, load, and kinematic measures |
| `policy_contrasts.parquet` | athlete-decision-contrast | Derived P-minus-G or P-minus-N analysis values without pretending they are trial measurements |
| `measure_registry.tsv` | versioned measure | Formula, event window, sign, unit, source requirements, and QC contract |
| `athlete_anchors.parquet` | athlete-feature anchor | Baseline center and dispersion locked before validation |
| `dose_measurements.parquet` | trial-target feature | Achieved movement change relative to the locked baseline |
| `qc_events.parquet` | rule evaluation | Machine-readable pass, warning, and failure records |
| `adverse_events.parquet` | event | Symptoms, incidents, relation, and action taken |
| `splits.parquet` | athlete-split membership | Leakage-safe analysis and held-out-sport assignments |
| `release_manifest.tsv` | released file | Privacy tier, consent basis, checksum, and license |
| `cue_registry.tsv` | versioned cue | Approved actions defined in `cue-library.md` |
| `safety_rule_registry.tsv` | versioned safety rule | Unified symptom, workload, event, pause, and stop definitions |

## Shared conventions

| Convention | Contract |
|---|---|
| Identifiers | Opaque strings. Public IDs are newly generated and cannot encode name, date of birth, team, sport, or site. |
| Time | ISO 8601 in UTC for restricted data. Public session timing is expressed as `study_day`, relative to each athlete's first session. |
| Units | SI units unless the unit is part of the field name. Every long-form measurement also has a UCUM-compatible `unit`. |
| Nulls | Use null plus a controlled `missing_reason`. Never use zero, `-1`, or an empty string as a missing-value code. |
| Booleans | `true` or `false`, never `yes`, `no`, `0`, or `1`. |
| Categories | Lowercase snake case values from the enumerations below. Unknown values use `unknown`, not a guessed category. |
| Coordinates | A right-handed task frame: `x_in` follows the incoming path, `x_out` follows the intended exit path, and `z` is vertical. Left and right cuts are reflected into a common analysis frame only in derived files, with the transform saved. |
| Laterality | Store anatomical side as observed. Any side-normalized feature must retain `transform_id` and the original value. |
| Precision | Preserve acquisition precision. Round only in presentation tables, never in the canonical analysis data. |
| Provenance | Each derived value names its input file hashes, processing pipeline version, and code commit. |
| Schema changes | Increment `schema_version`. Never change the meaning of an existing field without a new version. |

## 1. `study_manifest.json`

All fields are required unless marked optional.

| Field | Type | Definition |
|---|---|---|
| `study_id` | string | Stable study identifier |
| `schema_version` | semantic version string | Version of this data contract |
| `dataset_version` | semantic version string | Version of the released observations |
| `protocol_version` | string | Approved protocol identifier |
| `preregistration_uri` | string | Immutable preregistration link or `pending` before registration |
| `cue_library_version` | string | Frozen cue registry version |
| `randomization_spec_hash` | SHA-256 string | Hash of the allocation specification |
| `policy_action_mapping_spec_hash` | SHA-256 string | Frozen P/G/N collision and abstention rules |
| `candidate_phone_configuration_set_hash` | SHA-256 string | Pre-pilot hash of every permitted candidate view, device-range, calibration, synchronization, and acquisition-QC configuration |
| `phone_configuration_acceptance_rule_hash` | SHA-256 string | Pre-pilot hash of the rule that selects or rejects a final configuration using pilot acquisition and reliability evidence only |
| `final_phone_configuration_hash` | SHA-256 string | Hash of the one pilot-qualified configuration used after the reliability pilot; null only while the pilot is still open |
| `final_phone_configuration_frozen_utc` | datetime | Time the final configuration was frozen; null only while the pilot is still open and otherwise before model-development recruitment |
| `primary_performance_measure` | string | Must equal `task_performance_score` for this protocol |
| `primary_performance_contrast` | string | Must equal `policy_performance_contrast_analysis_value`, the athlete-level P-minus-G contrast built from the registered performance measure |
| `primary_load_measure` | string | Must equal `policy_load_contrast_analysis_value`; its registered raw reference constituent is `peak_external_knee_abduction_moment_normalized` |
| `task_failure_value_f_y` | number | Development-locked unfavorable task-performance value |
| `task_failure_penalty_kappa_y` | number | Frozen increment beyond the registered successful-trial upper tail |
| `task_failure_reference_rule_hash` | SHA-256 string | Tail estimator, development subset, and reason hierarchy used to derive (F_Y) |
| `performance_support_best_y_min` | number | Frozen best task-performance-score support bound $Y_{min}$ used only for downstream-unexposed G actions |
| `load_noninferiority_margin` | number | Locked margin in the primary load measure's unit |
| `load_margin_basis` | string | External biomechanical justification fixed before pilot-outcome review; pilot reliability may reject feasibility but cannot set or widen the margin |
| `load_margin_external_justification_hash` | SHA-256 string | External clinical or measurement justification fixed before pilot-outcome review |
| `load_failure_penalty_kappa_l` | number | Positive penalty added to the contrast margin for task- or safety-related missing load |
| `load_failure_contrast_value` | number | Frozen contrast-level value (\delta_L+\kappa_L), not a fabricated raw load |
| `load_failure_contrast_rule_hash` | SHA-256 string | Contrast direction, reason hierarchy, shared-action zero rule, and tipping-point range |
| `load_support_l_min` | number | Frozen lower support bound $L_{min}$ for downstream-unexposed N actions |
| `load_support_l_max` | number | Frozen upper support bound $L_{max}$ for downstream-unexposed P actions |
| `partial_identification_derivation_rule_hash` | SHA-256 string | Development source, tail/support estimators, contrast direction, and all P/G/N substitution rules |
| `support_bound_rule_frozen_utc` | datetime | Must precede access to development outcomes |
| `support_bound_values_frozen_utc` | datetime | Must precede first prospective enrollment, baseline, or calibration measurement |
| `maximum_paired_calibration_replacement_pairs` | integer or null | Provisional field populated only if an approved paired-calibration replacement contract is adopted; otherwise null |
| `decision_score_threshold` | number | Locked load-model score threshold; may be called a probability only after calibration is demonstrated |
| `policy_uncertainty_threshold` | number | Locked maximum uncertainty for issuing a recommendation |
| `primary_estimand` | string | Human-readable intention-to-treat contrast |
| `analysis_plan_hash` | SHA-256 string | Hash of the frozen analysis plan |
| `repository_commit` | Git commit string | Code version used for the release |
| `prospective_freeze_utc` | datetime | Immutable freeze before first prospective enrollment or measurement |
| `first_prospective_enrollment_utc` | datetime | Audit boundary; must follow the freeze |
| `consent_version` | string | Disclosure-reviewed prospective consent form |
| `safety_rule_registry_hash` | SHA-256 string | Unified approved workload and stop rules |
| `created_utc` | datetime | Manifest creation time |

Numerical values are filled at their preregistered times. In particular, \(\delta_L\) and its external basis precede pilot-outcome review; candidate pilot doses, washout, and workload caps precede pilot exposure; explicitly pilot-derived trial counts and measurement thresholds are filled afterward; and all remaining policy values are frozen before the first prospective enrollment or measurement. This document does not invent them.

## 2. `athletes.parquet`

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `study_id` | string | yes | Foreign key to manifest |
| `athlete_id` | string | yes | Unique de-identified athlete key |
| `site_id` | string | yes | De-identified acquisition site |
| `team_cluster_id` | string | yes | De-identified team or training-group cluster; unique singleton code when no teammate is enrolled |
| `sport` | category | yes | `basketball`, `soccer`, `handball`, or protocol-approved addition |
| `competition_level` | category | yes | Registry-defined levels fixed before enrollment |
| `sex_recorded_for_biomechanics` | category | yes | Value and collection rationale approved by ethics board |
| `age_years` | number | restricted | Age at consent. Public release uses `age_band` |
| `age_band` | category | public | Preregistered bins broad enough for disclosure control |
| `height_m` | number | yes | Measured stature |
| `mass_kg` | number | yes | Measured body mass |
| `dominant_leg` | category | yes | `left`, `right`, `mixed`, `unknown`; self-reported definition documented |
| `preferred_cut_side` | category | yes | `left`, `right`, `none`, `unknown` |
| `years_in_sport` | number | optional | Self-reported, nonnegative |
| `eligibility_status` | category | yes | `eligible`, `excluded_before_task`, `withdrew_before_task` |
| `screen_passed` | boolean | yes | Medical/readiness screen result; diagnosis text is never public |
| `public_tabular_consent` | boolean | yes | Consent for de-identified analysis rows |
| `public_derived_biometric_consent` | boolean | yes | Consent for potentially identifying pose, gait, trajectory, and derived model inputs |
| `public_video_consent` | boolean | yes | Separate consent for de-identified video |
| `controlled_raw_consent` | boolean | yes | Consent for controlled raw sensor access |
| `ssac_release_eligible` | boolean | yes | Fixed before prospective outcomes; requires every public input needed for the submitted analysis |
| `release_cohort_designation` | category | yes | `ssac_primary` or prospectively declared `non_ssac_separate` |
| `withdrawal_status` | category | yes | `active`, `withdrawn_keep_prior`, `withdrawn_remove_if_permitted` |

Direct identifiers, team names, exact birth dates, contact information, free-text medical history, and consent forms belong in an access-controlled linkage system outside the research release. Pose, gait, detailed trajectories, exact anthropometry, and rare event combinations are treated as potentially re-identifiable biometrics even after direct identifiers are removed.

## 3. `sessions.parquet`

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `session_id` | string | yes | Unique session key |
| `athlete_id` | string | yes | Athlete foreign key |
| `phase` | category | yes | `screening`, `reliability_pilot`, `model_development`, `calibration`, `policy_validation`, `practice`, `retention`, `transfer` |
| `study_day` | integer | public | Days since this athlete's first session |
| `session_start_utc` | datetime | restricted | Acquisition time |
| `protocol_version` | string | yes | Protocol used in this session |
| `equipment_config_id` | string | yes | Candidate configuration ID during the reliability pilot; the selected final configuration ID during model-development, calibration, policy-validation, practice, retention, and transfer phases |
| `surface_id` | string | yes | Coded playing surface |
| `footwear_category` | category | yes | Preregistered category, with brand/model withheld if identifying |
| `pre_session_readiness` | number | optional | Scale and range identified by `readiness_scale_id` |
| `readiness_scale_id` | string | conditional | Required when readiness is collected |
| `pre_session_pain` | number | optional | Scale and range identified by `pain_scale_id` |
| `pain_scale_id` | string | conditional | Required when pain is collected |
| `maximum_maximal_attempts` | integer | yes | IRB-approved cap including aborted and replacement attempts |
| `attempted_maximal_cuts` | integer | yes | All started maximal attempts, not only valid completions |
| `fatigue_stop_rule_id` | string | yes | Frozen performance-decline or symptom rule |
| `session_completed` | boolean | yes | Whether planned protocol was completed |
| `session_stop_reason` | category | conditional | Required when incomplete: `athlete_request`, `pain_rule`, `fatigue_rule`, `incident`, `equipment`, `protocol`, `other` |

## 4. `trials.parquet`

One row is retained for every attempted cut, including aborted and invalid attempts.

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `trial_id` | string | yes | Unique attempted-cut key |
| `session_id` | string | yes | Session foreign key |
| `athlete_id` | string | yes | Denormalized key for integrity checks |
| `phase` | category | yes | Must match the linked session |
| `block_id` | string | yes | Counterbalanced block key |
| `scheduled_slot_id` | string | conditional | Pregenerated validation-slot key; required for prospective action trials |
| `pair_id` | string | conditional | Cue-control pair key for randomized calibration |
| `pair_replicate` | integer | conditional | Replicate number for the athlete-cue pair |
| `previous_cue_id` | string | conditional | Most recent active cue before this attempt, including across pairs |
| `washout_trial_ids` | list[string] | yes | Ordered neutral reset attempts since the previous active cue; empty only when not required |
| `replacement_of_trial_id` | string | optional | Original attempted trial when this is a protocol-permitted replacement |
| `trial_order_session` | integer | yes | One-based attempt order |
| `trial_order_block` | integer | yes | One-based order within block |
| `task_id` | category | yes | `cut_90` for the primary study |
| `planning_condition` | category | yes | `preplanned` or `reactive` |
| `cut_direction` | category | yes | `left` or `right` in the laboratory frame |
| `plant_limb` | category | yes | `left` or `right` anatomical limb |
| `intended_cut_angle_deg` | number | yes | Protocol target, normally 90 for `cut_90` |
| `requested_effort` | category | yes | Protocol-defined effort stage |
| `entry_speed_target_id` | string | yes | Reference to the preregistered speed corridor |
| `rest_interval_s` | number | yes | Actual rest before the attempt |
| `trial_start_utc` | datetime | restricted | Clock time for source synchronization |
| `assignment_id` | string | conditional | Randomization-event key; required when trial or containing block was randomized |
| `planned_action_id` | string | conditional | Registered intended condition block used for ITT mapping |
| `realized_delivery_id` | string | conditional | Per-trial delivery record, including deviations |
| `attempt_status` | category | yes | `completed`, `aborted_before_contact`, `stopped_by_staff`, `equipment_failure` |
| `performance_acquisition_valid` | boolean | yes | Whether the primary performance instrument produced a usable value |
| `load_acquisition_valid` | boolean | yes | Whether the primary load instrument produced a usable value |
| `acquisition_failure_codes` | list[string] | yes | Hardware, synchronization, calibration, or signal failures only |
| `task_fidelity_status` | category | yes | `pass`, `speed_deviation`, `path_deviation`, `angle_deviation`, `wrong_execution`, or `not_assessable` |
| `task_fidelity_rule_ids` | list[string] | yes | Frozen post-assignment task checks, retained in ITT |
| `safety_related_missingness` | boolean | yes | Outcome absent after symptom, veto, withdrawal, or stopping rule |
| `primary_policy_value_member` | boolean | yes | Set from pre-outcome eligibility and calibration-start rules, never task fidelity |
| `analysis_population` | list[category] | yes | Membership in `policy_value`, `safety`, and exploratory `per_protocol` sets |

Task-fidelity deviations are outcomes of assignment, not acquisition failures. The primary analysis retains their measured outcome or applies the preregistered failure composite. A cue-related plate miss cannot be deleted and replaced by analysing only the later successful strike. Before activating `PLANT_OFFSET_REDUCE_V1`, the pilot must show that the force-capture area covers its full approved envelope; otherwise that cue is retired from any load-endpoint study.

## 5. `assignments.parquet`

This table records randomization only. It does not store what was delivered or what movement was achieved. One allocation may govern a trial, a condition block, a session, or an athlete-level practice arm.

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `assignment_id` | string | yes | Unique allocation key |
| `athlete_id` | string | yes | Athlete foreign key |
| `session_id` | string | yes | Session foreign key |
| `randomization_unit` | category | yes | `trial`, `block`, `session`, or `athlete` |
| `randomization_unit_id` | string | yes | Key of the unit that received the allocation |
| `sequence_id` | string | yes | Counterbalancing sequence |
| `randomization_block_id` | string | yes | Allocation block |
| `position_in_sequence` | integer | yes | One-based sequence position |
| `unique_action_count_k_i` | integer | conditional | Number of distinct P/G/N planned actions after collision mapping |
| `collision_pattern` | category | conditional | `all_distinct`, `p_eq_g`, `p_eq_n`, `g_eq_n`, or `p_eq_g_eq_n` |
| `action_order_sampling_rule_id` | string | conditional | Frozen independent uniform-permutation rule and RNG provenance for the athlete's realized $K_i$ |
| `allocation_spec_version` | string | yes | Frozen randomization implementation |
| `allocation_probability` | number | yes | Probability of the realized assignment under the design; for acute unique-action order, normally `1 / K_i!` |
| `assigned_arm` | category | yes | `probe_sequence`, `acute_condition_order`, `personalized_practice`, `population_practice`, or registered alternative |
| `planned_action_id` | string | conditional | Planned physical action when allocation is action-level |
| `assigned_policy_label` | category | conditional | `personalized` or `population` for randomized practice allocation |
| `assignment_created_utc` | datetime | restricted | Must precede `trial_start_utc` |
| `allocation_concealed_until_utc` | datetime | restricted | Audit of concealment |

The intention-to-treat analysis uses the allocated policy or sequence even after a delivery deviation. Planned action is joined through `planned_actions.parquet`, realized delivery through `realized_deliveries.parquet`, and achieved movement through `dose_measurements.parquet`.

## 6. `phone_views.parquet`

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `view_id` | string | yes | Unique trial-camera key |
| `trial_id` | string | yes | Trial foreign key |
| `camera_role` | category | yes | `frontal_oblique`, `sagittal_oblique`, or registered alternative |
| `device_id` | string | yes | De-identified hardware key |
| `video_uri` | string | yes | Relative repository or controlled-store path |
| `sha256` | string | yes | File checksum |
| `codec` | string | yes | Video encoding |
| `width_px` | integer | yes | Frame width |
| `height_px` | integer | yes | Frame height |
| `nominal_fps` | number | yes | Requested frame rate |
| `measured_fps` | number | yes | Observed frame rate |
| `frame_count` | integer | yes | Decoded frames |
| `clock_domain` | string | yes | Device clock identifier |
| `sync_event_id` | string | yes | Shared event used for alignment |
| `sync_offset_ms` | number | yes | Estimated offset to the study master clock |
| `sync_drift_ms_per_min` | number | yes | Estimated clock drift |
| `intrinsic_calibration_id` | string | yes | Camera intrinsic record |
| `extrinsic_calibration_id` | string | yes | Camera-to-task-frame record |
| `calibration_reprojection_rmse_px` | number | yes | Calibration QC value |
| `missing_frame_fraction` | number | yes | Missing or undecodable frames divided by expected frames |
| `occlusion_fraction_primary_window` | number | yes | Preregistered joint visibility metric |
| `face_deidentification_status` | category | yes | `not_required_restricted`, `blurred_verified`, `cropped_verified`, `failed` |
| `audio_status` | category | yes | `absent`, `removed_verified`, `restricted`, `failed` |

## 7. `sensor_files.parquet`

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `sensor_file_id` | string | yes | Unique stream key |
| `trial_id` | string | conditional | Trial key, or session key for continuous capture |
| `session_id` | string | yes | Session foreign key |
| `modality` | category | yes | `force_plate`, `marker_mocap`, `markerless_reference`, `pressure_insole`, `imu`, `timing_gate` |
| `device_id` | string | yes | De-identified device key |
| `file_uri` | string | yes | Relative path |
| `sha256` | string | yes | File checksum |
| `sampling_rate_hz` | number | yes | Observed sampling rate |
| `coordinate_frame_id` | string | yes | Registered coordinate system |
| `calibration_id` | string | yes | Calibration record |
| `clock_domain` | string | yes | Source clock |
| `sync_offset_ms` | number | yes | Offset to master clock |
| `sync_drift_ms_per_min` | number | yes | Drift estimate |
| `start_sample` | integer | yes | First sample for the linked trial, inclusive |
| `end_sample` | integer | yes | Last sample for the linked trial, inclusive |
| `saturation_detected` | boolean | yes | Sensor range exceeded |
| `signal_qc_status` | category | yes | `pass`, `warning`, `fail` |

## 8. `measurements.parquet`

This long table prevents outcome definitions from being hidden in wide, one-off columns.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `measurement_id` | string | yes | Unique value key |
| `trial_id` | string | yes | Trial foreign key |
| `measure_name` | string | yes | Canonical registry name |
| `value` | number | conditional | Null only with `missing_reason` |
| `unit` | string | yes | UCUM-compatible unit |
| `anatomical_side` | category | yes | `left`, `right`, `bilateral`, `not_applicable` |
| `event_name` | category | yes | `approach`, `penultimate_contact`, `initial_contact`, `weight_acceptance`, `toe_off`, `exit`, or registered event |
| `summary_operation` | category | yes | `instant`, `peak`, `minimum`, `mean`, `integral`, `duration`, `angle_difference` |
| `construct_class` | category | yes | `performance`, `joint_moment_reference`, `external_force`, `plantar_load_proxy`, `kinematic`, `task_fidelity` |
| `analysis_role` | category | yes | `primary`, `secondary`, `exploratory`, `covariate`, `qc_only` |
| `source_modality` | category | yes | Registered acquisition or fused source |
| `source_file_hashes` | list[string] | yes | Input checksums |
| `processing_pipeline_version` | string | yes | Frozen feature code version |
| `repository_commit` | string | yes | Exact code commit |
| `transform_id` | string | optional | Side normalization or coordinate transform |
| `measurement_valid` | boolean | yes | Frozen feature-level QC result |
| `missing_reason` | category | conditional | `not_collected`, `sensor_failure`, `sync_failure`, `occlusion`, `outside_valid_range`, `processing_failure`, `task_induced`, `safety_stop`, `withdrawal`, `not_applicable` |
| `missingness_class` | category | conditional | `technical_plausibly_mar`, `task_induced`, `safety_related`, `administrative`, or `structural` |
| `primary_missingness_treatment` | category | conditional | `observed`, `failure_composite`, `contrast_penalty`, `worst_rank`, `technical_mi`, or `not_primary` under the frozen plan |

### Required trial-level canonical measures

The preregistration designates trial-level `task_performance_score` as the primary performance outcome input. The athlete-level derived primary load outcome, `policy_load_contrast_analysis_value`, belongs in `policy_contrasts.parquet`, not this trial table. `peak_external_knee_abduction_moment_normalized` is its privileged raw reference constituent. Remaining trial measures are secondary, exploratory, covariate, or QC variables.

| Canonical `measure_name` | Unit | Construct | Definition boundary |
|---|---|---|---|
| `entry_speed` | m/s | performance covariate | COM or pelvis speed in the locked approach window |
| `cut_completion_time` | s | performance | Locked start and finish events |
| `task_performance_score` | 1 | performance | `ln(cut_completion_time / 1 s)` for task-complete attempts; frozen $F_Y$ for post-assignment task or safety failure; lower is better |
| `task_completion_indicator` | 1 | task fidelity | One only when the frozen task-completion rule passes; never used alone to drop an ITT row |
| `exit_speed` | m/s | performance | Speed in the locked post-cut window |
| `path_error` | m | task fidelity | Distance from preregistered exit corridor |
| `achieved_cut_angle` | deg | task fidelity | Incoming-to-exit trajectory angle |
| `plant_contact_time` | s | performance | Initial contact to toe-off of plant limb |
| `peak_external_knee_abduction_moment_normalized` | N*m/kg | joint moment reference | Permitted only with synchronized force and validated 3D kinematics |
| `peak_vertical_ground_reaction_force_normalized` | N/kg | external force | Peak vertical force during registered contact |
| `braking_impulse_normalized` | N*s/kg | external force | Time integral of posterior force in the task frame |
| `regional_peak_plantar_pressure` | kPa | plantar load proxy | Region and insole calibration must be registered |
| `regional_pressure_time_integral` | kPa*s | plantar load proxy | Region and integration window must be registered |
| `foot_progression_angle_at_initial_contact` | deg | kinematic | Signed foot long-axis yaw in the task frame |
| `foot_exit_alignment_error_at_initial_contact` | deg | kinematic | Wrapped foot-axis difference from intended exit direction |
| `plant_lateral_offset_normalized` | 1 | kinematic | Plant ankle center relative to projected COM in the registered lateral axis, divided by stature |
| `penultimate_deceleration_share` | 1 | kinematic/performance | Share of approach-to-exit speed loss occurring before plant contact |
| `trunk_lean_toward_exit_at_initial_contact` | deg | kinematic | Signed frontal-plane trunk lean toward intended exit |

Pressure-derived outcomes must never be renamed as knee moment, tissue stress, or injury risk.

### `measure_registry.tsv`

Every `measure_name` used in a locked analysis must resolve to one immutable registry row. A plain-language label is not a measurement definition.

| Field | Definition |
|---|---|
| `measure_name` | Stable canonical measure or contrast identifier |
| `measure_version` | Version of the complete measurement contract |
| `record_level` | `trial` or `athlete_decision_contrast` |
| `construct_class` | Registered construct category |
| `formal_definition` | Equation or executable specification |
| `unit` | UCUM-compatible output unit |
| `favorable_direction` | `higher`, `lower`, or `context_dependent` |
| `anatomical_scope` | Side, segment, or whole-body scope |
| `source_modality_requirements` | Minimum valid sensors or camera views |
| `event_detector_id` | Frozen event-detection algorithm |
| `window_start_rule` | Exact event-relative start |
| `window_end_rule` | Exact event-relative end |
| `filtering_and_resampling_id` | Frozen signal-processing pipeline |
| `coordinate_transform_id` | Task and anatomical frame transform |
| `normalization_rule` | Body-mass, stature, speed, or no normalization |
| `validity_rule_ids` | Required QC checks |
| `missingness_rule_id` | Rule for unavailable or invalid values |
| `reliability_gate_id` | Pilot ICC/SEM/SDC or decision-agreement criterion |
| `reference_method_id` | Gold-standard or privileged reference definition, if applicable |
| `task_completion_rule_id` | Completed-versus-failure rule for a performance composite |
| `task_failure_value_f_y` | Frozen unfavorable value, when applicable |
| `task_failure_penalty_kappa_y` | Development-locked penalty and scale |
| `task_failure_reason_hierarchy_id` | Priority when multiple task or safety failures occur |
| `performance_support_best_y_min` | Frozen best-score support bound for an unexposed G action |
| `load_failure_penalty_kappa_l` | Positive registered contrast penalty beyond $\delta_L$ |
| `load_failure_contrast_value` | Frozen $\delta_L+\kappa_L$ value for nontechnical missing load contrasts |
| `load_failure_reason_hierarchy_id` | Task/safety ordering, shared-action zero rule, and tipping-point range |
| `load_support_l_min` | Frozen lower load support bound for an unexposed N action |
| `load_support_l_max` | Frozen upper load support bound for an unexposed P action |
| `partial_identification_derivation_rule_hash` | Immutable source, estimator, and substitution specification |
| `support_bound_rule_frozen_utc` | Audit time before development-outcome access |
| `support_bound_values_frozen_utc` | Audit time before prospective enrollment or measurement |
| `repository_commit` | Executable implementation version |
| `registry_row_hash` | SHA-256 of the complete row and linked specifications |

For the two primary measures, the registry also stores the exact aggregation level, covariate adjustment, outlier rule, estimand sign, and noninferiority or superiority interpretation. Every primary registry row and linked constant is frozen before the first prospective athlete is enrolled or produces baseline or calibration data.

## 9. `policy_contrasts.parquet`

This table stores analysis values derived across planned actions. It never uses a trial ID as if one trial contained a policy contrast.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `policy_contrast_id` | string | yes | Unique contrast row |
| `athlete_id` | string | yes | Athlete key |
| `decision_occasion_id` | string | yes | Frozen policy-decision occasion |
| `period_id` | string | yes | Registered analysis period or block summary |
| `left_policy_label` | category | yes | `personalized` for a primary contrast |
| `right_policy_label` | category | yes | `population` or `neutral` |
| `left_planned_action_id` | string | yes | Planned action selected by the left policy |
| `right_planned_action_id` | string | yes | Planned action selected by the right policy |
| `contrast_measure_name` | string | yes | Canonical registry identifier; the primary load row uses `policy_load_contrast_analysis_value` |
| `value` | number | conditional | Derived contrast; null only at a registered pre-imputation stage with `missing_reason` |
| `unit` | string | yes | UCUM-compatible unit |
| `derivation_status` | category | yes | `observed`, `failure_composite`, `shared_action_zero`, `contrast_penalty`, `partial_identification`, or `technical_imputation` |
| `source_period_summary_hash` | SHA-256 string | yes | Hash of the fixed-denominator action summaries used by the contrast builder |
| `missing_reason` | category | conditional | Registered reason when a pre-imputation value is null |
| `contrast_builder_version` | string | yes | Frozen builder version |
| `repository_commit` | string | yes | Exact code commit |
| `analysis_role` | category | yes | `primary`, `secondary`, or `exploratory` |

The required primary contrast rows are:

| Canonical `contrast_measure_name` | Unit | Construct | Definition boundary |
|---|---|---|---|
| `policy_performance_contrast_analysis_value` | 1 | task-performance contrast | P-minus-G contrast of registered `task_performance_score` action summaries; includes the frozen failure composite, exact zero for a shared planned action, and the registered least-favourable rule for a downstream-unexposed action; lower is better |
| `policy_load_contrast_analysis_value` | N*m/kg | joint moment contrast | Observed P-minus-N contrast when estimable; frozen $\delta_L+\kappa_L$ for task- or safety-related missingness; exactly zero for a shared planned action |

## 10. `athlete_anchors.parquet`

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `anchor_id` | string | yes | Unique athlete-feature anchor |
| `athlete_id` | string | yes | Athlete key |
| `measure_name` | string | yes | Target feature |
| `anchor_phase` | category | yes | Must be `calibration` or preregistered reliability phase |
| `baseline_trial_ids_hash` | SHA-256 string | yes | Hash of ordered natural-baseline trial IDs |
| `anchor_method` | category | yes | `mean`, `median`, or another preregistered method |
| `baseline_center` | number | yes | Locked natural-movement center |
| `baseline_dispersion` | number | yes | Registered dispersion estimate |
| `smallest_detectable_change` | number | optional | Reliability-pilot value when estimated |
| `unit` | string | yes | Same unit as target measure |
| `locked_utc` | datetime | restricted | Must precede intervention validation |
| `anchor_spec_version` | string | yes | Frozen calculation version |

## 11. `dose_measurements.parquet`

For targeted feature $k$, the directed achieved dose is

\[
d_{itk}=s_k\{m_{itk}-b_{ik}\},
\]

where $m_{itk}$ is the observed feature, $b_{ik}$ is the locked athlete baseline, and $s_k\in\{-1,+1\}$ is the cue registry's fixed direction. A positive dose means movement in the requested direction. It does not mean the movement is beneficial.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `dose_id` | string | yes | Unique trial-feature dose key |
| `trial_id` | string | yes | Trial foreign key |
| `planned_action_id` | string | yes | Intended action retained for intention-to-treat provenance |
| `realized_delivery_id` | string | conditional | Per-trial realized delivery; null only when the slot was not exposed |
| `realized_cue_id` | string | conditional | Cue actually delivered, copied from the realized-delivery record |
| `target_measure_name` | string | yes | Registered feature |
| `observed_value` | number | conditional | Feature value for the trial |
| `anchor_id` | string | yes | Locked baseline reference |
| `baseline_center` | number | yes | Copied from anchor for audit |
| `dose_direction_multiplier` | integer | yes | `-1` or `+1`, fixed by cue version |
| `directed_dose` | number | conditional | Formula above |
| `dose_unit` | string | yes | Target feature unit |
| `planned_target_delta` | number | conditional | Pretrial requested change from the planned action |
| `target_tolerance_id` | string | conditional | Frozen adherence band |
| `adherence_status` | category | yes | `within_target_band`, `same_direction_outside_band`, `opposite_direction`, `unmeasured`, `not_applicable` |
| `measurement_valid` | boolean | yes | Feature QC |
| `missing_reason` | category | conditional | Controlled code |

All registered dose features should be measured in every valid trial where feasible, including control trials. Analyses of achieved dose are secondary because dose is post-assignment behavior.

## 12. `policy_decisions.parquet`

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `policy_decision_id` | string | yes | Unique policy output |
| `decision_occasion_id` | string | yes | Groups the policies evaluated for one athlete and validation occasion |
| `athlete_id` | string | yes | Target athlete |
| `decision_session_id` | string | yes | Session in which decision is made |
| `policy_label` | category | yes | `personalized`, `population`, or fixed `neutral` |
| `policy_definition_id` | string | yes | Frozen algorithm and comparator definition |
| `policy_freeze_hash` | SHA-256 string | yes | Full policy bundle for P, G, or the registered fixed-neutral definition |
| `training_data_cutoff_utc` | datetime | restricted | Latest observation visible to policy; freeze time for neutral |
| `training_trial_ids_hash` | SHA-256 string | yes | Exact calibration set, or registered empty-set hash for neutral |
| `candidate_set_hash` | SHA-256 string | yes | Eligible cue IDs and versions |
| `model_name` | string | conditional | Registered response model; not applicable to fixed neutral |
| `model_version` | string | conditional | Frozen version |
| `model_artifact_hash` | SHA-256 string | conditional | Weights or fitted-state checksum |
| `repository_commit` | string | yes | Inference code commit |
| `population_ranking_hash` | SHA-256 string | conditional | Required for `population`; frozen cue order learned in development only |
| `raw_model_decision` | category | conditional | `recommend` or `abstain` before safety review; not applicable to N |
| `raw_selected_cue_id` | string | conditional | Candidate selected before safety review |
| `safety_action_review_ids` | list[string] | yes | Candidate-level reviews used before frozen fallback; empty only for fixed N or a calibration-failure structural neutral, with status recorded |
| `final_system_decision` | category | yes | `recommend`, `abstain`, or `fixed_neutral` after veto and fallback |
| `final_selected_cue_id` | string | conditional | Required only when the final decision is `recommend` |
| `deliverable_active_decision` | boolean | yes | Gate-0 indicator; false for abstention, fixed neutral, calibration-failure structural neutral, and veto-to-neutral fallback |
| `predicted_performance_contrast` | number | conditional | Contrast to locked reference arm |
| `performance_reference_arm` | category | conditional | Arm used for the predicted performance contrast |
| `performance_contrast_unit` | string | conditional | Unit and favorable sign documented |
| `predicted_load_contrast` | number | conditional | Contrast to baseline or comparator |
| `load_reference_arm` | category | conditional | Arm used for the predicted load contrast |
| `load_contrast_unit` | string | conditional | Primary load unit |
| `load_upper_bound` | number | conditional | Bound used in safety decision |
| `load_bound_type` | string | conditional | Registered interval or posterior-bound definition |
| `constraint_evaluation_status` | category | yes | `evaluated`, `not_applicable_neutral`, or `not_estimable_calibration_failure` |
| `load_margin` | number | conditional | Frozen noninferiority margin; null with explicit not-applicable status for N |
| `prediction_uncertainty` | number | conditional | Registered uncertainty statistic for evaluated P/G output |
| `uncertainty_metric_id` | string | conditional | Frozen definition and scale of uncertainty |
| `feasibility_pass` | boolean | conditional | Target remains within observed/calibrated envelope |
| `load_constraint_pass` | boolean | conditional | Frozen load rule passes |
| `uncertainty_pass` | boolean | conditional | Frozen uncertainty rule passes |
| `abstention_reason` | category | conditional | `no_predicted_gain`, `load_constraint`, `uncertainty`, `out_of_envelope`, `missing_measurement`, `calibration_failed`, `safety_veto`, `cue_suspended`, or `no_eligible_cue` |
| `decision_created_utc` | datetime | restricted | Must precede validation allocation |

The complete prediction vector for every candidate cue is released in a companion long table or serialized model output, not only the winning prediction. The population policy uses the same prospective-athlete performance-eligibility, load, uncertainty, support, and safety screen as P, but cannot use that athlete's estimated performance ordering. P, G, and N each receive a decision row and freeze hash; P and G must be regenerated from their saved freeze bundles. Calibration failure still emits all three rows. Their final decisions map to one structural-neutral planned action with `deliverable_active_decision=false`.

## 13. `safety_action_reviews.parquet`

One row represents the pre-delivery safety review of one candidate action. The reviewer receives the action specification without a P/G source label. If both policies select the same candidate, they reference the same review. A veto removes the candidate from both policy candidate sets before each frozen fallback rule runs.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `safety_action_review_id` | string | yes | Unique review key |
| `decision_occasion_id` | string | yes | Athlete-policy comparison occasion |
| `athlete_id` | string | yes | Athlete foreign key |
| `candidate_action_spec_hash` | SHA-256 string | yes | Cue, version, target, text, demonstration, and safety bundle shown for review |
| `candidate_cue_id` | string | yes | Candidate active cue or registered neutral fallback |
| `candidate_cue_version` | string | yes | Exact registry version |
| `policy_source_visible_to_reviewer` | boolean | yes | Must be false for the confirmatory workflow |
| `review_result` | category | yes | `approved` or `vetoed` |
| `veto_rule_id` | string | conditional | Registry rule requiring veto |
| `reviewer_id` | string | restricted | Authorized safety reviewer |
| `review_created_utc` | datetime | restricted | Must precede final P/G decision and action mapping |
| `safety_registry_hash` | SHA-256 string | yes | Active safety rules |

## 14. `planned_actions.parquet`

One row represents one intended cue or control condition block created before exposure. P, G, and N reuse the same `planned_action_id` when collision or fallback rules resolve them to an identical intended action. Real-world delivery deviations never change planned-action identity.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `planned_action_id` | string | yes | Unique intended condition-block key |
| `athlete_id` | string | yes | Athlete foreign key |
| `session_id` | string | conditional | Planned validation session; null only for structural-neutral no-exposure records |
| `condition_block_id` | string | conditional | Counterbalanced planned block |
| `intended_cue_id` | string | yes | Registered active cue or `CTRL_NEUTRAL_V1` |
| `cue_version` | string | yes | Exact registered version |
| `target_value` | number | conditional | Athlete-specific target fixed before delivery |
| `target_unit` | string | conditional | Unit of the target |
| `target_calculation_hash` | SHA-256 string | conditional | Baseline, increment, envelope, and target rule inputs |
| `planned_display_text_hash` | SHA-256 string | yes | Exact intended instruction text |
| `planned_demonstration_id` | string | optional | Exact approved demonstration, when intended |
| `planned_action_definition_hash` | SHA-256 string | yes | Intended cue ID, version, target, text, demonstration, and safety-rule bundle |
| `planned_validation_slots` | integer | yes | Frozen B-val denominator for this distinct action; zero only for structural-neutral no-exposure records |
| `structural_no_exposure` | boolean | yes | True only for a registered structural-zero action such as calibration failure |
| `action_created_utc` | datetime | restricted | Must precede the first linked trial |

## 15. `realized_deliveries.parquet`

One row records what was actually delivered on one attempted trial. Wrong or partial delivery stays attached to the originally planned action for intention-to-treat analysis and never creates a new P/G/N collision.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `realized_delivery_id` | string | yes | Unique per-attempt delivery key |
| `trial_id` | string | yes | Attempted trial foreign key |
| `planned_action_id` | string | yes | Intended action retained for ITT |
| `realized_cue_id` | string | conditional | Cue actually communicated; null when none was delivered |
| `realized_cue_version` | string | conditional | Exact delivered version when identifiable |
| `realized_target_value` | number | conditional | Target actually communicated |
| `realized_target_unit` | string | conditional | Unit of realized target |
| `realized_display_text_hash` | SHA-256 string | conditional | Actual displayed or spoken text |
| `realized_demonstration_id` | string | optional | Demonstration actually used |
| `realized_delivery_hash` | SHA-256 string | yes | Complete realized content plus delivery-status hash |
| `delivery_status` | category | yes | `as_planned`, `none_delivered`, `wrong_cue`, `partial`, `technical_failure`, or `stopped_before_instruction` |
| `deviation_reason` | category | conditional | Required unless `as_planned` |
| `delivery_operator_id` | string | restricted | De-identified operator key |
| `assessor_blinded` | boolean | yes | Whether the outcome assessor was masked |
| `delivery_created_utc` | datetime | restricted | Audit timestamp |

## 16. `policy_action_map.parquet`

This bridge table prevents outcome duplication when policies resolve to one planned action. P is the personalized policy, G is the population policy, and N is neutral movement.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `policy_action_map_id` | string | yes | Unique bridge-row key |
| `decision_occasion_id` | string | yes | Policy-comparison occasion |
| `athlete_id` | string | yes | Athlete foreign key |
| `policy_label` | category | yes | `personalized`, `population`, or `neutral` |
| `policy_decision_id` | string | yes | P, G, or N decision row |
| `planned_action_id` | string | yes | Intended action used to estimate this policy's ITT outcome |
| `mapping_reason` | category | yes | `direct`, `shared_same_planned_action`, `abstention_to_neutral`, `neutral_reference`, or `calibration_failure_structural_neutral` |
| `performance_contrast_role` | category | yes | `personalized`, `population`, `not_used` |
| `load_contrast_role` | category | yes | `personalized`, `neutral`, `not_used` |
| `mapping_created_utc` | datetime | restricted | Must precede access to validation outcomes |
| `mapping_spec_hash` | SHA-256 string | yes | Frozen collision and abstention rules |

The unique key is (`decision_occasion_id`, `athlete_id`, `policy_label`). Reuse of a `planned_action_id` across policy labels is required, not prohibited, when P=G, P=N, G=N, or P=G=N. Exact zero is assigned only when labels map to the same `planned_action_id` and its complete `planned_action_definition_hash` matches. Realized delivery cannot create or erase that ITT zero. The analysis builder joins a shared outcome once and never copies it into independent rows.

## 17. `scheduled_action_slots.parquet`

The frozen randomizer pregenerates exactly B-val slots for every distinct nonstructural planned action. This table therefore exists even when an attempt never occurs. It separates a failure after an action was received from an action that was never reached because an earlier action stopped the session.

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `scheduled_slot_id` | string | yes | Unique pregenerated slot key |
| `decision_occasion_id` | string | yes | Policy-comparison occasion |
| `athlete_id` | string | yes | Athlete foreign key |
| `planned_action_id` | string | yes | Intended action for this slot |
| `slot_within_action` | integer | yes | One through frozen B-val |
| `scheduled_global_period` | integer | yes | Pregenerated session order |
| `previous_planned_action_id` | string | conditional | Preceding action for carryover adjustment |
| `scheduled_slot_status` | category | yes | `attempted_observed`, `attempted_technical_missing`, `failure_after_action_exposure`, or `unexposed_previous_action_stop` |
| `trial_id` | string | conditional | Required for any attempted slot |
| `event_causing_planned_action_id` | string | conditional | Earlier or current action responsible for a stop, when attributable |
| `primary_performance_slot_value` | number | conditional | Observed task score or frozen F-Y after this action's exposure; null for technical or unexposed slots |
| `primary_slot_handling` | category | yes | `observed`, `failure_composite`, `technical_mi`, or `partial_identification_bound` |
| `handling_rule_id` | string | yes | Frozen denominator, imputation, failure, and bound rule |

An action stopped after one or more exposed trials retains all B-val slots in its denominator. Slots after exposure that are consequences of that action use its registered performance failure composite and contrast-level load penalty. If an earlier different action ends the session, later slots are `unexposed_previous_action_stop`; they are not failures of the unreceived action. For a distinct P/G performance contrast, substitute $F_Y$ for unexposed P and $Y_{min}$ for unexposed G, yielding $F_Y-Y_{min}$ when both are unexposed. For a distinct P/N load contrast, substitute $L_{max}$ for unexposed P and $L_{min}$ for unexposed N, retaining the other observed or technically imputed action value. When an exposed-action load penalty also applies, use the larger of that upper endpoint and $\delta_L+\kappa_L$. Policies sharing one `planned_action_id` with the same complete `planned_action_definition_hash` remain exactly zero under every rule.

## 18. `qc_events.parquet`

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `qc_event_id` | string | yes | Unique check result |
| `entity_type` | category | yes | `session`, `trial`, `view`, `sensor_file`, `measurement`, `policy_decision`, `safety_action_review`, `planned_action`, `realized_delivery`, or `scheduled_action_slot` |
| `entity_id` | string | yes | Checked entity key |
| `rule_id` | string | yes | Frozen QC rule |
| `rule_version` | string | yes | Exact definition |
| `observed_value` | number/string | optional | Value assessed |
| `threshold_value` | number/string | optional | Preregistered threshold |
| `result` | category | yes | `pass`, `warning`, `fail`, `not_applicable` |
| `automated` | boolean | yes | Machine or human assessment |
| `assessor_id` | string | conditional | De-identified assessor for manual checks |
| `assessed_utc` | datetime | restricted | Audit time |
| `notes_code` | string | optional | Controlled reason code, no public free text |

Minimum rules cover entry-speed corridor, path and cut-angle fidelity, full force-plate contact, synchronization, missing frames, camera calibration, marker or keypoint visibility, sensor saturation, cue delivery, and outcome availability. Threshold values come from the frozen protocol.

## 19. `adverse_events.parquet`

| Field | Type | Required | Definition / allowed values |
|---|---:|:---:|---|
| `adverse_event_id` | string | yes | Unique event key |
| `athlete_id` | string | yes | Athlete foreign key |
| `session_id` | string | yes | Session foreign key |
| `trial_id` | string | optional | Trial associated with onset, if any |
| `event_time_relative_s` | number | optional | Time relative to session start for public data |
| `event_category` | category | yes | `pain_increase`, `slip`, `trip`, `fall`, `muscle_symptom`, `joint_symptom`, `dizziness`, `equipment_contact`, `other` |
| `severity` | category | yes | `mild`, `moderate`, `severe`, using protocol definitions |
| `relatedness` | category | yes | `unrelated`, `unlikely`, `possible`, `probable`, `definite`, `unassessed` |
| `serious` | boolean | yes | Per ethics-approved definition |
| `session_action` | category | yes | `continued`, `rested_and_resumed`, `cue_withdrawn`, `session_stopped`, `medical_referral` |
| `resolved_during_session` | boolean | yes | Status at session end |
| `reported_to_oversight` | boolean | yes | Reporting requirement completed |
| `planned_action_id` | string | optional | Intended ITT action at onset |
| `realized_delivery_id` | string | optional | Per-trial delivery at onset, when an attempt occurred |
| `policy_labels_mapped` | list[category] | optional | Policies mapped to the action at onset |
| `public_event_summary` | string | optional | Disclosure-reviewed categorical summary |
| `restricted_clinical_narrative_uri` | string | restricted | Stored outside public repository |

All enrolled athletes contribute to the safety population, including those without valid performance or load outcomes.

## 20. `safety_rule_registry.tsv`

| Field | Type | Definition |
|---|---:|---|
| `safety_rule_id` | string | Stable approved rule identifier |
| `rule_version` | string | Version tied to protocol and consent |
| `pain_scale_id` | string | Instrument, anchors, and range |
| `any_new_or_increased_pain_stop` | boolean | Whether any new or increased pain stops the attempt or session |
| `absolute_pain_stop` | number | Approved absolute stop threshold |
| `pain_increase_stop` | number | Approved increase from session baseline |
| `sharp_pain_stop` | boolean | Whether any sharp pain stops exposure |
| `instability_and_incident_rule` | string | Instability, slip, trip, fall, dizziness, and staff-concern actions |
| `maximum_maximal_attempts` | integer | Session cap including replacements and failed attempts |
| `minimum_recovery_s` | number | Minimum between maximal attempts |
| `fatigue_stop_rule` | string | Frozen performance-decline, exertion, or symptom rule |
| `severity_definitions` | string | Mild, moderate, severe, and serious definitions |
| `relatedness_definitions` | string | Unrelated through definite criteria |
| `cue_suspension_rule` | string | Moderate-or-worse and repeated-mild thresholds |
| `study_pause_rule` | string | Event count or severity that pauses enrollment |
| `ethics_approval_id` | string | Approval or amendment covering this version |
| `registry_row_hash` | SHA-256 string | Complete immutable rule checksum |

All user interfaces, cue records, session checks, and adverse-event logic reference the same active registry row. A conflicting local threshold fails validation.

## 21. `splits.parquet`

| Field | Type | Required | Definition |
|---|---:|:---:|---|
| `split_spec_id` | string | yes | Frozen split definition |
| `split_spec_hash` | SHA-256 string | yes | Hash of complete athlete allocation |
| `athlete_id` | string | yes | Atomic grouping unit |
| `sport` | category | yes | Audit of held-out-sport design |
| `fold_id` | string | yes | Fold or prospective cohort |
| `cohort_role` | category | yes | `reliability_pilot`, `model_development`, or `prospective_validation` |
| `perception_model_role` | category | yes | `train`, `model_selection`, `internal_test`, `prospective_test`, or `not_used` |
| `response_population_role` | category | yes | `population_train`, `model_selection`, `internal_test`, or `not_used` |
| `personal_update_role` | category | yes | `update_input` or `not_used` |
| `prospective_outcome_role` | category | yes | `evaluation` or `not_used` |
| `threshold_role` | category | yes | `pilot_estimation`, `prospective_locked`, or `not_used` |
| `sport_holdout_status` | category | yes | `development_sport`, `held_out_sport`, or `not_applicable` |
| `assignment_created_before_analysis` | boolean | yes | Confirms split was locked before outcome inspection |

All model-development partitions are athlete-disjoint and assigned by the frozen stratified randomizer, never by lexical ID order. Within a prospective athlete, that athlete's permitted calibration trials may have `personal_update_role=update_input` while later locked validation outcomes have `prospective_outcome_role=evaluation`; neither can contribute to population fitting, model selection, or threshold calibration. A held-out-sport athlete may have both of those prospective roles, but must have `response_population_role=not_used` and `threshold_role=prospective_locked`.

## 22. Public-release tiers

| Tier | Access | Permitted contents | Prohibited contents |
|---|---|---|---|
| `r0_internal_linkage` | Named authorized staff only | Consent forms, contact details, exact dates, clinical narratives, re-identification key | Any public or analysis repository |
| `r1_controlled_raw` | Approved researchers under data-use agreement | Raw calibrated video, detailed 3D trajectories, native sensor streams, fine demographics when consented | Direct identifiers, audio not required for analysis, unrestricted redistribution |
| `r2_public_analysis` | Public | Pseudonymous trials, assignments, policy decisions, safety reviews, planned actions, realized deliveries, scheduled slots, policy-action maps, derived measurements, QC, adverse-event categories, code, dictionaries, and consented de-identified media | Exact dates, named teams, free text, faces, voices, GPS, linkage keys |
| `r3_public_aggregate` | Public | Disclosure-reviewed summary tables and figures | Participant-level inference or reconstruction |

The main published analysis must be reproducible from `r2_public_analysis` or from a clearly documented combination of public and ethically justified controlled files. Aggregate-only release is insufficient for a claim that depends on participant-level randomized data. Rare adverse-event combinations and small demographic cells receive a disclosure review before release; any suppression is represented by a code and documented, never silently removed.

### `release_manifest.tsv`

| Field | Type | Definition |
|---|---:|---|
| `file_uri` | string | Relative released path |
| `sha256` | string | File checksum |
| `bytes` | integer | File size |
| `media_type` | string | MIME type |
| `release_tier` | category | `r1_controlled_raw`, `r2_public_analysis`, or `r3_public_aggregate` |
| `consent_basis` | category | Approved consent category |
| `deidentification_method_id` | string | Versioned method |
| `deidentification_verified` | boolean | Second-person or automated-plus-manual check complete |
| `license_id` | string | Data or code license |
| `access_uri` | string | Public or application URL |
| `included_in_primary_analysis` | boolean | Whether the file contributes to a reported primary result |

## Controlled enumerations

Enumerations live in a versioned `enums.json`. At minimum it contains:

```json
{
  "phase": ["screening", "reliability_pilot", "model_development", "calibration", "policy_validation", "practice", "retention", "transfer"],
  "assigned_arm": ["probe_sequence", "acute_condition_order", "personalized_practice", "population_practice"],
  "attempt_status": ["completed", "aborted_before_contact", "stopped_by_staff", "equipment_failure"],
  "qc_result": ["pass", "warning", "fail", "not_applicable"],
  "policy_decision": ["recommend", "abstain", "fixed_neutral"],
  "policy_label": ["personalized", "population", "neutral"],
  "mapping_reason": ["direct", "shared_same_planned_action", "abstention_to_neutral", "neutral_reference", "calibration_failure_structural_neutral"],
  "collision_pattern": ["all_distinct", "p_eq_g", "p_eq_n", "g_eq_n", "p_eq_g_eq_n"],
  "scheduled_slot_status": ["attempted_observed", "attempted_technical_missing", "failure_after_action_exposure", "unexposed_previous_action_stop"],
  "cohort_role": ["reliability_pilot", "model_development", "prospective_validation"],
  "sport_holdout_status": ["development_sport", "held_out_sport", "not_applicable"],
  "release_tier": ["r0_internal_linkage", "r1_controlled_raw", "r2_public_analysis", "r3_public_aggregate"]
}
```

## Automated validation gates

The repository validator should fail before analysis or release when any of these conditions occurs:

- a primary or foreign key is missing or duplicated;
- an assignment or policy-action mapping timestamp follows the start of its linked randomized unit;
- a cue ID or version is absent from the frozen cue registry;
- assigned, planned, realized-delivery, and achieved-dose fields are collapsed into one variable;
- a prospective P or G decision lacks its policy freeze, candidate-set, training-data, population-ranking when applicable, or code hash;
- a policy label has zero or multiple action mappings for one decision occasion;
- a calibration failure lacks three final decision rows mapped to one structural-neutral planned action;
- a vetoed candidate is removed from one policy but not the other, or its reviewer could see policy source;
- P, G, or N choose the same intended action but map to duplicated planned actions without a registered reason;
- two policy labels map to the same action but the analysis builder duplicates its outcome as independent data;
- a realized-delivery deviation changes the planned-action identity or shared-action zero rule;
- a nonstructural prospective action lacks exactly B-val pregenerated slots;
- a slot unexposed after an earlier action's stop is penalized as failure of the unreceived action;
- acute order is not sampled under the frozen rule for the realized `K_i` and collision pattern;
- validation data were visible before the policy freeze;
- the same athlete appears in two population-model development partitions, or a split was formed by sorting identifiers instead of the frozen randomizer;
- a held-out-sport athlete contributes to population fitting, model selection, or threshold estimation;
- post-assignment task fidelity or plate strike determines primary policy-value membership;
- an eligible athlete who begins calibration disappears instead of receiving P/G/N outputs and structural-neutral mapping;
- a safety threshold conflicts with the active safety-rule registry, or prospective data are pooled across a cue-suspension version boundary;
- a joint-moment measure lacks force-plus-3D provenance;
- a pressure measure is labeled as internal joint or tissue load;
- an athlete-level policy contrast is stored as a trial measurement or lacks its source-summary hash;
- an invalid trial is removed rather than retained with a reason;
- a public file contains restricted columns, exact timestamps, unverified faces, voices, GPS, or linkage keys;
- an analysis row lacks the required release consent;
- a released file checksum does not match its manifest entry.

## Analysis-ready derivation

The confirmatory period-summary table is generated by code from the normalized files. It contains one row per athlete, decision occasion, distinct planned action, and fixed-denominator period summary; retains assignment, scheduled-slot, realized-delivery, and policy-map identity; and reports attempted, observed, failed, technical-missing, and unexposed slot counts. A separate contrast builder maps P, G, and N onto those summaries and writes `policy_contrasts.parquet`. It emits exact zero for identical planned actions, applies $d_i^L=\delta_L+\kappa_L$ only to eligible task- or safety-related missing load contrasts after action exposure, and invokes the frozen partial-identification rule for actions unexposed because an earlier action stopped the session. Neither output is hand-edited. The build log saves input checksums, mapping collision counts, every missingness classification, software versions, and output checksums.
