"""Run synthetic operating-characteristic checks for the cue policy."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from dataclasses import asdict, replace
from math import sqrt
from pathlib import Path
from typing import Iterable

import numpy as np

from causal_move import SimulationConfig, run_replication


SCENARIO_COLORS = {
    "heterogeneous": "#0072B2",
    "high_signal": "#D55E00",
    "homogeneous": "#E69F00",
    "boundary": "#009E73",
    "null": "#56B4E9",
    "deployable_null": "#7B3294",
    "unsafe": "#CC79A7",
}

SCENARIO_DESCRIPTIONS = {
    "heterogeneous": "Athlete-specific response variation with held-out-sport shift.",
    "high_signal": "Positive control with lower measurement noise.",
    "homogeneous": "One population cue dominates; personalization should add little.",
    "boundary": "Performance and load effects cluster near policy thresholds.",
    "null": "Every cue has zero performance effect; true P-minus-G value is zero.",
    "deployable_null": (
        "Every cue is equally beneficial and safe; the guard may deploy while true "
        "P-minus-G value remains zero."
    ),
    "unsafe": "All cues exceed the load margin; policy should mostly abstain.",
}

SCENARIO_OVERRIDES = {
    "high_signal": {
        "performance_noise_sd": 0.060,
        "load_noise_sd": 0.006,
    },
    "deployable_null": {
        "performance_noise_sd": 0.060,
        "load_noise_sd": 0.006,
    },
}

DEVELOPMENT_SPORTS = ("basketball", "soccer")
EVALUATION_SPORTS = ("basketball", "soccer", "handball")


def _balanced_sport_counts(
    athletes: int,
    sports: tuple[str, ...],
) -> tuple[tuple[str, int], ...]:
    """Allocate athletes deterministically while differing by at most one."""

    base, remainder = divmod(athletes, len(sports))
    return tuple(
        (sport, base + int(index < remainder))
        for index, sport in enumerate(sports)
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Simulate the proposed study. Outputs are design evidence only."
    )
    parser.add_argument("--repetitions", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument(
        "--development-sizes",
        type=int,
        nargs="+",
        default=(100, 160),
    )
    parser.add_argument(
        "--calibration-block-counts",
        type=int,
        nargs="+",
        default=(4, 8),
    )
    parser.add_argument("--validation-blocks", type=int, default=6)
    parser.add_argument(
        "--evaluation-sizes",
        type=int,
        nargs="+",
        default=(36,),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "simulation",
    )
    return parser.parse_args()


def summarize_runs(
    rows: list[dict[str, float | bool | int | str]],
    repetitions: int,
    scenario: str,
    development_athletes: int,
    calibration_blocks: int,
    validation_blocks: int,
    evaluation_athletes: int,
) -> dict[str, float | int | str | None]:
    policy_names = ("personalized", "population_best", "random_feasible")
    numeric_fields = (
        "primary_gate",
        "performance_superiority_gate",
        "load_noninferiority_gate",
        "performance_difference_observed",
        "personalized_load_observed",
        "personalized_true_load",
        "true_personalized_minus_population",
        "recommendation_coverage",
        "abstention_rate",
        "mean_true_constrained_regret_to_oracle",
        "load_model_score_brier",
        "benefit_model_score_brier",
        "posterior_marginal_95_coverage",
        "guard_calibration_passed",
        "guard_load_upper_critical",
        "guard_performance_lower_critical",
        "guard_audit_minimum_policy_clearances",
        "guard_audit_maximum_load_false_clearance_upper",
        "guard_audit_maximum_performance_false_benefit_upper",
    ) + tuple(
        f"guard_audit_{policy}_{suffix}"
        for policy in policy_names
        for suffix in (
            "clearances",
            "load_false_clearances",
            "load_false_clearance_upper",
            "performance_false_benefits",
            "performance_false_benefit_upper",
        )
    )
    sport_diagnostic_suffixes = (
        "evaluation_athletes",
        "recommendation_coverage",
        "abstention_rate",
        "performance_difference_observed",
        "personalized_load_observed",
        "true_personalized_minus_population",
        "personalized_true_load",
    )
    numeric_fields += tuple(
        field
        for field in sorted(rows[0])
        if field.startswith("sport_")
        and any(field.endswith(f"_{suffix}") for suffix in sport_diagnostic_suffixes)
    )
    summary: dict[str, float | int | str | None] = {
        "evidence_scope": "SYNTHETIC_DESIGN_ONLY",
        "scenario": scenario,
        "development_athletes": development_athletes,
        "calibration_blocks": calibration_blocks,
        "validation_blocks": validation_blocks,
        "evaluation_athletes": evaluation_athletes,
        "repetitions": repetitions,
    }
    for field in (
        "development_sport_counts_json",
        "evaluation_sport_counts_json",
        "heldout_sport",
    ):
        if field not in rows[0]:
            continue
        unique_values = {str(row[field]) for row in rows}
        if len(unique_values) != 1:
            raise ValueError(f"Replications disagree on {field}")
        summary[field] = unique_values.pop()
    for field in numeric_fields:
        values = np.asarray([float(row[field]) for row in rows], dtype=float)
        summary[f"{field}_mean"] = float(np.mean(values))
        summary[f"{field}_sd"] = float(np.std(values, ddof=1))
        summary[f"{field}_mcse"] = float(np.std(values, ddof=1) / np.sqrt(values.size))
        summary[f"{field}_q025"] = float(np.quantile(values, 0.025))
        summary[f"{field}_q975"] = float(np.quantile(values, 0.975))

    pooled_rates = {
        "true_load_violation_rate_when_recommended": (
            "true_load_violation_count",
            "recommended_count",
        ),
        "joint_success_rate_when_recommended": (
            "joint_success_count",
            "recommended_count",
        ),
        "oracle_match_rate_when_recommended": (
            "oracle_match_count",
            "recommended_count",
        ),
        "safety_gate_false_clearance_rate": (
            "safety_gate_false_clearance_count",
            "safety_gate_clearance_count",
        ),
    }
    for policy in policy_names:
        pooled_rates[f"{policy}_true_load_violation_rate_when_recommended"] = (
            f"{policy}_true_load_violation_count",
            f"{policy}_recommended_count",
        )
        pooled_rates[f"{policy}_true_false_benefit_rate_when_recommended"] = (
            f"{policy}_true_false_benefit_count",
            f"{policy}_recommended_count",
        )
    for name, (numerator_field, denominator_field) in pooled_rates.items():
        numerator = sum(int(row[numerator_field]) for row in rows)
        denominator = sum(int(row[denominator_field]) for row in rows)
        summary[f"{name}_numerator"] = numerator
        summary[f"{name}_denominator"] = denominator
        summary[f"{name}_pooled"] = (
            numerator / denominator if denominator else None
        )
    split_manifest = [
        {
            "replication_seed": int(row["seed"]),
            "guard_split_seed": int(row["guard_split_seed"]),
            "guard_split_assignment_hash": str(
                row["guard_split_assignment_hash"]
            ),
        }
        for row in rows
    ]
    manifest_json = json.dumps(split_manifest, separators=(",", ":"))
    summary["guard_split_audit_manifest"] = manifest_json
    summary["guard_split_audit_manifest_sha256"] = hashlib.sha256(
        manifest_json.encode("utf-8")
    ).hexdigest()
    return summary


def run_design(
    repetitions: int,
    master_seed: int,
    development_sizes: Iterable[int],
    calibration_block_counts: Iterable[int],
    validation_blocks: int,
    evaluation_sizes: Iterable[int],
) -> list[dict[str, float | int | str | None]]:
    development_sizes = tuple(development_sizes)
    calibration_block_counts = tuple(calibration_block_counts)
    evaluation_sizes = tuple(evaluation_sizes)
    if repetitions < 2:
        raise ValueError("At least two repetitions are required")
    if not development_sizes or any(size < 80 for size in development_sizes):
        raise ValueError("Every development size must contain at least 80 athletes")
    if len(set(development_sizes)) != len(development_sizes):
        raise ValueError("Development sizes must be unique")
    if (
        not calibration_block_counts
        or any(count < 4 or count % 2 for count in calibration_block_counts)
    ):
        raise ValueError("Calibration block counts must be even and at least four")
    if len(set(calibration_block_counts)) != len(calibration_block_counts):
        raise ValueError("Calibration block counts must be unique")
    if validation_blocks < 2 or validation_blocks % 2:
        raise ValueError("Validation blocks must be a positive even count")
    if not evaluation_sizes or any(size < 6 for size in evaluation_sizes):
        raise ValueError(
            "Every evaluation size must contain at least two athletes per sport"
        )
    if len(set(evaluation_sizes)) != len(evaluation_sizes):
        raise ValueError("Evaluation sizes must be unique")

    scenarios = tuple(SCENARIO_DESCRIPTIONS)
    combinations = [
        (scenario, development_size, calibration_blocks, evaluation_size)
        for scenario in scenarios
        for development_size in development_sizes
        for calibration_blocks in calibration_block_counts
        for evaluation_size in evaluation_sizes
    ]
    seeds = np.random.SeedSequence(master_seed).spawn(len(combinations) * repetitions)
    seed_index = 0
    summaries: list[dict[str, float | int | str | None]] = []

    for scenario, development_size, calibration_blocks, evaluation_size in combinations:
        config = replace(
            SimulationConfig(),
            scenario=scenario,
            development_athletes=development_size,
            development_sport_counts=_balanced_sport_counts(
                development_size,
                DEVELOPMENT_SPORTS,
            ),
            calibration_blocks=calibration_blocks,
            validation_blocks=validation_blocks,
            guard_checking_blocks=validation_blocks,
            evaluation_athletes=evaluation_size,
            evaluation_sport_counts=_balanced_sport_counts(
                evaluation_size,
                EVALUATION_SPORTS,
            ),
            **SCENARIO_OVERRIDES.get(scenario, {}),
        )
        runs: list[dict[str, float | bool | int | str]] = []
        for _ in range(repetitions):
            run_seed = int(seeds[seed_index].generate_state(1, dtype=np.uint32)[0])
            seed_index += 1
            runs.append(run_replication(config, run_seed))
        summaries.append(
            summarize_runs(
                runs,
                repetitions,
                scenario,
                development_size,
                calibration_blocks,
                validation_blocks,
                evaluation_size,
            )
        )
    return summaries


def write_csv(
    rows: list[dict[str, float | int | str | None]],
    path: Path,
) -> None:
    if not rows:
        raise ValueError("Cannot write an empty simulation table")
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_json(
    rows: list[dict[str, float | int | str | None]],
    path: Path,
    args: argparse.Namespace,
) -> None:
    source_paths = (
        Path(__file__).resolve(),
        Path(__file__).resolve().with_name("causal_move.py"),
    )

    def sha256(path_to_hash: Path) -> str:
        return hashlib.sha256(path_to_hash.read_bytes()).hexdigest()

    payload = {
        "schema_version": "1.1.0",
        "evidence_scope": "SYNTHETIC_DESIGN_ONLY",
        "warning": (
            "Synthetic operating characteristics validate software and design behavior only. "
            "They do not show that the policy helps athletes."
        ),
        "run_configuration": {
            "master_seed": args.seed,
            "repetitions": args.repetitions,
            "development_sizes": list(args.development_sizes),
            "calibration_block_counts": list(args.calibration_block_counts),
            "validation_blocks": args.validation_blocks,
            "evaluation_sizes": list(args.evaluation_sizes),
            "base_simulation_config": asdict(SimulationConfig()),
            "scenario_descriptions": SCENARIO_DESCRIPTIONS,
            "scenario_overrides": SCENARIO_OVERRIDES,
        },
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "platform": platform.platform(),
        },
        "source_sha256": {path.name: sha256(path) for path in source_paths},
        "rows": rows,
    }
    path.write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def _map_x(value: int, values: list[int], left: float, right: float) -> float:
    if len(set(values)) == 1:
        return 0.5 * (left + right)
    return left + (value - min(values)) / (max(values) - min(values)) * (right - left)


def _map_y(value: float, top: float, bottom: float) -> float:
    return bottom - value * (bottom - top)


def _wilson_interval(successes: int, total: int) -> tuple[float, float]:
    """Two-sided 95% Wilson interval for a Monte Carlo pass proportion."""

    if total < 1 or successes < 0 or successes > total:
        raise ValueError("Invalid Monte Carlo binomial counts")
    z_value = 1.959963984540054
    proportion = successes / total
    denominator = 1.0 + z_value**2 / total
    center = (proportion + z_value**2 / (2.0 * total)) / denominator
    radius = (
        z_value
        * sqrt(
            proportion * (1.0 - proportion) / total
            + z_value**2 / (4.0 * total**2)
        )
        / denominator
    )
    return max(0.0, center - radius), min(1.0, center + radius)


def write_svg(
    rows: list[dict[str, float | int | str | None]],
    path: Path,
) -> None:
    width, height = 900, 540
    left, right, top, bottom = 90.0, 850.0, 85.0, 450.0
    sizes = sorted({int(row["development_athletes"]) for row in rows})
    block_designs = sorted(
        {
            (int(row["calibration_blocks"]), int(row["validation_blocks"]))
            for row in rows
        }
    )
    dash_cycle = ("none", "12 4", "5 4", "12 4 2 4")
    design_dashes = {
        design: dash_cycle[index % len(dash_cycle)]
        for index, design in enumerate(block_designs)
    }
    pieces = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<title>Synthetic design simulation, not athlete results</title>",
        '<rect width="100%" height="100%" fill="white"/>',
        '<g font-family="Arial, Helvetica, sans-serif" fill="#222">',
        '<text x="450" y="28" text-anchor="middle" font-size="18" font-weight="bold">SYNTHETIC DESIGN SIMULATION — NOT ATHLETE RESULTS</text>',
        '<text x="450" y="51" text-anchor="middle" font-size="13">Development-guard feasibility across N and B-cal; cannot populate an SSAC Results section</text>',
    ]

    for tick in np.linspace(0.0, 1.0, 6):
        y = _map_y(float(tick), top, bottom)
        pieces.append(
            f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" stroke="#D9D9D9" stroke-width="1"/>'
        )
        pieces.append(
            f'<text x="{left - 12}" y="{y + 4:.1f}" text-anchor="end" font-size="13">{tick:.1f}</text>'
        )
    pieces.extend(
        [
            f'<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="#222" stroke-width="1.5"/>',
            f'<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="#222" stroke-width="1.5"/>',
        ]
    )
    for size in sizes:
        x = _map_x(size, sizes, left, right)
        pieces.append(
            f'<line x1="{x:.1f}" y1="{bottom}" x2="{x:.1f}" y2="{bottom + 6}" stroke="#222"/>'
        )
        pieces.append(
            f'<text x="{x:.1f}" y="{bottom + 25}" text-anchor="middle" font-size="13">{size}</text>'
        )

    for scenario, color in SCENARIO_COLORS.items():
        for design in block_designs:
            scenario_rows = [
                row
                for row in rows
                if row["scenario"] == scenario
                and int(row["calibration_blocks"]) == design[0]
                and int(row["validation_blocks"]) == design[1]
            ]
            points: list[str] = []
            for development_size in sizes:
                same_size = [
                    row
                    for row in scenario_rows
                    if int(row["development_athletes"]) == development_size
                ]
                if not same_size:
                    continue
                rate = float(
                    np.mean(
                        [
                            float(row["guard_calibration_passed_mean"])
                            for row in same_size
                        ]
                    )
                )
                repetitions = sum(int(row["repetitions"]) for row in same_size)
                successes = int(round(rate * repetitions))
                lower_rate, upper_rate = _wilson_interval(successes, repetitions)
                x = _map_x(development_size, sizes, left, right)
                y = _map_y(rate, top, bottom)
                lower_y = _map_y(lower_rate, top, bottom)
                upper_y = _map_y(upper_rate, top, bottom)
                points.append(f"{x:.1f},{y:.1f}")
                pieces.append(
                    f'<line x1="{x:.1f}" y1="{upper_y:.1f}" x2="{x:.1f}" y2="{lower_y:.1f}" stroke="{color}" stroke-width="1.2"/>'
                )
                pieces.append(
                    f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="white" stroke="{color}" stroke-width="2"/>'
                )
            if points:
                pieces.append(
                    f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="2.2" stroke-dasharray="{design_dashes[design]}"/>'
                )

    pieces.extend(
        [
            f'<text x="{(left + right) / 2:.1f}" y="{height - 35}" text-anchor="middle" font-size="15">Development athletes</text>',
            f'<text x="25" y="{(top + bottom) / 2:.1f}" text-anchor="middle" font-size="15" transform="rotate(-90 25 {(top + bottom) / 2:.1f})">Simulated probability development guard passes</text>',
        ]
    )
    legend_x, legend_y = 600.0, 92.0
    for index, scenario in enumerate(SCENARIO_DESCRIPTIONS):
        y = legend_y + 22 * index
        color = SCENARIO_COLORS[scenario]
        pieces.append(
            f'<line x1="{legend_x}" y1="{y}" x2="{legend_x + 38}" y2="{y}" stroke="{color}" stroke-width="2.5"/>'
        )
        pieces.append(
            f'<text x="{legend_x + 48}" y="{y + 4}" font-size="12">{scenario.replace("_", " ").title()} scenario</text>'
        )
    for index, design in enumerate(block_designs):
        y = legend_y + 22 * index
        pieces.append(
            f'<line x1="120" y1="{y}" x2="158" y2="{y}" stroke="#333" stroke-width="2.5" stroke-dasharray="{design_dashes[design]}"/>'
        )
        pieces.append(
            f'<text x="168" y="{y + 4}" font-size="12">B-cal={design[0]}, B-val={design[1]}</text>'
        )
    pieces.extend(["</g>", "</svg>"])
    path.write_text("\n".join(pieces) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = run_design(
        args.repetitions,
        args.seed,
        args.development_sizes,
        args.calibration_block_counts,
        args.validation_blocks,
        args.evaluation_sizes,
    )
    write_csv(rows, args.output_dir / "design-operating-characteristics.csv")
    write_json(rows, args.output_dir / "design-summary.json", args)
    write_svg(rows, args.output_dir / "figure-design-operating-characteristics.svg")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
