# Reference Policy Prototype

This directory contains a NumPy-only implementation of the paper's decision rule. It is intentionally small enough to inspect line by line.

## Evidence and transport boundary

**Current status:** the design and reference-prototype scaffold are complete, but no real athlete intervention data or phone-video validation data are included. Synthetic outputs are implementation and design diagnostics only. They are not athlete evidence, deployment clearance, or an SSAC-ready Results section.

**No held-out-sport guarantee:** the development guard has no formal guarantee for held-out handball or any other out-of-distribution population. Handball is an empirical prospective transport stress test of a frozen pipeline. It is not covered automatically by exchangeability-based calibration on basketball and soccer, even if the observed handball result is favourable.

The prototype performs five operations:

1. simulates paired, counterbalanced cue and no-cue calibration blocks;
2. estimates a two-outcome population prior from development athletes;
3. updates that prior with a new athlete's calibration data;
4. calibrates selection-aware performance and load bounds using development athletes only, applies a selector-specific exact-binomial deployment audit, then selects a cue or abstains;
5. creates independent validation outcomes after every decision is locked.

## Run tests

Use Python 3.10 or newer with NumPy installed:

```bash
cd prototype
python -m unittest discover -s tests -v
```

## Run design simulations

```bash
cd prototype
python simulate_design.py \
  --repetitions 20 \
  --development-sizes 100 160 \
  --calibration-block-counts 4 8 \
  --validation-blocks 6 \
  --evaluation-sizes 36 \
  --output-dir ../simulation
```

The command writes a CSV, JSON provenance record, and vector SVG. Every output is labeled `SYNTHETIC_DESIGN_ONLY`. Schema 1.1.0 includes the seed, full base configuration, explicit sport counts, held-out-sport ID, descriptive sport-level diagnostics, runtime versions, scenario definitions, and source-file SHA-256 hashes.

The base configuration assigns 50 basketball and 50 soccer development athletes, then evaluates 10 new athletes from each of basketball, soccer, and held-out handball. The stored default grid uses 12 evaluation athletes per sport because its evaluation size is 36. Within each development-size condition, athletes are assigned by a seeded sport-stratified random split to roughly 50% population fit, 25% conformal calibration, and 25% independent guard audit. The default scan varies development N and personal calibration blocks because those determine whether the guard can issue any recommendation. Sport-level outputs are descriptive diagnostics, not powered sport-specific effects. This is design exploration, not a sample-size recommendation. Final counts and allowed audit error bounds must be locked from pilot-informed joint simulations before enrollment.

These outputs cannot fill the SSAC abstract's Results section. They cannot establish athlete benefit, individual safety, injury reduction, or video-model validity.

## Sign convention

- Larger performance differences are better.
- Larger mechanical-load differences are worse.
- Abstention retains the no-cue condition and has a true effect of zero in simulation.

## Leakage boundary

Development and evaluation athlete IDs are disjoint. The development split is seeded, sport-stratified, hashed, and independent of lexical athlete-ID order. The population prior uses development calibration only. Evaluation athletes contribute only their randomized calibration blocks before decisions are locked. The validation random generator is instantiated after locking, and validation outcomes never return to model fitting.

## Statistical interpretation

- Cue-control order is exactly counterbalanced when the block count is even and differs by at most one when it is odd.
- Where the simulator reports a confidence interval for an athlete-level sample mean, it uses the registered Student-t critical value.
- Conditional safety and success rates are pooled from their numerators and denominators. A rate is undefined when the policy makes no recommendations.
- For the empirical-Bayes update, personal sampling covariance is multiplied by the squared ratio of the two-sided 95% Student-t critical value to 1.96. The subsequent precision update and tail diagnostics remain Gaussian. This is a heuristic small-sample Gaussian approximation, not a Student-t likelihood or a Student-t posterior.
- Development athletes are split before fitting into population-fit, conformal-calibration, and untouched audit groups. No athlete or outcome crosses those roles.
- Each calibration and audit athlete has exactly the registered B-cal personal-update blocks and B-val future-outcome blocks. The guard checking set is required to equal the prospective B-val count.
- Conformal residuals use the worst error across all four cues, so their bounds account for choosing a cue after looking across the candidate set. The untouched audit group then applies the complete selected-cue rule to unseen blocks.
- Personalized, population-ranked, and random comparators use the same athlete-specific eligible cue set; only their ranking or choice rule differs.
- The guard audits each of those three selectors separately for load false clearance and performance false benefit. Each error rate uses an exact one-sided 95% Clopper-Pearson upper confidence bound. The load bound is compared with a frozen maximum load-false-clearance rate, while the performance bound is compared with a separately frozen maximum performance-false-benefit rate. Every selector must also reach the registered minimum clearance count; otherwise every deployment decision abstains.
- The calibrated guard covers a future noisy validation-block mean only under the registered athlete-exchangeability assumptions. It is not a finite-sample interval for the latent causal effect, proof of individual safety, or a formal held-out-handball/OOD transport guarantee. Held-out handball is an empirical prospective transport stress test and must be reported as such.
- The quantities named `safe_probability` and `benefit_probability` are retained as plug-in Gaussian diagnostics. They do not control cue eligibility and cannot be described as calibrated probabilities without separate evidence.
- The load endpoint is a prespecified mechanical-load proxy. Average noninferiority on that proxy is not proof of individual safety and is not an injury-risk claim.

## Scenario scope

The simulation contains heterogeneous-response, homogeneous-response, threshold-boundary, exact-zero-performance, deployable policy-equivalence, and uniformly unsafe scenarios. In `deployable_null`, all cues have the same positive performance effect and remain safely below the load boundary. It uses the same explicitly low-noise measurement regime as the high-signal positive control so the guard can deploy while the true personalized-minus-population effect stays exactly zero; this probes false superiority under recommendation rather than obtaining a trivial null through universal abstention. The high-signal scenario separately verifies that the policy can recommend when the guard is informative. The design grid varies B-cal. In heterogeneous and high-signal scenarios, only the registered held-out-sport subset receives the transport shift; seen-sport evaluation athletes remain in the prospective mixture. Every parameter and sport count is illustrative rather than empirically anchored.

The current simulator does not yet represent video pose-estimation error, missing keypoints, heavy-tailed residuals, cue nonadherence, carryover, correlated effects across cues, or deployment drift. Those cases belong in a later sensitivity suite after pilot data identify realistic ranges.
