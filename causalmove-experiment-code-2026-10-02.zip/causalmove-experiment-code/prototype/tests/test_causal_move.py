"""Unit tests for the causal cue policy."""

from __future__ import annotations

from collections import Counter
import unittest
from dataclasses import replace

import numpy as np

from causal_move import (
    _exact_binomial_upper_bound,
    _finite_sample_upper_quantile,
    AthletePosterior,
    calibrate_policy_guard,
    Decision,
    decision_signature,
    EffectSummary,
    PolicyThresholds,
    PopulationPrior,
    SimulationConfig,
    TrialBatch,
    evaluate_policies,
    fit_population_prior,
    posterior_update,
    recommend_personalized,
    recommend_population,
    recommend_random_feasible,
    regularize_covariance,
    run_replication,
    simulate_paired_trials,
    simulate_truth,
    simulate_validation,
    student_t_critical,
    summarize_pairs,
    Truth,
    validate_config,
)


class CausalMoveTests(unittest.TestCase):
    def setUp(self) -> None:
        self.thresholds = PolicyThresholds(
            load_margin=0.05,
            minimum_performance_gain=0.0,
            safety_probability=0.95,
            benefit_probability=0.80,
        )

    def _posterior(self, means: dict[str, tuple[float, float]]) -> AthletePosterior:
        cues = tuple(means)
        return AthletePosterior(
            athlete_id="eval_001",
            cues=cues,
            means={cue: np.asarray(value, dtype=float) for cue, value in means.items()},
            covariances={cue: np.diag([0.01**2, 0.005**2]) for cue in cues},
            load_upper_critical=1.6448536269514722,
            performance_lower_critical=0.8416212335729143,
            guard_calibration_passed=True,
        )

    def test_unsafe_high_performance_cue_is_rejected(self) -> None:
        posterior = self._posterior({"fast_unsafe": (0.30, 0.12), "safe": (0.10, 0.01)})
        decision = recommend_personalized(posterior, self.thresholds)
        self.assertEqual(decision.cue, "safe")
        self.assertNotIn("fast_unsafe", decision.feasible_cues)

    def test_selection_uses_calibrated_bound_not_plugin_tail_score(self) -> None:
        posterior = AthletePosterior(
            athlete_id="eval_001",
            cues=("cue",),
            means={"cue": np.asarray([0.20, 0.04])},
            covariances={"cue": np.diag([0.01**2, 0.005**2])},
            load_upper_critical=3.0,
            performance_lower_critical=1.0,
            guard_calibration_passed=True,
        )
        decision = recommend_personalized(posterior, self.thresholds)
        self.assertGreater(decision.scores["cue"].safe_probability, 0.95)
        self.assertGreater(decision.scores["cue"].load_upper_bound, 0.05)
        self.assertIsNone(decision.cue)

    def test_failed_development_guard_forces_global_abstention(self) -> None:
        posterior = AthletePosterior(
            athlete_id="eval_001",
            cues=("cue",),
            means={"cue": np.asarray([0.20, 0.00])},
            covariances={"cue": np.diag([0.01**2, 0.005**2])},
            guard_calibration_passed=False,
        )
        self.assertIsNone(recommend_personalized(posterior, self.thresholds).cue)

    def test_all_unsafe_cues_produce_abstention(self) -> None:
        posterior = self._posterior({"a": (0.30, 0.12), "b": (0.20, 0.10)})
        decision = recommend_personalized(posterior, self.thresholds)
        self.assertIsNone(decision.cue)
        self.assertEqual(decision.feasible_cues, ())

    def test_random_policy_never_leaves_feasible_set(self) -> None:
        posterior = self._posterior({"a": (0.10, 0.01), "b": (0.20, 0.12)})
        prior = PopulationPrior(
            cues=("a", "b"),
            means={"a": np.asarray([0.10, 0.01]), "b": np.asarray([0.20, 0.01])},
            covariances={"a": np.eye(2), "b": np.eye(2)},
            development_athlete_ids=("dev_1", "dev_2", "dev_3"),
            performance_lower_critical=0.8416212335729143,
            guard_calibration_passed=True,
        )
        decision = recommend_random_feasible(
            prior,
            posterior,
            self.thresholds,
            np.random.default_rng(1),
        )
        self.assertEqual(decision.cue, "a")
        self.assertIn(decision.cue, decision.feasible_cues)

    def test_population_policy_ignores_personal_performance_ranking(self) -> None:
        posterior = self._posterior({"a": (0.01, 0.01), "b": (0.40, 0.01)})
        prior = PopulationPrior(
            cues=("a", "b"),
            means={"a": np.asarray([0.20, 0.01]), "b": np.asarray([0.10, 0.01])},
            covariances={"a": np.eye(2), "b": np.eye(2)},
            development_athlete_ids=("dev_1", "dev_2", "dev_3"),
            performance_lower_critical=0.8416212335729143,
            guard_calibration_passed=True,
        )
        decision = recommend_population(prior, posterior, self.thresholds)
        self.assertEqual(decision.cue, "a")

    def test_covariance_regularization_is_positive_definite(self) -> None:
        adjusted = regularize_covariance(
            np.asarray([[1.0, 2.0], [2.0, 1.0]]),
            floor=1e-5,
        )
        self.assertTrue(np.allclose(adjusted, adjusted.T))
        self.assertTrue(np.all(np.linalg.eigvalsh(adjusted) > 0.0))

    def test_precise_personal_data_shrink_less_than_noisy_data(self) -> None:
        prior = PopulationPrior(
            cues=("cue",),
            means={"cue": np.asarray([0.0, 0.0])},
            covariances={"cue": np.diag([0.10, 0.10])},
            development_athlete_ids=("dev_1", "dev_2", "dev_3"),
        )
        personal_mean = {("eval_1", "cue"): np.asarray([1.0, 0.02])}
        precise = EffectSummary(
            means=personal_mean,
            mean_covariances={("eval_1", "cue"): np.diag([0.001, 0.001])},
            blocks={("eval_1", "cue"): 8},
        )
        noisy = EffectSummary(
            means=personal_mean,
            mean_covariances={("eval_1", "cue"): np.diag([0.50, 0.50])},
            blocks={("eval_1", "cue"): 2},
        )
        precise_posterior = posterior_update(prior, precise, "eval_1", 1e-8)
        noisy_posterior = posterior_update(prior, noisy, "eval_1", 1e-8)
        self.assertGreater(
            precise_posterior.means["cue"][0],
            noisy_posterior.means["cue"][0],
        )

    def test_development_evaluation_overlap_is_rejected(self) -> None:
        prior = PopulationPrior(
            cues=("cue",),
            means={"cue": np.asarray([0.0, 0.0])},
            covariances={"cue": np.eye(2)},
            development_athlete_ids=("same", "dev_2", "dev_3"),
        )
        summary = EffectSummary(
            means={("same", "cue"): np.asarray([0.1, 0.0])},
            mean_covariances={("same", "cue"): np.eye(2)},
            blocks={("same", "cue"): 2},
        )
        with self.assertRaises(ValueError):
            posterior_update(prior, summary, "same", 1e-6)

    def test_fixed_seed_and_unequal_sport_aggregation_are_reproducible(self) -> None:
        config = replace(
            SimulationConfig(),
            development_athletes=80,
            evaluation_athletes=9,
            development_sport_counts=(("basketball", 40), ("soccer", 40)),
            evaluation_sport_counts=(
                ("basketball", 2),
                ("soccer", 2),
                ("handball", 5),
            ),
            calibration_blocks=4,
            validation_blocks=2,
            guard_checking_blocks=2,
        )
        first = run_replication(config, seed=44)
        second = run_replication(config, seed=44)
        self.assertEqual(set(first), set(second))
        for key in first:
            if isinstance(first[key], float) and np.isnan(first[key]):
                self.assertTrue(np.isnan(second[key]), msg=key)
            else:
                self.assertEqual(first[key], second[key], msg=key)
        diagnostic_suffixes = (
            "evaluation_athletes",
            "recommendation_coverage",
            "abstention_rate",
            "performance_difference_observed",
            "personalized_load_observed",
            "true_personalized_minus_population",
            "personalized_true_load",
        )
        sport_counts = {"basketball": 2, "soccer": 2, "handball": 5}
        for sport, count in sport_counts.items():
            for suffix in diagnostic_suffixes:
                self.assertIn(f"sport_{sport}_{suffix}", first)
            self.assertEqual(first[f"sport_{sport}_evaluation_athletes"], count)
        self.assertAlmostEqual(
            float(first["performance_difference_observed"]),
            sum(
                count
                * float(first[f"sport_{sport}_performance_difference_observed"])
                for sport, count in sport_counts.items()
            )
            / 9.0,
        )
        self.assertAlmostEqual(
            float(first["personalized_load_observed"]),
            sum(
                count * float(first[f"sport_{sport}_personalized_load_observed"])
                for sport, count in sport_counts.items()
            )
            / 9.0,
        )

    def test_high_signal_scenario_is_a_passing_positive_control(self) -> None:
        config = replace(
            SimulationConfig(),
            scenario="high_signal",
            development_athletes=100,
            evaluation_athletes=24,
            evaluation_sport_counts=(
                ("basketball", 8),
                ("soccer", 8),
                ("handball", 8),
            ),
            calibration_blocks=8,
            validation_blocks=8,
            guard_checking_blocks=8,
            performance_noise_sd=0.060,
            load_noise_sd=0.006,
        )
        result = run_replication(config, seed=44)
        self.assertTrue(result["guard_calibration_passed"])
        self.assertGreater(result["recommendation_coverage"], 0.0)
        self.assertGreaterEqual(result["guard_audit_minimum_policy_clearances"], 20)
        self.assertLessEqual(
            result["guard_audit_maximum_load_false_clearance_upper"],
            0.15,
        )
        self.assertLessEqual(
            result["guard_audit_maximum_performance_false_benefit_upper"],
            0.15,
        )

    def test_exact_audit_bound_rejects_small_sample_wilson_edge(self) -> None:
        self.assertGreater(_exact_binomial_upper_bound(1, 28), 0.15)
        zero_of_twenty = _exact_binomial_upper_bound(0, 20)
        self.assertLess(zero_of_twenty, 0.15)
        self.assertAlmostEqual(
            zero_of_twenty,
            1.0 - 0.05 ** (1.0 / 20),
            places=12,
        )
        self.assertAlmostEqual(
            _exact_binomial_upper_bound(1, 28),
            0.1585,
            places=4,
        )
        self.assertAlmostEqual(
            _exact_binomial_upper_bound(199, 200),
            0.95 ** (1.0 / 200),
            places=12,
        )
        self.assertEqual(_exact_binomial_upper_bound(200, 200), 1.0)
        bounds = [_exact_binomial_upper_bound(events, 50) for events in range(51)]
        self.assertTrue(all(left <= right for left, right in zip(bounds, bounds[1:])))

    def test_max_over_cues_conformal_rank_has_expected_exchangeable_coverage(self) -> None:
        rng = np.random.default_rng(211)
        repetitions = 5_000
        scores = rng.normal(size=(repetitions, 21, 4)).max(axis=2)
        covered = []
        for row in scores:
            critical = _finite_sample_upper_quantile(row[:20], 0.95)
            covered.append(float(row[20] <= critical))
        observed = float(np.mean(covered))
        self.assertGreater(observed, 0.94)
        self.assertLess(observed, 0.965)

    def test_guard_roles_hash_and_audit_outcome_separation(self) -> None:
        config = replace(
            SimulationConfig(),
            scenario="high_signal",
            development_athletes=100,
            calibration_blocks=8,
            validation_blocks=8,
            guard_checking_blocks=8,
            performance_noise_sd=0.030,
            load_noise_sd=0.003,
        )
        athlete_ids = tuple(f"dev_{index:03d}" for index in range(100))
        truth = simulate_truth(
            config,
            athlete_ids,
            (),
            np.random.default_rng(31),
        )
        trials = simulate_paired_trials(
            truth,
            athlete_ids,
            blocks=16,
            config=config,
            rng=np.random.default_rng(32),
            counterbalance_segments=(8, 8),
        )

        def calibrate(
            batch: TrialBatch,
            registered_ids=athlete_ids,
            load_limit: float = 0.99,
            performance_limit: float = 0.99,
        ):
            return calibrate_policy_guard(
                batch,
                registered_ids,
                config.cues,
                config.thresholds,
                config.covariance_floor,
                load_limit,
                performance_limit,
                1,
                8,
                8,
                33,
            )

        _, baseline = calibrate(trials)
        assignments = baseline.split_assignments
        self.assertEqual(len(assignments), len(athlete_ids))
        self.assertEqual({item[0] for item in assignments}, set(athlete_ids))
        self.assertEqual(
            {item[2] for item in assignments},
            {"population_fit", "conformal_calibration", "independent_audit"},
        )
        _, repeated = calibrate(trials)
        self.assertEqual(
            baseline.split_assignment_hash,
            repeated.split_assignment_hash,
        )
        _, reordered = calibrate(trials, tuple(reversed(athlete_ids)))
        self.assertEqual(baseline.split_assignments, reordered.split_assignments)
        self.assertEqual(
            baseline.split_assignment_hash,
            reordered.split_assignment_hash,
        )
        self.assertEqual(baseline.load_upper_critical, reordered.load_upper_critical)
        self.assertEqual(
            baseline.performance_lower_critical,
            reordered.performance_lower_critical,
        )
        self.assertEqual(
            baseline.audit_policy_clearances,
            reordered.audit_policy_clearances,
        )
        self.assertEqual(
            baseline.audit_policy_load_false_clearances,
            reordered.audit_policy_load_false_clearances,
        )
        self.assertEqual(
            baseline.audit_policy_load_false_clearance_uppers,
            reordered.audit_policy_load_false_clearance_uppers,
        )
        self.assertEqual(
            baseline.audit_policy_performance_false_benefits,
            reordered.audit_policy_performance_false_benefits,
        )
        self.assertEqual(
            baseline.audit_policy_performance_false_benefit_uppers,
            reordered.audit_policy_performance_false_benefit_uppers,
        )
        self.assertEqual(baseline.passed, reordered.passed)

        self.assertTrue(baseline.passed)
        _, load_tightened = calibrate(
            trials,
            load_limit=baseline.maximum_load_false_clearance_upper - 1e-12,
        )
        self.assertFalse(load_tightened.passed)
        _, performance_tightened = calibrate(
            trials,
            performance_limit=(
                baseline.maximum_performance_false_benefit_upper - 1e-12
            ),
        )
        self.assertFalse(performance_tightened.passed)

        roles = {athlete_id: role for athlete_id, _, role in assignments}
        changed_pairs = tuple(
            replace(
                pair,
                cue_outcome=(
                    pair.cue_outcome[0] + 10.0,
                    pair.cue_outcome[1] + 10.0,
                ),
            )
            if roles[pair.athlete_id] == "independent_audit" and pair.block >= 8
            else pair
            for pair in trials.pairs
        )
        _, mutated = calibrate(TrialBatch(phase="calibration", pairs=changed_pairs))
        self.assertEqual(baseline.load_upper_critical, mutated.load_upper_critical)
        self.assertEqual(
            baseline.performance_lower_critical,
            mutated.performance_lower_critical,
        )
        self.assertEqual(
            baseline.audit_policy_clearances,
            mutated.audit_policy_clearances,
        )
        self.assertGreater(
            mutated.maximum_load_false_clearance_upper,
            baseline.maximum_load_false_clearance_upper,
        )

    def test_uncalibrated_fitted_prior_fails_closed(self) -> None:
        development_ids = ("dev_1", "dev_2", "dev_3")
        development = EffectSummary(
            means={
                (athlete_id, "cue"): np.asarray([0.20, 0.00])
                for athlete_id in development_ids
            },
            mean_covariances={
                (athlete_id, "cue"): np.diag([0.01**2, 0.005**2])
                for athlete_id in development_ids
            },
            blocks={(athlete_id, "cue"): 4 for athlete_id in development_ids},
        )
        prior = fit_population_prior(
            development,
            development_ids,
            ("cue",),
            covariance_floor=1e-8,
        )
        personal = EffectSummary(
            means={("eval_1", "cue"): np.asarray([0.20, 0.00])},
            mean_covariances={
                ("eval_1", "cue"): np.diag([0.01**2, 0.005**2])
            },
            blocks={("eval_1", "cue"): 4},
        )
        posterior = posterior_update(prior, personal, "eval_1", 1e-8)
        self.assertFalse(posterior.guard_calibration_passed)
        self.assertIsNone(recommend_personalized(posterior, self.thresholds).cue)

    def test_abstention_has_zero_true_policy_value(self) -> None:
        athlete_ids = ("eval_1", "eval_2")
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "handball" for athlete_id in athlete_ids},
            effects={
                (athlete_id, "cue"): np.asarray([1.0, 0.0])
                for athlete_id in athlete_ids
            },
        )
        decisions = {
            policy: tuple(
                Decision(
                    athlete_id=athlete_id,
                    policy=policy,
                    cue=None,
                    feasible_cues=(),
                    scores={},
                )
                for athlete_id in athlete_ids
            )
            for policy in ("personalized", "population_best", "random_feasible")
        }
        config = replace(
            SimulationConfig(),
            cues=("cue",),
            evaluation_athletes=2,
            validation_blocks=30,
        )
        validation = simulate_validation(
            truth,
            decisions,
            blocks=30,
            config=config,
            rng=np.random.default_rng(7),
        )
        metrics = evaluate_policies(truth, decisions, validation, self.thresholds)
        self.assertTrue(
            all(outcome.mean_difference == (0.0, 0.0) for outcome in validation)
        )
        self.assertEqual(metrics["personalized_true_performance"], 0.0)
        self.assertEqual(metrics["recommendation_coverage"], 0.0)
        self.assertEqual(metrics["abstention_rate"], 1.0)
        self.assertTrue(
            np.isnan(metrics["true_load_violation_rate_when_recommended"])
        )

    def test_same_cue_uses_one_shared_validation_outcome(self) -> None:
        athlete_ids = ("eval_1", "eval_2")
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "handball" for athlete_id in athlete_ids},
            effects={
                (athlete_id, "cue"): np.asarray([0.2, 0.01])
                for athlete_id in athlete_ids
            },
        )
        decisions = {
            policy: tuple(
                Decision(
                    athlete_id=athlete_id,
                    policy=policy,
                    cue="cue" if policy != "random_feasible" else None,
                    feasible_cues=("cue",),
                    scores={},
                )
                for athlete_id in athlete_ids
            )
            for policy in ("personalized", "population_best", "random_feasible")
        }
        config = replace(SimulationConfig(), cues=("cue",), evaluation_athletes=2)
        validation = simulate_validation(
            truth,
            decisions,
            blocks=4,
            config=config,
            rng=np.random.default_rng(13),
        )
        lookup = {
            (outcome.athlete_id, outcome.policy): outcome.mean_difference
            for outcome in validation
        }
        for athlete_id in athlete_ids:
            self.assertEqual(
                lookup[(athlete_id, "personalized")],
                lookup[(athlete_id, "population_best")],
            )

    def test_calibration_order_is_exactly_counterbalanced_for_even_blocks(self) -> None:
        athlete_id = "eval_1"
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "handball"},
            effects={(athlete_id, "cue"): np.asarray([0.1, 0.01])},
        )
        config = replace(SimulationConfig(), cues=("cue",))
        trials = simulate_paired_trials(
            truth,
            (athlete_id,),
            blocks=4,
            config=config,
            rng=np.random.default_rng(99),
        )
        cue_first_count = sum(pair.cue_period == 1 for pair in trials.pairs)
        self.assertEqual(cue_first_count, 2)

    def test_guard_fit_and_future_segments_are_separately_counterbalanced(self) -> None:
        athlete_id = "dev_1"
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "basketball"},
            effects={(athlete_id, "cue"): np.asarray([0.1, 0.01])},
        )
        trials = simulate_paired_trials(
            truth,
            (athlete_id,),
            blocks=10,
            config=replace(SimulationConfig(), cues=("cue",)),
            rng=np.random.default_rng(8),
            counterbalance_segments=(4, 6),
        )
        fit_first = sum(pair.cue_period == 1 for pair in trials.pairs if pair.block < 4)
        check_first = sum(pair.cue_period == 1 for pair in trials.pairs if pair.block >= 4)
        self.assertEqual(fit_first, 2)
        self.assertEqual(check_first, 3)

    def test_duplicate_and_incomplete_calibration_cells_are_rejected(self) -> None:
        athlete_id = "dev_1"
        truth = Truth(
            cues=("a", "b"),
            athlete_sports={athlete_id: "basketball"},
            effects={
                (athlete_id, "a"): np.asarray([0.1, 0.01]),
                (athlete_id, "b"): np.asarray([0.1, 0.01]),
            },
        )
        trials = simulate_paired_trials(
            truth,
            (athlete_id,),
            blocks=4,
            config=replace(SimulationConfig(), cues=("a", "b")),
            rng=np.random.default_rng(2),
        )
        duplicate = TrialBatch(
            phase="calibration",
            pairs=trials.pairs + (trials.pairs[0],),
        )
        with self.assertRaisesRegex(ValueError, "Duplicate calibration cell"):
            summarize_pairs(duplicate, 1e-6)
        incomplete = TrialBatch(phase="calibration", pairs=trials.pairs[:-1])
        with self.assertRaisesRegex(ValueError, "Incomplete cue-by-block"):
            summarize_pairs(incomplete, 1e-6)

    def test_duplicate_development_ids_are_rejected(self) -> None:
        summary = EffectSummary(
            means={
                (athlete_id, "cue"): np.asarray([0.1, 0.01])
                for athlete_id in ("a", "b", "c")
            },
            mean_covariances={
                (athlete_id, "cue"): np.eye(2)
                for athlete_id in ("a", "b", "c")
            },
            blocks={(athlete_id, "cue"): 2 for athlete_id in ("a", "b", "c")},
        )
        with self.assertRaisesRegex(ValueError, "must be unique"):
            fit_population_prior(summary, ("a", "b", "b"), ("cue",), 1e-6)

    def test_null_scenario_is_exact_p_minus_g_performance_null(self) -> None:
        config = replace(SimulationConfig(), scenario="null")
        truth = simulate_truth(
            config,
            ("dev_1", "dev_2"),
            ("eval_1",),
            np.random.default_rng(4),
        )
        self.assertTrue(
            all(float(effect[0]) == 0.0 for effect in truth.effects.values())
        )

    def test_deployable_null_has_equal_positive_performance_for_every_cue(self) -> None:
        config = replace(SimulationConfig(), scenario="deployable_null")
        truth = simulate_truth(
            config,
            ("dev_1", "dev_2"),
            ("eval_1",),
            np.random.default_rng(5),
        )
        self.assertTrue(
            all(float(effect[0]) == 0.10 for effect in truth.effects.values())
        )
        eval_performance = {
            float(truth.effects[("eval_1", cue)][0]) for cue in config.cues
        }
        self.assertEqual(eval_performance, {0.10})

    def test_default_truth_uses_the_registered_cross_sport_allocations(self) -> None:
        config = SimulationConfig()
        development_ids = tuple(
            f"dev_{index:03d}" for index in range(config.development_athletes)
        )
        evaluation_ids = tuple(
            f"eval_{index:03d}" for index in range(config.evaluation_athletes)
        )
        truth = simulate_truth(
            config,
            development_ids,
            evaluation_ids,
            np.random.default_rng(17),
        )

        self.assertEqual(
            Counter(truth.athlete_sports[athlete_id] for athlete_id in development_ids),
            Counter({"basketball": 50, "soccer": 50}),
        )
        self.assertEqual(
            Counter(truth.athlete_sports[athlete_id] for athlete_id in evaluation_ids),
            Counter({"basketball": 10, "soccer": 10, "handball": 10}),
        )

    def test_heldout_shift_changes_only_the_registered_heldout_sport(self) -> None:
        unshifted = replace(
            SimulationConfig(),
            development_athletes=80,
            evaluation_athletes=9,
            development_sport_counts=(("basketball", 40), ("soccer", 40)),
            evaluation_sport_counts=(
                ("basketball", 2),
                ("soccer", 2),
                ("volleyball", 5),
            ),
            heldout_sport="volleyball",
            heldout_sport_shift=0.0,
        )
        shifted = replace(unshifted, heldout_sport_shift=0.020)
        validate_config(unshifted)
        validate_config(shifted)
        development_ids = tuple(f"dev_{index:03d}" for index in range(80))
        evaluation_ids = tuple(f"eval_{index:03d}" for index in range(9))
        base_truth = simulate_truth(
            unshifted,
            development_ids,
            evaluation_ids,
            np.random.default_rng(81),
        )
        shifted_truth = simulate_truth(
            shifted,
            development_ids,
            evaluation_ids,
            np.random.default_rng(81),
        )
        shift_pattern = (0.020, -0.020, 0.010, -0.010)
        for athlete_id in development_ids + evaluation_ids:
            for cue, expected_heldout_shift in zip(unshifted.cues, shift_pattern):
                observed = (
                    shifted_truth.effects[(athlete_id, cue)]
                    - base_truth.effects[(athlete_id, cue)]
                )
                expected = (
                    expected_heldout_shift
                    if shifted_truth.athlete_sports[athlete_id] == "volleyball"
                    else 0.0
                )
                self.assertAlmostEqual(float(observed[0]), expected)
                self.assertAlmostEqual(float(observed[1]), 0.0)

    def test_registered_sport_allocations_are_validated(self) -> None:
        invalid_configs = (
            (
                "development total",
                replace(
                    SimulationConfig(),
                    development_sport_counts=(("basketball", 49), ("soccer", 50)),
                ),
                "development_athletes",
            ),
            (
                "duplicate sport",
                replace(
                    SimulationConfig(),
                    development_sport_counts=(
                        ("basketball", 50),
                        ("basketball", 50),
                    ),
                ),
                "unique",
            ),
            (
                "zero count",
                replace(
                    SimulationConfig(),
                    evaluation_sport_counts=(
                        ("basketball", 10),
                        ("soccer", 20),
                        ("handball", 0),
                    ),
                ),
                "positive",
            ),
            (
                "noncanonical sport ID",
                replace(
                    SimulationConfig(),
                    development_sport_counts=(("Basket Ball", 50), ("soccer", 50)),
                ),
                "lowercase",
            ),
            (
                "held-out leakage",
                replace(
                    SimulationConfig(),
                    development_sport_counts=(
                        ("basketball", 50),
                        ("handball", 50),
                    ),
                ),
                "absent from development",
            ),
            (
                "held-out missing",
                replace(
                    SimulationConfig(),
                    evaluation_sport_counts=(
                        ("basketball", 15),
                        ("soccer", 15),
                    ),
                ),
                "present in evaluation",
            ),
            (
                "development sport missing",
                replace(
                    SimulationConfig(),
                    evaluation_sport_counts=(
                        ("basketball", 10),
                        ("handball", 20),
                    ),
                ),
                "development sports",
            ),
            (
                "unregistered evaluation sport",
                replace(
                    SimulationConfig(),
                    evaluation_sport_counts=(
                        ("basketball", 8),
                        ("soccer", 8),
                        ("handball", 8),
                        ("tennis", 6),
                    ),
                ),
                "only development sports",
            ),
        )
        for label, config, message in invalid_configs:
            with self.subTest(label=label):
                with self.assertRaisesRegex(ValueError, message):
                    validate_config(config)

    def test_all_policies_use_the_same_personal_eligibility_set(self) -> None:
        posterior = self._posterior({"a": (0.10, 0.01), "b": (0.20, 0.01)})
        prior = PopulationPrior(
            cues=("a", "b"),
            means={"a": np.asarray([-0.10, 0.01]), "b": np.asarray([-0.20, 0.01])},
            covariances={"a": np.eye(2), "b": np.eye(2)},
            development_athlete_ids=("dev_1", "dev_2", "dev_3"),
            guard_calibration_passed=True,
        )
        personalized = recommend_personalized(posterior, self.thresholds)
        population = recommend_population(prior, posterior, self.thresholds)
        random = recommend_random_feasible(
            prior,
            posterior,
            self.thresholds,
            np.random.default_rng(3),
        )
        self.assertEqual(personalized.feasible_cues, population.feasible_cues)
        self.assertEqual(personalized.feasible_cues, random.feasible_cues)

    def test_duplicate_validation_outcome_is_rejected(self) -> None:
        athlete_ids = ("eval_1", "eval_2")
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "handball" for athlete_id in athlete_ids},
            effects={
                (athlete_id, "cue"): np.asarray([0.1, 0.01])
                for athlete_id in athlete_ids
            },
        )
        decisions = {
            policy: tuple(
                Decision(
                    athlete_id=athlete_id,
                    policy=policy,
                    cue=None,
                    feasible_cues=(),
                    scores={},
                )
                for athlete_id in athlete_ids
            )
            for policy in ("personalized", "population_best", "random_feasible")
        }
        validation = list(
            simulate_validation(
                truth,
                decisions,
                blocks=2,
                config=replace(SimulationConfig(), cues=("cue",)),
                rng=np.random.default_rng(3),
            )
        )
        validation.append(validation[0])
        with self.assertRaisesRegex(ValueError, "Duplicate validation outcome"):
            evaluate_policies(truth, decisions, validation, self.thresholds)

    def test_invalid_configuration_is_rejected_before_simulation(self) -> None:
        non_string_cue = replace(
            SimulationConfig(),
            cues=("a", "b", "c", 4),
        )
        with self.assertRaisesRegex(ValueError, "strings"):
            validate_config(non_string_cue)
        duplicate_cues = replace(
            SimulationConfig(),
            cues=("a", "a", "b", "c"),
        )
        with self.assertRaisesRegex(ValueError, "unique"):
            validate_config(duplicate_cues)
        invalid_correlation = replace(
            SimulationConfig(),
            outcome_noise_correlation=1.0,
        )
        with self.assertRaisesRegex(ValueError, "correlation"):
            validate_config(invalid_correlation)
        nonnumeric_shift = replace(
            SimulationConfig(),
            heldout_sport_shift="not-a-number",
        )
        with self.assertRaisesRegex(ValueError, "numeric"):
            validate_config(nonnumeric_shift)
        mismatched_future_blocks = replace(
            SimulationConfig(),
            validation_blocks=8,
            guard_checking_blocks=6,
        )
        with self.assertRaisesRegex(ValueError, "prospective validation"):
            validate_config(mismatched_future_blocks)
        unattainable_level = replace(
            SimulationConfig(),
            thresholds=replace(
                SimulationConfig().thresholds,
                safety_probability=0.99,
            ),
        )
        with self.assertRaisesRegex(ValueError, "unattainable"):
            validate_config(unattainable_level)

    def test_validation_generation_cannot_change_locked_decisions(self) -> None:
        athlete_ids = ("eval_1", "eval_2")
        truth = Truth(
            cues=("cue",),
            athlete_sports={athlete_id: "handball" for athlete_id in athlete_ids},
            effects={
                (athlete_id, "cue"): np.asarray([0.2, 0.01])
                for athlete_id in athlete_ids
            },
        )
        decisions = {
            policy: tuple(
                Decision(
                    athlete_id=athlete_id,
                    policy=policy,
                    cue="cue",
                    feasible_cues=("cue",),
                    scores={},
                )
                for athlete_id in athlete_ids
            )
            for policy in ("personalized", "population_best", "random_feasible")
        }
        before = decision_signature(decisions)
        config = replace(SimulationConfig(), cues=("cue",))
        first = simulate_validation(
            truth,
            decisions,
            blocks=4,
            config=config,
            rng=np.random.default_rng(101),
        )
        second = simulate_validation(
            truth,
            decisions,
            blocks=4,
            config=config,
            rng=np.random.default_rng(202),
        )
        self.assertNotEqual(first, second)
        self.assertEqual(before, decision_signature(decisions))

    def test_student_t_critical_values_cover_small_samples(self) -> None:
        self.assertAlmostEqual(student_t_critical(3), 3.182, places=3)
        self.assertAlmostEqual(
            student_t_critical(3, one_sided=True),
            2.353,
            places=3,
        )


if __name__ == "__main__":
    unittest.main()
