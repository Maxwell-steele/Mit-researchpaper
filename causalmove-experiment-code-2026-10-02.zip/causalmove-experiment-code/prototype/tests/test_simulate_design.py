"""Tests for design-level aggregation and provenance behavior."""

from __future__ import annotations

import json
import unittest
from argparse import Namespace
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from causal_move import SimulationConfig, run_replication
from simulate_design import (
    SCENARIO_DESCRIPTIONS,
    SCENARIO_OVERRIDES,
    _wilson_interval,
    run_design,
    summarize_runs,
    write_json,
    write_svg,
)


class DesignSimulationTests(unittest.TestCase):
    def _empty_run(self) -> dict[str, float | bool | int | str]:
        row: dict[str, float | bool | int | str] = {
            "primary_gate": False,
            "performance_superiority_gate": False,
            "load_noninferiority_gate": True,
            "performance_difference_observed": 0.0,
            "personalized_load_observed": 0.0,
            "personalized_true_load": 0.0,
            "true_personalized_minus_population": 0.0,
            "recommendation_coverage": 0.0,
            "abstention_rate": 1.0,
            "mean_true_constrained_regret_to_oracle": 0.0,
            "load_model_score_brier": 0.1,
            "benefit_model_score_brier": 0.2,
            "posterior_marginal_95_coverage": 0.95,
            "guard_calibration_passed": True,
            "guard_load_upper_critical": 2.0,
            "guard_performance_lower_critical": 1.0,
            "guard_audit_minimum_policy_clearances": 20,
            "guard_audit_maximum_load_false_clearance_upper": 0.05,
            "guard_audit_maximum_performance_false_benefit_upper": 0.05,
            "recommended_count": 0,
            "true_load_violation_count": 0,
            "joint_success_count": 0,
            "oracle_match_count": 0,
            "safety_gate_clearance_count": 0,
            "safety_gate_false_clearance_count": 0,
            "seed": 1,
            "guard_split_seed": 2,
            "guard_split_assignment_hash": "a" * 64,
        }
        for policy in ("personalized", "population_best", "random_feasible"):
            row[f"guard_audit_{policy}_clearances"] = 20
            row[f"guard_audit_{policy}_load_false_clearances"] = 0
            row[f"guard_audit_{policy}_load_false_clearance_upper"] = 0.05
            row[f"guard_audit_{policy}_performance_false_benefits"] = 0
            row[f"guard_audit_{policy}_performance_false_benefit_upper"] = 0.05
            row[f"{policy}_recommended_count"] = 0
            row[f"{policy}_true_load_violation_count"] = 0
            row[f"{policy}_true_false_benefit_count"] = 0
        return row

    def test_conditional_rates_pool_counts_and_remain_undefined_at_zero(self) -> None:
        no_recommendations = [self._empty_run(), self._empty_run()]
        empty_summary = summarize_runs(
            no_recommendations,
            2,
            "unsafe",
            80,
            4,
            6,
            10,
        )
        self.assertIsNone(
            empty_summary["true_load_violation_rate_when_recommended_pooled"]
        )
        self.assertIsNone(
            empty_summary[
                "population_best_true_false_benefit_rate_when_recommended_pooled"
            ]
        )
        self.assertEqual(len(empty_summary["guard_split_audit_manifest_sha256"]), 64)

        one_recommendation = self._empty_run()
        one_recommendation.update(
            {
                "recommendation_coverage": 0.1,
                "abstention_rate": 0.9,
                "recommended_count": 1,
                "true_load_violation_count": 1,
            }
        )
        pooled = summarize_runs(
            [self._empty_run(), one_recommendation],
            2,
            "unsafe",
            80,
            4,
            6,
            10,
        )
        self.assertEqual(
            pooled["true_load_violation_rate_when_recommended_numerator"],
            1,
        )
        self.assertEqual(
            pooled["true_load_violation_rate_when_recommended_denominator"],
            1,
        )
        self.assertEqual(
            pooled["true_load_violation_rate_when_recommended_pooled"],
            1.0,
        )

    def test_design_inputs_reject_duplicate_evaluation_sizes(self) -> None:
        with self.assertRaisesRegex(ValueError, "unique"):
            run_design(
                repetitions=2,
                master_seed=7,
                development_sizes=(80,),
                calibration_block_counts=(4,),
                validation_blocks=6,
                evaluation_sizes=(6, 6),
            )

    def test_design_scan_varies_development_n_and_personal_blocks(self) -> None:
        rows = run_design(
            repetitions=2,
            master_seed=9,
            development_sizes=(80, 84),
            calibration_block_counts=(4, 6),
            validation_blocks=2,
            evaluation_sizes=(6,),
        )
        self.assertEqual(
            {(row["development_athletes"], row["calibration_blocks"]) for row in rows},
            {(80, 4), (80, 6), (84, 4), (84, 6)},
        )
        for row in rows:
            development_counts = dict(
                json.loads(str(row["development_sport_counts_json"]))
            )
            evaluation_counts = dict(
                json.loads(str(row["evaluation_sport_counts_json"]))
            )
            self.assertEqual(sum(development_counts.values()), row["development_athletes"])
            self.assertEqual(set(development_counts), {"basketball", "soccer"})
            self.assertEqual(
                evaluation_counts,
                {"basketball": 2, "soccer": 2, "handball": 2},
            )
            self.assertEqual(row["heldout_sport"], "handball")
            for sport in ("basketball", "soccer", "handball"):
                self.assertEqual(
                    row[f"sport_{sport}_evaluation_athletes_mean"],
                    2.0,
                )
                self.assertIn(
                    f"sport_{sport}_recommendation_coverage_mean",
                    row,
                )
                self.assertIn(
                    f"sport_{sport}_performance_difference_observed_mean",
                    row,
                )
            for metric in (
                "performance_difference_observed",
                "personalized_load_observed",
                "personalized_true_load",
            ):
                pooled_key = f"{metric}_mean"
                self.assertIn(pooled_key, row)
                subgroup_mean = sum(
                    float(row[f"sport_{sport}_{metric}_mean"])
                    for sport in ("basketball", "soccer", "handball")
                ) / 3.0
                self.assertAlmostEqual(float(row[pooled_key]), subgroup_mean)

    def test_wilson_interval_does_not_collapse_at_boundary(self) -> None:
        lower, upper = _wilson_interval(0, 20)
        self.assertEqual(lower, 0.0)
        self.assertGreater(upper, 0.0)

    def test_json_schema_versions_the_cross_sport_contract(self) -> None:
        args = Namespace(
            seed=9,
            repetitions=2,
            development_sizes=(100,),
            calibration_block_counts=(4,),
            validation_blocks=6,
            evaluation_sizes=(30,),
        )
        with TemporaryDirectory() as directory:
            path = Path(directory) / "summary.json"
            write_json([{"evidence_scope": "SYNTHETIC_DESIGN_ONLY"}], path, args)
            payload = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(payload["schema_version"], "1.1.0")
        base_config = payload["run_configuration"]["base_simulation_config"]
        self.assertIn("development_sport_counts", base_config)
        self.assertIn("evaluation_sport_counts", base_config)
        self.assertEqual(base_config["heldout_sport"], "handball")

    def test_deployable_null_uses_an_informative_measurement_regime(self) -> None:
        self.assertLess(
            SCENARIO_OVERRIDES["deployable_null"]["performance_noise_sd"],
            0.10,
        )
        self.assertLess(
            SCENARIO_OVERRIDES["deployable_null"]["load_noise_sd"],
            0.01,
        )
        config = replace(
            SimulationConfig(),
            scenario="deployable_null",
            **SCENARIO_OVERRIDES["deployable_null"],
        )
        result = run_replication(config, seed=44)
        self.assertTrue(result["guard_calibration_passed"])
        self.assertGreater(result["recommendation_coverage"], 0.0)
        self.assertEqual(result["true_personalized_minus_population"], 0.0)

    def test_svg_labels_each_scenario_once_in_legend(self) -> None:
        rows = [
            {
                "scenario": scenario,
                "development_athletes": 80,
                "calibration_blocks": 4,
                "validation_blocks": 6,
                "evaluation_athletes": 2,
                "repetitions": 20,
                "guard_calibration_passed_mean": 0.0,
            }
            for scenario in SCENARIO_DESCRIPTIONS
        ]
        with TemporaryDirectory() as directory:
            path = Path(directory) / "figure.svg"
            write_svg(rows, path)
            svg = path.read_text(encoding="utf-8")
        for scenario in SCENARIO_DESCRIPTIONS:
            label = scenario.replace("_", " ").title()
            self.assertEqual(svg.count(f">{label} scenario<"), 1)


if __name__ == "__main__":
    unittest.main()
