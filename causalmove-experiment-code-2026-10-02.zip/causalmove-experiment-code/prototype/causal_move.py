"""Auditable reference policy for athlete-specific movement cues.

This module uses paired randomized calibration trials and a two-outcome
empirical-Bayes model. Performance effects are coded so that larger is better.
Mechanical-load effects are coded so that larger is worse.

The implementation is deliberately small. It validates the proposed decision
logic in simulation. It is not evidence that any cue helps a real athlete.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, replace
from math import ceil, erf, exp, fsum, isfinite, lgamma, log, log1p, sqrt
from typing import Iterable, Mapping, Sequence

import numpy as np
from numpy.typing import NDArray


Vector = NDArray[np.float64]
Matrix = NDArray[np.float64]


@dataclass(frozen=True)
class PolicyThresholds:
    """Locked policy thresholds in the units of the analyzed outcomes."""

    load_margin: float
    minimum_performance_gain: float = 0.0
    safety_probability: float = 0.95
    benefit_probability: float = 0.80


@dataclass(frozen=True)
class SimulationConfig:
    """Parameters for a design simulation, not deployment defaults."""

    cues: tuple[str, ...] = (
        "FPA_ALIGN_EXIT_V1",
        "PLANT_OFFSET_REDUCE_V1",
        "BRAKE_EARLIER_V1",
        "TRUNK_TOWARD_EXIT_V1",
    )
    development_athletes: int = 100
    evaluation_athletes: int = 30
    development_sport_counts: tuple[tuple[str, int], ...] = (
        ("basketball", 50),
        ("soccer", 50),
    )
    evaluation_sport_counts: tuple[tuple[str, int], ...] = (
        ("basketball", 10),
        ("soccer", 10),
        ("handball", 10),
    )
    heldout_sport: str = "handball"
    calibration_blocks: int = 4
    validation_blocks: int = 6
    performance_noise_sd: float = 0.18
    load_noise_sd: float = 0.020
    outcome_noise_correlation: float = 0.20
    performance_period_effect: float = -0.010
    load_period_effect: float = 0.002
    covariance_floor: float = 1e-6
    heldout_sport_shift: float = 0.020
    guard_checking_blocks: int = 6
    maximum_development_load_false_clearance_rate: float = 0.15
    maximum_development_performance_false_benefit_rate: float = 0.15
    minimum_development_safety_clearances: int = 20
    scenario: str = "heterogeneous"
    thresholds: PolicyThresholds = PolicyThresholds(load_margin=0.050)


@dataclass(frozen=True)
class TrialPair:
    """One randomized cue-control pair within an athlete and block."""

    athlete_id: str
    sport: str
    cue: str
    block: int
    sequence_index: int
    cue_period: int
    control_period: int
    cue_outcome: tuple[float, float]
    control_outcome: tuple[float, float]

    @property
    def difference(self) -> Vector:
        return np.asarray(self.cue_outcome) - np.asarray(self.control_outcome)


@dataclass(frozen=True)
class TrialBatch:
    phase: str
    pairs: tuple[TrialPair, ...]


@dataclass(frozen=True)
class EffectSummary:
    means: Mapping[tuple[str, str], Vector]
    mean_covariances: Mapping[tuple[str, str], Matrix]
    blocks: Mapping[tuple[str, str], int]


@dataclass(frozen=True)
class PopulationPrior:
    cues: tuple[str, ...]
    means: Mapping[str, Vector]
    covariances: Mapping[str, Matrix]
    development_athlete_ids: tuple[str, ...]
    mean_uncertainty_covariances: Mapping[str, Matrix] = field(default_factory=dict)
    future_mean_covariances: Mapping[str, Matrix] = field(default_factory=dict)
    athlete_counts: Mapping[str, int] = field(default_factory=dict)
    load_upper_critical: float = float("inf")
    performance_lower_critical: float = float("inf")
    guard_calibration_passed: bool = False
    guard_minimum_policy_clearances: int = 0
    guard_maximum_load_false_clearance_upper: float = 1.0
    guard_maximum_performance_false_benefit_upper: float = 1.0


@dataclass(frozen=True)
class AthletePosterior:
    athlete_id: str
    cues: tuple[str, ...]
    means: Mapping[str, Vector]
    covariances: Mapping[str, Matrix]
    future_mean_covariances: Mapping[str, Matrix] = field(default_factory=dict)
    load_upper_critical: float = float("inf")
    performance_lower_critical: float = float("inf")
    guard_calibration_passed: bool = False


@dataclass(frozen=True)
class CueScore:
    """Plug-in Gaussian model scores; calibration must be checked empirically."""

    cue: str
    expected_performance: float
    expected_load: float
    performance_sd: float
    load_sd: float
    decision_performance_sd: float
    decision_load_sd: float
    performance_lower_bound: float
    load_upper_bound: float
    safe_probability: float
    benefit_probability: float


@dataclass(frozen=True)
class GuardCalibration:
    """Development-only critical values and selector-specific audit results."""

    load_upper_critical: float
    performance_lower_critical: float
    audit_policy_clearances: Mapping[str, int]
    audit_policy_load_false_clearances: Mapping[str, int]
    audit_policy_load_false_clearance_uppers: Mapping[str, float]
    audit_policy_performance_false_benefits: Mapping[str, int]
    audit_policy_performance_false_benefit_uppers: Mapping[str, float]
    minimum_policy_clearances: int
    maximum_load_false_clearance_upper: float
    maximum_performance_false_benefit_upper: float
    population_fit_athletes: int
    conformal_calibration_athletes: int
    independent_audit_athletes: int
    split_seed: int
    split_assignment_hash: str
    split_assignments: tuple[tuple[str, str, str], ...]
    passed: bool


@dataclass(frozen=True)
class Decision:
    athlete_id: str
    policy: str
    cue: str | None
    feasible_cues: tuple[str, ...]
    scores: Mapping[str, CueScore]
    locked: bool = True


@dataclass(frozen=True)
class Truth:
    cues: tuple[str, ...]
    athlete_sports: Mapping[str, str]
    effects: Mapping[tuple[str, str], Vector]


@dataclass(frozen=True)
class ValidationOutcome:
    athlete_id: str
    policy: str
    cue: str | None
    mean_difference: tuple[float, float]


def normal_cdf(value: float) -> float:
    """Standard normal cumulative distribution function."""

    return 0.5 * (1.0 + erf(value / sqrt(2.0)))


_T_CRITICAL_975 = (
    12.706,
    4.303,
    3.182,
    2.776,
    2.571,
    2.447,
    2.365,
    2.306,
    2.262,
    2.228,
    2.201,
    2.179,
    2.160,
    2.145,
    2.131,
    2.120,
    2.110,
    2.101,
    2.093,
    2.086,
    2.080,
    2.074,
    2.069,
    2.064,
    2.060,
    2.056,
    2.052,
    2.048,
    2.045,
    2.042,
)

_T_CRITICAL_950 = (
    6.314,
    2.920,
    2.353,
    2.132,
    2.015,
    1.943,
    1.895,
    1.860,
    1.833,
    1.812,
    1.796,
    1.782,
    1.771,
    1.761,
    1.753,
    1.746,
    1.740,
    1.734,
    1.729,
    1.725,
    1.721,
    1.717,
    1.714,
    1.711,
    1.708,
    1.706,
    1.703,
    1.701,
    1.699,
    1.697,
)


def student_t_critical(degrees_of_freedom: int, one_sided: bool = False) -> float:
    """Return the 95% one-sided or 95% two-sided Student-t critical value."""

    if degrees_of_freedom < 1:
        raise ValueError("Degrees of freedom must be positive")
    table = _T_CRITICAL_950 if one_sided else _T_CRITICAL_975
    if degrees_of_freedom <= len(table):
        return table[degrees_of_freedom - 1]

    z_value = 1.6448536269514722 if one_sided else 1.959963984540054
    df = float(degrees_of_freedom)
    # Cornish-Fisher expansion; accurate enough for df > 30, where it is used.
    first = (z_value**3 + z_value) / (4.0 * df)
    second = (5.0 * z_value**5 + 16.0 * z_value**3 + 3.0 * z_value) / (
        96.0 * df**2
    )
    third = (
        3.0 * z_value**7
        + 19.0 * z_value**5
        + 17.0 * z_value**3
        - 15.0 * z_value
    ) / (384.0 * df**3)
    return z_value + first + second + third


def validate_config(config: SimulationConfig) -> None:
    """Reject invalid design parameters before random numbers are generated."""

    if not isinstance(config.cues, tuple):
        raise ValueError("Cue IDs must be supplied as a tuple")
    if len(config.cues) != 4:
        raise ValueError("The reference simulation requires exactly four cues")
    if any(not isinstance(cue, str) for cue in config.cues):
        raise ValueError("Cue IDs must be strings")
    if any(not cue.strip() for cue in config.cues) or len(set(config.cues)) != len(
        config.cues
    ):
        raise ValueError("Cue IDs must be nonempty and unique")
    if not isinstance(config.thresholds, PolicyThresholds):
        raise ValueError("Thresholds must use PolicyThresholds")
    integer_values = (
        config.development_athletes,
        config.evaluation_athletes,
        config.calibration_blocks,
        config.validation_blocks,
        config.guard_checking_blocks,
        config.minimum_development_safety_clearances,
    )
    if any(
        isinstance(value, (bool, np.bool_))
        or not isinstance(value, (int, np.integer))
        for value in integer_values
    ):
        raise ValueError("Athlete, block, and clearance counts must be integers")
    numeric_values = (
        config.performance_noise_sd,
        config.load_noise_sd,
        config.outcome_noise_correlation,
        config.performance_period_effect,
        config.load_period_effect,
        config.covariance_floor,
        config.heldout_sport_shift,
        config.maximum_development_load_false_clearance_rate,
        config.maximum_development_performance_false_benefit_rate,
        config.thresholds.load_margin,
        config.thresholds.minimum_performance_gain,
        config.thresholds.safety_probability,
        config.thresholds.benefit_probability,
    )
    if any(
        isinstance(value, (bool, np.bool_))
        or not isinstance(value, (int, float, np.integer, np.floating))
        for value in numeric_values
    ):
        raise ValueError("Continuous configuration values must be numeric")
    if config.development_athletes < 80 or config.evaluation_athletes < 2:
        raise ValueError("Three-way guard calibration needs at least 80 development athletes")

    def validate_sport_counts(
        label: str,
        sport_counts: Sequence[tuple[str, int]],
        expected_total: int,
        minimum_per_sport: int,
    ) -> dict[str, int]:
        if not sport_counts:
            raise ValueError(f"{label} sport counts cannot be empty")
        sports = [sport for sport, _ in sport_counts]
        if any(not isinstance(sport, str) or not sport.strip() for sport in sports):
            raise ValueError(f"{label} sport IDs must be nonempty strings")
        if any(
            not sport.isascii()
            or sport != sport.lower()
            or not sport[0].isalpha()
            or any(not (character.isalnum() or character == "_") for character in sport)
            for sport in sports
        ):
            raise ValueError(
                f"{label} sport IDs must use lowercase ASCII letters, digits, "
                "and underscores"
            )
        if len(set(sports)) != len(sports):
            raise ValueError(f"{label} sport IDs must be unique")
        counts = [count for _, count in sport_counts]
        if any(type(count) is not int or count <= 0 for count in counts):
            raise ValueError(f"{label} sport counts must be positive integers")
        if any(count < minimum_per_sport for count in counts):
            raise ValueError(
                f"Each {label.lower()} sport needs at least "
                f"{minimum_per_sport} athletes"
            )
        if sum(counts) != expected_total:
            raise ValueError(
                f"{label} sport counts must sum to "
                f"{label.lower()}_athletes={expected_total}"
            )
        return dict(sport_counts)

    development_sports = validate_sport_counts(
        "Development",
        config.development_sport_counts,
        config.development_athletes,
        3,
    )
    evaluation_sports = validate_sport_counts(
        "Evaluation",
        config.evaluation_sport_counts,
        config.evaluation_athletes,
        2,
    )
    if len(development_sports) < 2:
        raise ValueError("At least two development sports are required")
    if not isinstance(config.heldout_sport, str) or not config.heldout_sport.strip():
        raise ValueError("Held-out sport ID must be a nonempty string")
    if (
        not config.heldout_sport.isascii()
        or config.heldout_sport != config.heldout_sport.lower()
        or not config.heldout_sport[0].isalpha()
        or any(
            not (character.isalnum() or character == "_")
            for character in config.heldout_sport
        )
    ):
        raise ValueError(
            "Held-out sport ID must use lowercase ASCII letters, digits, and underscores"
        )
    if config.heldout_sport in development_sports:
        raise ValueError("Held-out sport must be absent from development")
    if config.heldout_sport not in evaluation_sports:
        raise ValueError("Held-out sport must be present in evaluation")
    missing_development_sports = set(development_sports) - set(evaluation_sports)
    if missing_development_sports:
        raise ValueError("All development sports must be present in evaluation")
    allowed_evaluation_sports = set(development_sports) | {config.heldout_sport}
    if set(evaluation_sports) != allowed_evaluation_sports:
        raise ValueError(
            "Evaluation may contain only development sports and the held-out sport"
        )
    if config.calibration_blocks < 4 or config.calibration_blocks % 2:
        raise ValueError("Guard calibration needs an even number of at least 4 blocks")
    if config.validation_blocks < 2:
        raise ValueError("Validation needs at least two blocks")
    if config.guard_checking_blocks != config.validation_blocks:
        raise ValueError("Guard checking and prospective validation block counts must match")
    if config.guard_checking_blocks % 2:
        raise ValueError("Guard checking needs an even block count for counterbalancing")
    if config.performance_noise_sd <= 0.0 or config.load_noise_sd <= 0.0:
        raise ValueError("Measurement noise standard deviations must be positive")
    if not -1.0 < config.outcome_noise_correlation < 1.0:
        raise ValueError("Outcome-noise correlation must lie strictly between -1 and 1")
    if config.covariance_floor <= 0.0:
        raise ValueError("Covariance floor must be positive")
    finite_values = (
        config.performance_noise_sd,
        config.load_noise_sd,
        config.outcome_noise_correlation,
        config.performance_period_effect,
        config.load_period_effect,
        config.covariance_floor,
        config.heldout_sport_shift,
        float(config.guard_checking_blocks),
        config.maximum_development_load_false_clearance_rate,
        config.maximum_development_performance_false_benefit_rate,
        config.thresholds.load_margin,
        config.thresholds.minimum_performance_gain,
        config.thresholds.safety_probability,
        config.thresholds.benefit_probability,
    )
    if not all(isfinite(value) for value in finite_values):
        raise ValueError("All numeric configuration values must be finite")
    if not 0.0 < config.thresholds.safety_probability < 1.0:
        raise ValueError("Safety score threshold must lie strictly between 0 and 1")
    if not 0.0 < config.thresholds.benefit_probability < 1.0:
        raise ValueError("Benefit score threshold must lie strictly between 0 and 1")
    if not 0.0 <= config.maximum_development_load_false_clearance_rate < 1.0:
        raise ValueError("Maximum load false-clearance rate must lie in [0, 1)")
    if not 0.0 <= config.maximum_development_performance_false_benefit_rate < 1.0:
        raise ValueError("Maximum performance false-benefit rate must lie in [0, 1)")
    if config.minimum_development_safety_clearances < 1:
        raise ValueError("At least one development safety clearance is required")
    sport_stratum_sizes = tuple(development_sports.values())
    conformal_athletes = sum(
        (stratum_size - stratum_size // 2) // 2
        for stratum_size in sport_stratum_sizes
    )
    _require_attainable_conformal_level(
        conformal_athletes,
        config.thresholds.safety_probability,
        "safety_probability",
    )
    _require_attainable_conformal_level(
        conformal_athletes,
        config.thresholds.benefit_probability,
        "benefit_probability",
    )
    if config.scenario not in {
        "heterogeneous",
        "high_signal",
        "homogeneous",
        "boundary",
        "null",
        "deployable_null",
        "unsafe",
    }:
        raise ValueError(f"Unknown scenario: {config.scenario}")


def regularize_covariance(matrix: Matrix, floor: float) -> Matrix:
    """Return a symmetric positive-definite covariance matrix."""

    if matrix.shape != (2, 2):
        raise ValueError("Expected a 2 x 2 covariance matrix")
    symmetric = 0.5 * (matrix + matrix.T)
    eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    clipped = np.maximum(eigenvalues, floor)
    adjusted = eigenvectors @ np.diag(clipped) @ eigenvectors.T
    return 0.5 * (adjusted + adjusted.T)


def _validate_trial_batch_structure(batch: TrialBatch) -> None:
    """Reject duplicate or incomplete athlete-cue-block calibration cells."""

    if batch.phase != "calibration":
        raise ValueError("Only calibration trials may enter model fitting")
    if not batch.pairs:
        raise ValueError("Calibration batch cannot be empty")

    seen_cells: set[tuple[str, str, int]] = set()
    sequence_indices: dict[str, set[int]] = {}
    sports: dict[str, str] = {}
    cells: dict[str, dict[str, set[int]]] = {}
    cue_first_counts: dict[tuple[str, str], int] = {}

    for pair in batch.pairs:
        cell = (pair.athlete_id, pair.cue, pair.block)
        if cell in seen_cells:
            raise ValueError(f"Duplicate calibration cell: {cell}")
        seen_cells.add(cell)
        if pair.block < 0 or pair.sequence_index < 0:
            raise ValueError("Block and sequence indices must be nonnegative")
        if {pair.cue_period, pair.control_period} != {1, 2}:
            raise ValueError(f"Invalid cue/control period order for {cell}")
        athlete_sequences = sequence_indices.setdefault(pair.athlete_id, set())
        if pair.sequence_index in athlete_sequences:
            raise ValueError(
                f"Duplicate sequence index for athlete {pair.athlete_id}: "
                f"{pair.sequence_index}"
            )
        athlete_sequences.add(pair.sequence_index)
        if pair.athlete_id in sports and sports[pair.athlete_id] != pair.sport:
            raise ValueError(f"Inconsistent sport for athlete {pair.athlete_id}")
        sports[pair.athlete_id] = pair.sport
        cells.setdefault(pair.athlete_id, {}).setdefault(pair.cue, set()).add(
            pair.block
        )
        cue_first_counts[cell[:2]] = cue_first_counts.get(cell[:2], 0) + int(
            pair.cue_period == 1
        )
        difference = pair.difference
        if difference.shape != (2,) or not np.all(np.isfinite(difference)):
            raise ValueError(f"Nonfinite or malformed outcome for {cell}")

    reference_cues: set[str] | None = None
    reference_blocks: set[int] | None = None
    for athlete_id, cue_blocks in cells.items():
        athlete_cues = set(cue_blocks)
        if reference_cues is None:
            reference_cues = athlete_cues
        elif athlete_cues != reference_cues:
            raise ValueError("Every athlete must have the same complete cue set")
        first_blocks = next(iter(cue_blocks.values()))
        for cue, blocks in cue_blocks.items():
            if blocks != first_blocks:
                raise ValueError(
                    f"Incomplete cue-by-block cells for athlete {athlete_id}, cue {cue}"
                )
            imbalance = abs(2 * cue_first_counts[(athlete_id, cue)] - len(blocks))
            if imbalance > 1:
                raise ValueError(
                    f"Cue/control order is not counterbalanced for {(athlete_id, cue)}"
                )
        if reference_blocks is None:
            reference_blocks = set(first_blocks)
        elif set(first_blocks) != reference_blocks:
            raise ValueError("Every athlete must have the same registered block cells")


def summarize_pairs(batch: TrialBatch, covariance_floor: float) -> EffectSummary:
    """Summarize randomized cue-control differences by athlete and cue."""

    _validate_trial_batch_structure(batch)

    grouped: dict[tuple[str, str], list[Vector]] = {}
    for pair in batch.pairs:
        grouped.setdefault((pair.athlete_id, pair.cue), []).append(pair.difference)

    means: dict[tuple[str, str], Vector] = {}
    covariances: dict[tuple[str, str], Matrix] = {}
    blocks: dict[tuple[str, str], int] = {}

    for key, values in grouped.items():
        array = np.vstack(values).astype(float)
        n_blocks = array.shape[0]
        if n_blocks < 2:
            raise ValueError(f"At least two paired blocks are required for {key}")
        sample_covariance = np.cov(array, rowvar=False, ddof=1)
        covariance_of_mean = np.asarray(sample_covariance, dtype=float) / n_blocks
        means[key] = np.mean(array, axis=0)
        covariances[key] = regularize_covariance(
            covariance_of_mean,
            covariance_floor,
        )
        blocks[key] = n_blocks

    return EffectSummary(means=means, mean_covariances=covariances, blocks=blocks)


def fit_population_prior(
    summary: EffectSummary,
    development_athlete_ids: Sequence[str],
    cues: Sequence[str],
    covariance_floor: float,
) -> PopulationPrior:
    """Estimate cue-specific population priors from development athletes only."""

    development_ids = tuple(development_athlete_ids)
    if len(set(development_ids)) != len(development_ids):
        raise ValueError("Development athlete IDs must be unique")
    if len(development_ids) < 3:
        raise ValueError("At least three development athletes are required")

    means: dict[str, Vector] = {}
    covariances: dict[str, Matrix] = {}
    mean_uncertainty_covariances: dict[str, Matrix] = {}
    athlete_counts: dict[str, int] = {}

    for cue in cues:
        keys = [(athlete_id, cue) for athlete_id in development_ids]
        missing = [key for key in keys if key not in summary.means]
        if missing:
            raise ValueError(f"Missing development summaries for cue {cue}: {missing[:3]}")

        athlete_means = np.vstack([summary.means[key] for key in keys])
        sampling_covariances = np.stack(
            [summary.mean_covariances[key] for key in keys],
            axis=0,
        )
        raw_between = np.cov(athlete_means, rowvar=False, ddof=1)
        estimated_between = raw_between - np.mean(sampling_covariances, axis=0)
        means[cue] = np.mean(athlete_means, axis=0)
        covariances[cue] = regularize_covariance(
            np.asarray(estimated_between, dtype=float),
            covariance_floor,
        )
        athlete_counts[cue] = len(development_ids)
        mean_uncertainty_covariances[cue] = regularize_covariance(
            np.asarray(raw_between, dtype=float) / len(development_ids),
            covariance_floor,
        )

    return PopulationPrior(
        cues=tuple(cues),
        means=means,
        covariances=covariances,
        development_athlete_ids=development_ids,
        mean_uncertainty_covariances=mean_uncertainty_covariances,
        athlete_counts=athlete_counts,
    )


def posterior_update(
    prior: PopulationPrior,
    personal_summary: EffectSummary,
    athlete_id: str,
    covariance_floor: float,
) -> AthletePosterior:
    """Combine the fixed development prior with one athlete's calibration."""

    if athlete_id in prior.development_athlete_ids:
        raise ValueError("Evaluation athlete appears in the development prior")

    posterior_means: dict[str, Vector] = {}
    posterior_covariances: dict[str, Matrix] = {}
    identity = np.eye(2)

    for cue in prior.cues:
        key = (athlete_id, cue)
        if key not in personal_summary.means:
            raise ValueError(f"Missing personal calibration for {key}")

        prior_mean_uncertainty = np.asarray(
            prior.mean_uncertainty_covariances.get(cue, np.zeros((2, 2))),
            dtype=float,
        )
        prior_covariance = regularize_covariance(
            np.asarray(prior.covariances[cue], dtype=float) + prior_mean_uncertainty,
            covariance_floor,
        )
        blocks = personal_summary.blocks[key]
        small_sample_multiplier = (
            student_t_critical(blocks - 1) / 1.959963984540054
        ) ** 2
        sampling_covariance = regularize_covariance(
            np.asarray(personal_summary.mean_covariances[key], dtype=float)
            * small_sample_multiplier,
            covariance_floor,
        )
        prior_precision = np.linalg.solve(prior_covariance, identity)
        sampling_precision = np.linalg.solve(sampling_covariance, identity)
        posterior_precision = prior_precision + sampling_precision
        posterior_covariance = np.linalg.solve(posterior_precision, identity)
        right_hand_side = (
            prior_precision @ prior.means[cue]
            + sampling_precision @ personal_summary.means[key]
        )
        posterior_mean = np.linalg.solve(posterior_precision, right_hand_side)

        posterior_means[cue] = posterior_mean
        posterior_covariances[cue] = regularize_covariance(
            posterior_covariance,
            covariance_floor,
        )

    return AthletePosterior(
        athlete_id=athlete_id,
        cues=prior.cues,
        means=posterior_means,
        covariances=posterior_covariances,
        future_mean_covariances=prior.future_mean_covariances,
        load_upper_critical=prior.load_upper_critical,
        performance_lower_critical=prior.performance_lower_critical,
        guard_calibration_passed=prior.guard_calibration_passed,
    )


def _split_guard_calibration_pairs(
    batch: TrialBatch,
    fitting_blocks: int,
    checking_blocks: int,
) -> tuple[TrialBatch, TrialBatch]:
    """Take registered B-cal fit blocks and B-val future-checking blocks."""

    _validate_trial_batch_structure(batch)
    if fitting_blocks < 2 or checking_blocks < 2:
        raise ValueError("Fit and future-checking sets each need at least two blocks")
    grouped: dict[tuple[str, str], list[TrialPair]] = {}
    for pair in batch.pairs:
        grouped.setdefault((pair.athlete_id, pair.cue), []).append(pair)

    fitting: list[TrialPair] = []
    checking: list[TrialPair] = []
    for key, pairs in grouped.items():
        ordered = sorted(pairs, key=lambda pair: (pair.block, pair.sequence_index))
        expected = fitting_blocks + checking_blocks
        if len(ordered) != expected:
            raise ValueError(
                f"Expected exactly {expected} blocks for {key}; found {len(ordered)}"
            )
        fitting.extend(ordered[:fitting_blocks])
        checking.extend(ordered[fitting_blocks:])

    fitting_batch = TrialBatch(phase="calibration", pairs=tuple(fitting))
    checking_batch = TrialBatch(phase="calibration", pairs=tuple(checking))
    _validate_trial_batch_structure(fitting_batch)
    _validate_trial_batch_structure(checking_batch)
    return fitting_batch, checking_batch


def _finite_sample_upper_quantile(values: Sequence[float], level: float) -> float:
    """Conformal upper quantile using ceil((n + 1) * level)."""

    if not 0.0 < level < 1.0:
        raise ValueError("Quantile level must lie strictly between zero and one")
    ordered = np.sort(np.asarray(values, dtype=float))
    if ordered.size == 0 or not np.all(np.isfinite(ordered)):
        raise ValueError("Conformal scores must be finite and nonempty")
    rank = ceil((ordered.size + 1) * level)
    if rank > ordered.size:
        return float("inf")
    return max(0.0, float(ordered[rank - 1]))


def _require_attainable_conformal_level(
    sample_size: int,
    level: float,
    name: str,
) -> None:
    """Reject a requested split-conformal level with no finite order statistic."""

    if sample_size < 1:
        raise ValueError("Conformal calibration requires at least one athlete")
    if ceil((sample_size + 1) * level) > sample_size:
        maximum_level = sample_size / (sample_size + 1)
        raise ValueError(
            f"{name}={level:.6g} is unattainable with {sample_size} conformal "
            f"athletes; use a level no greater than {maximum_level:.6g} or "
            "increase development N"
        )


def _exact_binomial_upper_bound(events: int, total: int) -> float:
    """Exact one-sided 95% Clopper-Pearson upper bound for a binomial rate."""

    if events < 0 or total < 0 or events > total:
        raise ValueError("Invalid binomial counts")
    if total == 0:
        return 1.0
    if events == total:
        return 1.0

    alpha = 0.05
    log_coefficients = tuple(
        lgamma(total + 1) - lgamma(count + 1) - lgamma(total - count + 1)
        for count in range(events + 1)
    )

    def binomial_cdf(probability: float) -> float:
        if probability <= 0.0:
            return 1.0
        if probability >= 1.0:
            return 0.0
        log_probability = log(probability)
        log_complement = log1p(-probability)
        log_terms = tuple(
            coefficient
            + count * log_probability
            + (total - count) * log_complement
            for count, coefficient in enumerate(log_coefficients)
        )
        maximum_log_term = max(log_terms)
        log_cumulative = maximum_log_term + log(
            fsum(exp(term - maximum_log_term) for term in log_terms)
        )
        return min(1.0, max(0.0, exp(log_cumulative)))

    lower = events / total
    upper = 1.0
    for _ in range(100):
        midpoint = 0.5 * (lower + upper)
        if binomial_cdf(midpoint) > alpha:
            lower = midpoint
        else:
            upper = midpoint
    return upper


def calibrate_policy_guard(
    development_trials: TrialBatch,
    development_athlete_ids: Sequence[str],
    cues: Sequence[str],
    thresholds: PolicyThresholds,
    covariance_floor: float,
    maximum_load_false_clearance_rate: float,
    maximum_performance_false_benefit_rate: float,
    minimum_safety_clearances: int,
    fitting_blocks: int,
    checking_blocks: int,
    split_seed: int,
) -> tuple[PopulationPrior, GuardCalibration]:
    """Fit, conformally calibrate, and audit a guard on disjoint athletes.

    A seeded sport-stratified split assigns half of development athletes to the
    population prior, one quarter to simultaneous conformal calibration, and one
    quarter to an untouched policy audit. Every athlete contributes B-cal blocks
    to personal updating and exactly B-val independent blocks to checking. B-val
    must match the prospective validation outcome block count.

    The resulting bound targets a future noisy block mean under athlete
    exchangeability. It is not a finite-sample bound for a latent causal effect and
    does not automatically transport to an unseen sport distribution.
    """

    athlete_ids = tuple(development_athlete_ids)
    if len(set(athlete_ids)) != len(athlete_ids):
        raise ValueError("Development athlete IDs must be unique")
    if len(athlete_ids) < 80:
        raise ValueError("At least 80 athletes are required for three-way calibration")

    sport_by_athlete: dict[str, str] = {}
    for pair in development_trials.pairs:
        existing = sport_by_athlete.get(pair.athlete_id)
        if existing is not None and existing != pair.sport:
            raise ValueError(f"Inconsistent sport for athlete {pair.athlete_id}")
        sport_by_athlete[pair.athlete_id] = pair.sport
    if set(sport_by_athlete) != set(athlete_ids):
        raise ValueError("Development trial athletes must exactly match registered IDs")

    split_rng = np.random.default_rng(split_seed)
    roles: dict[str, str] = {}
    for sport in sorted(set(sport_by_athlete.values())):
        stratum = np.asarray(
            sorted(
                athlete_id
                for athlete_id in athlete_ids
                if sport_by_athlete[athlete_id] == sport
            ),
            dtype=object,
        )
        split_rng.shuffle(stratum)
        fit_end = len(stratum) // 2
        conformal_end = fit_end + (len(stratum) - fit_end) // 2
        for athlete_id in stratum[:fit_end]:
            roles[str(athlete_id)] = "population_fit"
        for athlete_id in stratum[fit_end:conformal_end]:
            roles[str(athlete_id)] = "conformal_calibration"
        for athlete_id in stratum[conformal_end:]:
            roles[str(athlete_id)] = "independent_audit"

    population_fit_ids = tuple(
        sorted(
            athlete_id
            for athlete_id in athlete_ids
            if roles[athlete_id] == "population_fit"
        )
    )
    conformal_ids = tuple(
        sorted(
            athlete_id
            for athlete_id in athlete_ids
            if roles[athlete_id] == "conformal_calibration"
        )
    )
    audit_ids = tuple(
        sorted(
            athlete_id
            for athlete_id in athlete_ids
            if roles[athlete_id] == "independent_audit"
        )
    )
    if len(conformal_ids) < 20 or len(audit_ids) < 20:
        raise ValueError("Conformal calibration and audit each need at least 20 athletes")
    _require_attainable_conformal_level(
        len(conformal_ids),
        thresholds.safety_probability,
        "safety_probability",
    )
    _require_attainable_conformal_level(
        len(conformal_ids),
        thresholds.benefit_probability,
        "benefit_probability",
    )

    fitting_batch, checking_batch = _split_guard_calibration_pairs(
        development_trials,
        fitting_blocks,
        checking_blocks,
    )
    fitting_summary = summarize_pairs(fitting_batch, covariance_floor)
    checking_summary = summarize_pairs(checking_batch, covariance_floor)

    prior = fit_population_prior(
        fitting_summary,
        population_fit_ids,
        cues,
        covariance_floor,
    )
    future_covariances = {
        cue: regularize_covariance(
            np.mean(
                np.stack(
                    [
                        checking_summary.mean_covariances[(athlete_id, cue)]
                        for athlete_id in population_fit_ids
                    ],
                    axis=0,
                ),
                axis=0,
            ),
            covariance_floor,
        )
        for cue in prior.cues
    }
    prior = replace(prior, future_mean_covariances=future_covariances)

    load_max_scores: list[float] = []
    performance_max_scores: list[float] = []
    for athlete_id in conformal_ids:
        posterior = posterior_update(
            prior,
            fitting_summary,
            athlete_id,
            covariance_floor,
        )
        load_scores: list[float] = []
        performance_scores: list[float] = []
        for cue in prior.cues:
            checking_mean = checking_summary.means[(athlete_id, cue)]
            posterior_mean = posterior.means[cue]
            posterior_covariance = posterior.covariances[cue]
            future_covariance = posterior.future_mean_covariances[cue]
            performance_sd = sqrt(
                max(
                    float(posterior_covariance[0, 0] + future_covariance[0, 0]),
                    1e-15,
                )
            )
            load_sd = sqrt(
                max(
                    float(posterior_covariance[1, 1] + future_covariance[1, 1]),
                    1e-15,
                )
            )
            performance_scores.append(
                (float(posterior_mean[0]) - float(checking_mean[0])) / performance_sd
            )
            load_scores.append(
                (float(checking_mean[1]) - float(posterior_mean[1])) / load_sd
            )
        performance_max_scores.append(max(performance_scores))
        load_max_scores.append(max(load_scores))

    final_load_critical = _finite_sample_upper_quantile(
        load_max_scores,
        thresholds.safety_probability,
    )
    final_performance_critical = _finite_sample_upper_quantile(
        performance_max_scores,
        thresholds.benefit_probability,
    )
    audit_prior = replace(
        prior,
        load_upper_critical=final_load_critical,
        performance_lower_critical=final_performance_critical,
        guard_calibration_passed=True,
    )
    policy_names = ("personalized", "population_best", "random_feasible")
    audit_policy_clearances = {policy: 0 for policy in policy_names}
    audit_policy_load_false_clearances = {policy: 0 for policy in policy_names}
    audit_policy_performance_false_benefits = {policy: 0 for policy in policy_names}
    audit_rng = np.random.default_rng(split_seed ^ 0xA5A5A5A5)
    for athlete_id in audit_ids:
        posterior = posterior_update(
            audit_prior,
            fitting_summary,
            athlete_id,
            covariance_floor,
        )
        audit_decisions = (
            recommend_personalized(posterior, thresholds),
            recommend_population(audit_prior, posterior, thresholds),
            recommend_random_feasible(audit_prior, posterior, thresholds, audit_rng),
        )
        for decision in audit_decisions:
            if decision.cue is None:
                continue
            policy = decision.policy
            audit_policy_clearances[policy] += 1
            checking_mean = checking_summary.means[(athlete_id, decision.cue)]
            audit_policy_load_false_clearances[policy] += int(
                float(checking_mean[1]) > thresholds.load_margin
            )
            audit_policy_performance_false_benefits[policy] += int(
                float(checking_mean[0]) <= thresholds.minimum_performance_gain
            )

    load_false_uppers = {
        policy: _exact_binomial_upper_bound(
            audit_policy_load_false_clearances[policy],
            audit_policy_clearances[policy],
        )
        for policy in policy_names
    }
    performance_false_uppers = {
        policy: _exact_binomial_upper_bound(
            audit_policy_performance_false_benefits[policy],
            audit_policy_clearances[policy],
        )
        for policy in policy_names
    }
    minimum_policy_clearances = min(audit_policy_clearances.values())
    maximum_load_false_upper = max(load_false_uppers.values())
    maximum_performance_false_upper = max(performance_false_uppers.values())
    passed = (
        minimum_policy_clearances >= minimum_safety_clearances
        and maximum_load_false_upper <= maximum_load_false_clearance_rate
        and maximum_performance_false_upper
        <= maximum_performance_false_benefit_rate
        and isfinite(final_load_critical)
        and isfinite(final_performance_critical)
    )
    split_assignments = tuple(
        sorted(
            (
                athlete_id,
                sport_by_athlete[athlete_id],
                roles[athlete_id],
            )
            for athlete_id in athlete_ids
        )
    )
    split_payload = "\n".join("|".join(item) for item in split_assignments)
    split_assignment_hash = hashlib.sha256(split_payload.encode("utf-8")).hexdigest()
    calibration = GuardCalibration(
        load_upper_critical=final_load_critical,
        performance_lower_critical=final_performance_critical,
        audit_policy_clearances=audit_policy_clearances,
        audit_policy_load_false_clearances=audit_policy_load_false_clearances,
        audit_policy_load_false_clearance_uppers=load_false_uppers,
        audit_policy_performance_false_benefits=(
            audit_policy_performance_false_benefits
        ),
        audit_policy_performance_false_benefit_uppers=performance_false_uppers,
        minimum_policy_clearances=minimum_policy_clearances,
        maximum_load_false_clearance_upper=maximum_load_false_upper,
        maximum_performance_false_benefit_upper=maximum_performance_false_upper,
        population_fit_athletes=len(population_fit_ids),
        conformal_calibration_athletes=len(conformal_ids),
        independent_audit_athletes=len(audit_ids),
        split_seed=split_seed,
        split_assignment_hash=split_assignment_hash,
        split_assignments=split_assignments,
        passed=passed,
    )
    calibrated_prior = replace(
        prior,
        load_upper_critical=calibration.load_upper_critical,
        performance_lower_critical=calibration.performance_lower_critical,
        guard_calibration_passed=calibration.passed,
        guard_minimum_policy_clearances=calibration.minimum_policy_clearances,
        guard_maximum_load_false_clearance_upper=(
            calibration.maximum_load_false_clearance_upper
        ),
        guard_maximum_performance_false_benefit_upper=(
            calibration.maximum_performance_false_benefit_upper
        ),
    )
    return calibrated_prior, calibration


def score_cues(
    posterior: AthletePosterior,
    thresholds: PolicyThresholds,
) -> dict[str, CueScore]:
    """Calculate posterior benefit and load-safety probabilities."""

    scores: dict[str, CueScore] = {}
    for cue in posterior.cues:
        mean = posterior.means[cue]
        covariance = posterior.covariances[cue]
        performance_sd = sqrt(max(float(covariance[0, 0]), 1e-15))
        load_sd = sqrt(max(float(covariance[1, 1]), 1e-15))
        future_covariance = np.asarray(
            posterior.future_mean_covariances.get(cue, np.zeros((2, 2))),
            dtype=float,
        )
        decision_performance_sd = sqrt(
            max(float(covariance[0, 0] + future_covariance[0, 0]), 1e-15)
        )
        decision_load_sd = sqrt(
            max(float(covariance[1, 1] + future_covariance[1, 1]), 1e-15)
        )
        benefit_probability = normal_cdf(
            (float(mean[0]) - thresholds.minimum_performance_gain) / performance_sd
        )
        safe_probability = normal_cdf(
            (thresholds.load_margin - float(mean[1])) / load_sd
        )
        scores[cue] = CueScore(
            cue=cue,
            expected_performance=float(mean[0]),
            expected_load=float(mean[1]),
            performance_sd=performance_sd,
            load_sd=load_sd,
            decision_performance_sd=decision_performance_sd,
            decision_load_sd=decision_load_sd,
            performance_lower_bound=(
                float(mean[0])
                - posterior.performance_lower_critical * decision_performance_sd
            ),
            load_upper_bound=(
                float(mean[1]) + posterior.load_upper_critical * decision_load_sd
            ),
            safe_probability=safe_probability,
            benefit_probability=benefit_probability,
        )
    return scores


def recommend_personalized(
    posterior: AthletePosterior,
    thresholds: PolicyThresholds,
) -> Decision:
    """Rank cues by personal expected performance after both probability gates."""

    scores = score_cues(posterior, thresholds)
    feasible = (
        tuple(
            cue
            for cue in posterior.cues
            if scores[cue].load_upper_bound <= thresholds.load_margin
            and scores[cue].performance_lower_bound
            > thresholds.minimum_performance_gain
        )
        if posterior.guard_calibration_passed
        else ()
    )
    selected = (
        max(feasible, key=lambda cue: (scores[cue].expected_performance, cue))
        if feasible
        else None
    )
    return Decision(
        athlete_id=posterior.athlete_id,
        policy="personalized",
        cue=selected,
        feasible_cues=feasible,
        scores=scores,
    )


def recommend_population(
    prior: PopulationPrior,
    posterior: AthletePosterior,
    thresholds: PolicyThresholds,
) -> Decision:
    """Use population ranking inside the identical athlete-specific eligible set."""

    scores = score_cues(posterior, thresholds)
    feasible = (
        tuple(
            cue
            for cue in posterior.cues
            if scores[cue].load_upper_bound <= thresholds.load_margin
            and scores[cue].performance_lower_bound
            > thresholds.minimum_performance_gain
        )
        if posterior.guard_calibration_passed
        else ()
    )
    selected = (
        max(feasible, key=lambda cue: (float(prior.means[cue][0]), cue))
        if feasible
        else None
    )
    return Decision(
        athlete_id=posterior.athlete_id,
        policy="population_best",
        cue=selected,
        feasible_cues=feasible,
        scores=scores,
    )


def recommend_random_feasible(
    prior: PopulationPrior,
    posterior: AthletePosterior,
    thresholds: PolicyThresholds,
    rng: np.random.Generator,
) -> Decision:
    """Choose uniformly inside the identical athlete-specific eligible set."""

    scores = score_cues(posterior, thresholds)
    feasible = (
        tuple(
            cue
            for cue in posterior.cues
            if scores[cue].load_upper_bound <= thresholds.load_margin
            and scores[cue].performance_lower_bound
            > thresholds.minimum_performance_gain
        )
        if posterior.guard_calibration_passed
        else ()
    )
    selected = str(rng.choice(feasible)) if feasible else None
    return Decision(
        athlete_id=posterior.athlete_id,
        policy="random_feasible",
        cue=selected,
        feasible_cues=feasible,
        scores=scores,
    )


def _scenario_parameters(
    cue_count: int,
    scenario: str,
) -> tuple[Vector, Vector, Matrix]:
    if cue_count != 4:
        raise ValueError("The reference scenarios currently require exactly four cues")

    if scenario in {"heterogeneous", "high_signal"}:
        performance_means = np.asarray([0.10, 0.09, 0.08, 0.07], dtype=float)
        load_means = np.asarray([0.015, 0.030, 0.005, 0.035], dtype=float)
        between_covariance = np.asarray(
            [[0.13**2, 0.20 * 0.13 * 0.025], [0.20 * 0.13 * 0.025, 0.025**2]],
            dtype=float,
        )
    elif scenario == "homogeneous":
        performance_means = np.asarray([0.15, 0.06, 0.04, 0.02], dtype=float)
        load_means = np.asarray([0.010, 0.015, 0.005, 0.020], dtype=float)
        between_covariance = np.asarray(
            [[0.015**2, 0.0], [0.0, 0.004**2]],
            dtype=float,
        )
    elif scenario == "boundary":
        # Effects cluster near both decision boundaries to stress the gates.
        performance_means = np.asarray([0.035, 0.020, 0.010, -0.005], dtype=float)
        load_means = np.asarray([0.045, 0.050, 0.055, 0.040], dtype=float)
        between_covariance = np.asarray(
            [[0.05**2, 0.15 * 0.05 * 0.012], [0.15 * 0.05 * 0.012, 0.012**2]],
            dtype=float,
        )
    elif scenario == "null":
        # Every cue has exactly zero performance effect, so P-G truth is zero.
        performance_means = np.zeros(4, dtype=float)
        load_means = np.asarray([0.010, 0.015, 0.005, 0.020], dtype=float)
        between_covariance = np.asarray(
            [[0.0, 0.0], [0.0, 0.006**2]],
            dtype=float,
        )
    elif scenario == "deployable_null":
        # Every cue is equally beneficial and safely below the load boundary.
        # This keeps the policy deployable while the true P-minus-G value is zero.
        performance_means = np.full(4, 0.10, dtype=float)
        load_means = np.asarray([0.010, 0.015, 0.005, 0.020], dtype=float)
        between_covariance = np.asarray(
            [[0.0, 0.0], [0.0, 0.002**2]],
            dtype=float,
        )
    elif scenario == "unsafe":
        performance_means = np.asarray([0.14, 0.12, 0.10, 0.08], dtype=float)
        load_means = np.asarray([0.105, 0.115, 0.095, 0.125], dtype=float)
        between_covariance = np.asarray(
            [[0.05**2, 0.0], [0.0, 0.008**2]],
            dtype=float,
        )
    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    return performance_means, load_means, between_covariance


def simulate_truth(
    config: SimulationConfig,
    development_ids: Sequence[str],
    evaluation_ids: Sequence[str],
    rng: np.random.Generator,
) -> Truth:
    """Create cue effects for two development sports and one unseen sport."""

    performance_means, load_means, between_covariance = _scenario_parameters(
        len(config.cues),
        config.scenario,
    )
    athlete_sports: dict[str, str] = {}
    effects: dict[tuple[str, str], Vector] = {}

    def assign_sports(
        athlete_ids: Sequence[str],
        sport_counts: Sequence[tuple[str, int]],
    ) -> None:
        offset = 0
        for sport, count in sorted(sport_counts):
            for athlete_id in athlete_ids[offset : offset + count]:
                athlete_sports[athlete_id] = sport
            offset += count

    assign_sports(development_ids, config.development_sport_counts)
    assign_sports(evaluation_ids, config.evaluation_sport_counts)

    heldout_pattern = np.asarray([1.0, -1.0, 0.5, -0.5], dtype=float)
    for athlete_id in tuple(development_ids) + tuple(evaluation_ids):
        is_heldout = athlete_sports[athlete_id] == config.heldout_sport
        for cue_index, cue in enumerate(config.cues):
            shift = (
                config.heldout_sport_shift * heldout_pattern[cue_index]
                if is_heldout and config.scenario in {"heterogeneous", "high_signal"}
                else 0.0
            )
            random_effect = rng.multivariate_normal(
                mean=np.zeros(2),
                cov=between_covariance,
            )
            effects[(athlete_id, cue)] = np.asarray(
                [
                    performance_means[cue_index] + shift + random_effect[0],
                    load_means[cue_index] + random_effect[1],
                ],
                dtype=float,
            )

    return Truth(cues=config.cues, athlete_sports=athlete_sports, effects=effects)


def _measurement_covariance(config: SimulationConfig) -> Matrix:
    covariance = config.outcome_noise_correlation * (
        config.performance_noise_sd * config.load_noise_sd
    )
    return np.asarray(
        [
            [config.performance_noise_sd**2, covariance],
            [covariance, config.load_noise_sd**2],
        ],
        dtype=float,
    )


def _counterbalanced_flags(
    count: int,
    rng: np.random.Generator,
) -> tuple[bool, ...]:
    """Randomize an exactly balanced order when count is even, or within one if odd."""

    if count < 1:
        raise ValueError("Counterbalancing requires at least one observation")
    flags = np.asarray(
        [True] * (count // 2) + [False] * (count // 2),
        dtype=bool,
    )
    if count % 2:
        flags = np.append(flags, bool(rng.integers(0, 2)))
    rng.shuffle(flags)
    return tuple(bool(value) for value in flags)


def simulate_paired_trials(
    truth: Truth,
    athlete_ids: Sequence[str],
    blocks: int,
    config: SimulationConfig,
    rng: np.random.Generator,
    counterbalance_segments: Sequence[int] | None = None,
) -> TrialBatch:
    """Simulate randomized within-block cue and no-cue trials."""

    if blocks < 2:
        raise ValueError("At least two paired blocks are required")
    segments = tuple(counterbalance_segments) if counterbalance_segments else (blocks,)
    if any(segment < 1 for segment in segments) or sum(segments) != blocks:
        raise ValueError("Counterbalance segments must be positive and sum to blocks")
    covariance = _measurement_covariance(config)
    period_effect = np.asarray(
        [config.performance_period_effect, config.load_period_effect],
        dtype=float,
    )
    pairs: list[TrialPair] = []

    for athlete_id in athlete_ids:
        baseline = rng.normal(loc=np.asarray([1.0, 1.0]), scale=np.asarray([0.10, 0.05]))
        schedule = [(cue, block) for block in range(blocks) for cue in truth.cues]
        rng.shuffle(schedule)
        cue_first_by_pair: dict[tuple[str, int], bool] = {}
        for cue in truth.cues:
            block_offset = 0
            for segment in segments:
                flags = _counterbalanced_flags(segment, rng)
                for local_block, flag in enumerate(flags):
                    cue_first_by_pair[(cue, block_offset + local_block)] = flag
                block_offset += segment
        for sequence_index, (cue, block) in enumerate(schedule):
            block_drift = rng.normal(
                loc=np.zeros(2),
                scale=np.asarray([0.030, 0.006]),
            )
            first_error = rng.multivariate_normal(np.zeros(2), covariance)
            second_error = rng.multivariate_normal(np.zeros(2), covariance)
            cue_first = cue_first_by_pair[(cue, block)]
            effect = truth.effects[(athlete_id, cue)]

            if cue_first:
                cue_period, control_period = 1, 2
                cue_outcome = baseline + block_drift + effect + first_error
                control_outcome = baseline + block_drift + period_effect + second_error
            else:
                cue_period, control_period = 2, 1
                control_outcome = baseline + block_drift + first_error
                cue_outcome = (
                    baseline
                    + block_drift
                    + effect
                    + period_effect
                    + second_error
                )

            pairs.append(
                TrialPair(
                    athlete_id=athlete_id,
                    sport=truth.athlete_sports[athlete_id],
                    cue=cue,
                    block=block,
                    sequence_index=sequence_index,
                    cue_period=cue_period,
                    control_period=control_period,
                    cue_outcome=(float(cue_outcome[0]), float(cue_outcome[1])),
                    control_outcome=(
                        float(control_outcome[0]),
                        float(control_outcome[1]),
                    ),
                )
            )

    return TrialBatch(phase="calibration", pairs=tuple(pairs))


def lock_decisions(
    prior: PopulationPrior,
    personal_summary: EffectSummary,
    evaluation_ids: Sequence[str],
    config: SimulationConfig,
    rng: np.random.Generator,
) -> dict[str, tuple[Decision, ...]]:
    """Create all decisions before any validation outcomes exist."""

    decisions: dict[str, list[Decision]] = {
        "personalized": [],
        "population_best": [],
        "random_feasible": [],
    }
    for athlete_id in evaluation_ids:
        posterior = posterior_update(
            prior,
            personal_summary,
            athlete_id,
            config.covariance_floor,
        )
        decisions["personalized"].append(
            recommend_personalized(posterior, config.thresholds)
        )
        decisions["population_best"].append(
            recommend_population(prior, posterior, config.thresholds)
        )
        decisions["random_feasible"].append(
            recommend_random_feasible(prior, posterior, config.thresholds, rng)
        )
    return {policy: tuple(items) for policy, items in decisions.items()}


def simulate_validation(
    truth: Truth,
    decisions: Mapping[str, Sequence[Decision]],
    blocks: int,
    config: SimulationConfig,
    rng: np.random.Generator,
) -> tuple[ValidationOutcome, ...]:
    """Generate independent outcomes after decisions have been locked."""

    if blocks < 1:
        raise ValueError("At least one validation block is required")
    covariance_of_difference = 2.0 * _measurement_covariance(config)
    period_effect = np.asarray(
        [config.performance_period_effect, config.load_period_effect],
        dtype=float,
    )
    outcomes: list[ValidationOutcome] = []
    decisions_by_athlete: dict[str, list[Decision]] = {}
    for policy, policy_decisions in decisions.items():
        for decision in policy_decisions:
            if decision.policy != policy or not decision.locked:
                raise ValueError("Validation requires locked, correctly labeled decisions")
            decisions_by_athlete.setdefault(decision.athlete_id, []).append(decision)

    for athlete_id, athlete_decisions in decisions_by_athlete.items():
        shared_outcomes: dict[str | None, Vector] = {}
        for decision in athlete_decisions:
            if decision.cue not in shared_outcomes:
                if decision.cue is None:
                    # Abstention is the same action as the no-cue comparator.
                    shared_outcomes[None] = np.zeros(2)
                else:
                    effect = truth.effects[(athlete_id, decision.cue)]
                    block_differences: list[Vector] = []
                    cue_first_flags = _counterbalanced_flags(blocks, rng)
                    for cue_first in cue_first_flags:
                        order_sign = -1.0 if cue_first else 1.0
                        noise = rng.multivariate_normal(
                            np.zeros(2),
                            covariance_of_difference,
                        )
                        block_differences.append(
                            effect + order_sign * period_effect + noise
                        )
                    shared_outcomes[decision.cue] = np.mean(
                        np.vstack(block_differences),
                        axis=0,
                    )

            mean_difference = shared_outcomes[decision.cue]
            outcomes.append(
                ValidationOutcome(
                    athlete_id=athlete_id,
                    policy=decision.policy,
                    cue=decision.cue,
                    mean_difference=(
                        float(mean_difference[0]),
                        float(mean_difference[1]),
                    ),
                )
            )
    return tuple(outcomes)


def _mean_interval(
    values: Vector,
    one_sided: bool = False,
) -> tuple[float, float, float]:
    if values.size < 2:
        raise ValueError("At least two athlete-level values are required")
    mean = float(np.mean(values))
    standard_error = float(np.std(values, ddof=1) / sqrt(values.size))
    critical = student_t_critical(values.size - 1, one_sided=one_sided)
    return mean, mean - critical * standard_error, mean + critical * standard_error


def _decision_map(
    decisions: Mapping[str, Sequence[Decision]],
) -> dict[tuple[str, str], Decision]:
    mapped: dict[tuple[str, str], Decision] = {}
    for policy, items in decisions.items():
        for decision in items:
            if decision.policy != policy:
                raise ValueError("Decision policy label does not match its collection")
            key = (decision.athlete_id, policy)
            if key in mapped:
                raise ValueError(f"Duplicate decision record: {key}")
            mapped[key] = decision
    return mapped


def evaluate_policies(
    truth: Truth,
    decisions: Mapping[str, Sequence[Decision]],
    validation: Iterable[ValidationOutcome],
    thresholds: PolicyThresholds,
) -> dict[str, float | bool | int]:
    """Evaluate locked policies at the athlete level."""

    outcome_map: dict[tuple[str, str], Vector] = {}
    for outcome in validation:
        key = (outcome.athlete_id, outcome.policy)
        if key in outcome_map:
            raise ValueError(f"Duplicate validation outcome: {key}")
        outcome_map[key] = np.asarray(outcome.mean_difference)
    decision_map = _decision_map(decisions)
    if "personalized" not in decisions:
        raise ValueError("Personalized policy decisions are required")
    evaluation_ids = tuple(
        decision.athlete_id for decision in decisions["personalized"]
    )
    if len(set(evaluation_ids)) != len(evaluation_ids):
        raise ValueError("Evaluation athlete IDs must be unique")
    expected_keys = {
        (athlete_id, policy)
        for athlete_id in evaluation_ids
        for policy in ("personalized", "population_best", "random_feasible")
    }
    if set(decision_map) != expected_keys:
        raise ValueError("Each policy must contain exactly one decision per athlete")
    if set(outcome_map) != expected_keys:
        raise ValueError("Validation must contain exactly one outcome per policy and athlete")

    personalized_observed = np.vstack(
        [outcome_map[(athlete_id, "personalized")] for athlete_id in evaluation_ids]
    )
    population_observed = np.vstack(
        [outcome_map[(athlete_id, "population_best")] for athlete_id in evaluation_ids]
    )
    random_observed = np.vstack(
        [outcome_map[(athlete_id, "random_feasible")] for athlete_id in evaluation_ids]
    )

    paired_performance = personalized_observed[:, 0] - population_observed[:, 0]
    perf_mean, perf_lower, perf_upper = _mean_interval(paired_performance)
    load_mean, _, load_upper = _mean_interval(
        personalized_observed[:, 1],
        one_sided=True,
    )
    effect_sd = float(np.std(paired_performance, ddof=1))
    effect_size = perf_mean / effect_sd if effect_sd > 0.0 else 0.0

    personalized_true_performance: list[float] = []
    personalized_true_load: list[float] = []
    population_true_performance: list[float] = []
    random_true_performance: list[float] = []
    oracle_regrets: list[float] = []
    oracle_matches = 0
    covered = 0
    joint_successes = 0
    load_violations = 0
    load_score_squared_errors: list[float] = []
    benefit_score_squared_errors: list[float] = []
    marginal_95_coverage: list[float] = []
    safety_gate_clearances = 0
    safety_gate_false_clearances = 0
    policy_selected_counts = {
        "personalized": 0,
        "population_best": 0,
        "random_feasible": 0,
    }
    policy_true_load_violations = {policy: 0 for policy in policy_selected_counts}
    policy_true_false_benefits = {policy: 0 for policy in policy_selected_counts}

    for athlete_id in evaluation_ids:
        personal_decision = decision_map[(athlete_id, "personalized")]
        population_decision = decision_map[(athlete_id, "population_best")]
        random_decision = decision_map[(athlete_id, "random_feasible")]

        def true_effect(decision: Decision) -> Vector:
            if decision.cue is None:
                return np.zeros(2)
            return truth.effects[(athlete_id, decision.cue)]

        personal_effect = true_effect(personal_decision)
        population_effect = true_effect(population_decision)
        random_effect = true_effect(random_decision)
        personalized_true_performance.append(float(personal_effect[0]))
        personalized_true_load.append(float(personal_effect[1]))
        population_true_performance.append(float(population_effect[0]))
        random_true_performance.append(float(random_effect[0]))

        for policy, decision, effect in (
            ("personalized", personal_decision, personal_effect),
            ("population_best", population_decision, population_effect),
            ("random_feasible", random_decision, random_effect),
        ):
            if decision.cue is None:
                continue
            policy_selected_counts[policy] += 1
            policy_true_load_violations[policy] += int(
                float(effect[1]) > thresholds.load_margin
            )
            policy_true_false_benefits[policy] += int(
                float(effect[0]) <= thresholds.minimum_performance_gain
            )

        for cue, score in personal_decision.scores.items():
            true_cue_effect = truth.effects[(athlete_id, cue)]
            is_safe = float(true_cue_effect[1]) <= thresholds.load_margin
            is_beneficial = (
                float(true_cue_effect[0]) > thresholds.minimum_performance_gain
            )
            load_score_squared_errors.append(
                (score.safe_probability - float(is_safe)) ** 2
            )
            benefit_score_squared_errors.append(
                (score.benefit_probability - float(is_beneficial)) ** 2
            )
            marginal_95_coverage.extend(
                (
                    float(
                        abs(float(true_cue_effect[0]) - score.expected_performance)
                        <= 1.959963984540054 * score.performance_sd
                    ),
                    float(
                        abs(float(true_cue_effect[1]) - score.expected_load)
                        <= 1.959963984540054 * score.load_sd
                    ),
                )
            )
            if score.load_upper_bound <= thresholds.load_margin:
                safety_gate_clearances += 1
                safety_gate_false_clearances += int(not is_safe)

        truly_feasible = [
            cue
            for cue in truth.cues
            if float(truth.effects[(athlete_id, cue)][1]) <= thresholds.load_margin
            and float(truth.effects[(athlete_id, cue)][0])
            > thresholds.minimum_performance_gain
        ]
        oracle_cue = (
            max(
                truly_feasible,
                key=lambda cue: float(truth.effects[(athlete_id, cue)][0]),
            )
            if truly_feasible
            else None
        )
        oracle_performance = max(
            0.0,
            float(truth.effects[(athlete_id, oracle_cue)][0])
            if oracle_cue is not None
            else 0.0,
        )
        selected_constrained_utility = (
            max(0.0, float(personal_effect[0]))
            if float(personal_effect[1]) <= thresholds.load_margin
            else 0.0
        )
        oracle_regrets.append(oracle_performance - selected_constrained_utility)

        if personal_decision.cue is not None:
            covered += 1
            load_violations += int(float(personal_effect[1]) > thresholds.load_margin)
            oracle_matches += int(personal_decision.cue == oracle_cue)
            joint_successes += int(
                float(personal_effect[0]) > thresholds.minimum_performance_gain
                and float(personal_effect[1]) <= thresholds.load_margin
            )

    true_load_violation_rate = (
        load_violations / covered if covered else float("nan")
    )
    coverage = covered / len(evaluation_ids)

    result: dict[str, float | bool | int] = {
        "evaluation_athletes": len(evaluation_ids),
        "performance_difference_observed": perf_mean,
        "performance_difference_ci_lower": perf_lower,
        "performance_difference_ci_upper": perf_upper,
        "performance_difference_effect_size_dz": effect_size,
        "personalized_load_observed": load_mean,
        "personalized_load_one_sided_95_upper": load_upper,
        "performance_superiority_gate": perf_lower > 0.0,
        "load_noninferiority_gate": load_upper <= thresholds.load_margin,
        "primary_gate": perf_lower > 0.0 and load_upper <= thresholds.load_margin,
        "personalized_true_performance": float(
            np.mean(np.asarray(personalized_true_performance))
        ),
        "personalized_true_load": float(np.mean(np.asarray(personalized_true_load))),
        "population_true_performance": float(
            np.mean(np.asarray(population_true_performance))
        ),
        "random_true_performance": float(np.mean(np.asarray(random_true_performance))),
        "true_personalized_minus_population": float(
            np.mean(
                np.asarray(personalized_true_performance)
                - np.asarray(population_true_performance)
            )
        ),
        "recommendation_coverage": coverage,
        "abstention_rate": 1.0 - coverage,
        "recommended_count": covered,
        "true_load_violation_count": load_violations,
        "joint_success_count": joint_successes,
        "oracle_match_count": oracle_matches,
        "true_load_violation_rate_when_recommended": true_load_violation_rate,
        "joint_success_rate_when_recommended": (
            joint_successes / covered if covered else float("nan")
        ),
        "oracle_match_rate_when_recommended": (
            oracle_matches / covered if covered else float("nan")
        ),
        "mean_true_constrained_regret_to_oracle": float(
            np.mean(np.asarray(oracle_regrets))
        ),
        "load_model_score_brier": (
            float(np.mean(load_score_squared_errors))
            if load_score_squared_errors
            else float("nan")
        ),
        "benefit_model_score_brier": (
            float(np.mean(benefit_score_squared_errors))
            if benefit_score_squared_errors
            else float("nan")
        ),
        "posterior_marginal_95_coverage": (
            float(np.mean(marginal_95_coverage))
            if marginal_95_coverage
            else float("nan")
        ),
        "safety_gate_clearance_count": safety_gate_clearances,
        "safety_gate_false_clearance_count": safety_gate_false_clearances,
        "personalized_observed_performance": float(np.mean(personalized_observed[:, 0])),
        "population_observed_performance": float(np.mean(population_observed[:, 0])),
        "random_observed_performance": float(np.mean(random_observed[:, 0])),
    }
    for policy in ("personalized", "population_best", "random_feasible"):
        selected = policy_selected_counts[policy]
        result[f"{policy}_recommended_count"] = selected
        result[f"{policy}_true_load_violation_count"] = (
            policy_true_load_violations[policy]
        )
        result[f"{policy}_true_false_benefit_count"] = (
            policy_true_false_benefits[policy]
        )
        result[f"{policy}_true_load_violation_rate_when_recommended"] = (
            policy_true_load_violations[policy] / selected
            if selected
            else float("nan")
        )
        result[f"{policy}_true_false_benefit_rate_when_recommended"] = (
            policy_true_false_benefits[policy] / selected
            if selected
            else float("nan")
        )
    return result


def run_replication(
    config: SimulationConfig,
    seed: int,
) -> dict[str, float | bool | int | str]:
    """Run one leakage-separated design replication."""

    validate_config(config)

    seed_sequence = np.random.SeedSequence(seed)
    (
        truth_seed,
        development_seed,
        split_seed_sequence,
        personal_seed,
        policy_seed,
        validation_seed,
    ) = seed_sequence.spawn(6)
    split_seed = int(split_seed_sequence.generate_state(1, dtype=np.uint32)[0])
    development_ids = tuple(
        f"dev_{index:03d}" for index in range(config.development_athletes)
    )
    evaluation_ids = tuple(
        f"eval_{index:03d}" for index in range(config.evaluation_athletes)
    )
    if set(development_ids) & set(evaluation_ids):
        raise RuntimeError("Development and evaluation athletes overlap")

    truth = simulate_truth(
        config,
        development_ids,
        evaluation_ids,
        np.random.default_rng(truth_seed),
    )
    development_trials = simulate_paired_trials(
        truth,
        development_ids,
        config.calibration_blocks + config.guard_checking_blocks,
        config,
        np.random.default_rng(development_seed),
        counterbalance_segments=(
            config.calibration_blocks,
            config.guard_checking_blocks,
        ),
    )
    prior, guard_calibration = calibrate_policy_guard(
        development_trials,
        development_ids,
        config.cues,
        config.thresholds,
        config.covariance_floor,
        config.maximum_development_load_false_clearance_rate,
        config.maximum_development_performance_false_benefit_rate,
        config.minimum_development_safety_clearances,
        config.calibration_blocks,
        config.guard_checking_blocks,
        split_seed,
    )

    personal_trials = simulate_paired_trials(
        truth,
        evaluation_ids,
        config.calibration_blocks,
        config,
        np.random.default_rng(personal_seed),
    )
    personal_summary = summarize_pairs(personal_trials, config.covariance_floor)
    decisions = lock_decisions(
        prior,
        personal_summary,
        evaluation_ids,
        config,
        np.random.default_rng(policy_seed),
    )

    # The validation generator is instantiated only after decisions are locked.
    validation = simulate_validation(
        truth,
        decisions,
        config.validation_blocks,
        config,
        np.random.default_rng(validation_seed),
    )
    metrics = evaluate_policies(truth, decisions, validation, config.thresholds)
    sport_diagnostic_fields = (
        "evaluation_athletes",
        "recommendation_coverage",
        "abstention_rate",
        "performance_difference_observed",
        "personalized_load_observed",
        "true_personalized_minus_population",
        "personalized_true_load",
    )
    for sport, registered_count in sorted(config.evaluation_sport_counts):
        sport_ids = {
            athlete_id
            for athlete_id in evaluation_ids
            if truth.athlete_sports[athlete_id] == sport
        }
        if len(sport_ids) != registered_count:
            raise RuntimeError(f"Observed sport allocation does not match {sport}")
        sport_decisions = {
            policy: tuple(
                decision
                for decision in policy_decisions
                if decision.athlete_id in sport_ids
            )
            for policy, policy_decisions in decisions.items()
        }
        sport_validation = tuple(
            outcome for outcome in validation if outcome.athlete_id in sport_ids
        )
        sport_metrics = evaluate_policies(
            truth,
            sport_decisions,
            sport_validation,
            config.thresholds,
        )
        for field_name in sport_diagnostic_fields:
            metrics[f"sport_{sport}_{field_name}"] = sport_metrics[field_name]
    metrics["seed"] = seed
    metrics["scenario"] = config.scenario
    metrics["development_athletes"] = config.development_athletes
    metrics["development_sport_counts_json"] = json.dumps(
        sorted(config.development_sport_counts),
        separators=(",", ":"),
    )
    metrics["evaluation_sport_counts_json"] = json.dumps(
        sorted(config.evaluation_sport_counts),
        separators=(",", ":"),
    )
    metrics["heldout_sport"] = config.heldout_sport
    metrics["calibration_blocks"] = config.calibration_blocks
    metrics["validation_blocks"] = config.validation_blocks
    metrics["guard_checking_blocks"] = config.guard_checking_blocks
    metrics["guard_calibration_passed"] = guard_calibration.passed
    metrics["guard_load_upper_critical"] = guard_calibration.load_upper_critical
    metrics["guard_performance_lower_critical"] = (
        guard_calibration.performance_lower_critical
    )
    metrics["guard_audit_clearances"] = guard_calibration.minimum_policy_clearances
    metrics["guard_audit_false_clearances"] = max(
        guard_calibration.audit_policy_load_false_clearances.values()
    )
    metrics["guard_audit_false_clearance_upper"] = (
        guard_calibration.maximum_load_false_clearance_upper
    )
    metrics["guard_audit_minimum_policy_clearances"] = (
        guard_calibration.minimum_policy_clearances
    )
    metrics["guard_audit_maximum_load_false_clearance_upper"] = (
        guard_calibration.maximum_load_false_clearance_upper
    )
    metrics["guard_audit_maximum_performance_false_benefit_upper"] = (
        guard_calibration.maximum_performance_false_benefit_upper
    )
    for policy in ("personalized", "population_best", "random_feasible"):
        metrics[f"guard_audit_{policy}_clearances"] = (
            guard_calibration.audit_policy_clearances[policy]
        )
        metrics[f"guard_audit_{policy}_load_false_clearances"] = (
            guard_calibration.audit_policy_load_false_clearances[policy]
        )
        metrics[f"guard_audit_{policy}_load_false_clearance_upper"] = (
            guard_calibration.audit_policy_load_false_clearance_uppers[policy]
        )
        metrics[f"guard_audit_{policy}_performance_false_benefits"] = (
            guard_calibration.audit_policy_performance_false_benefits[policy]
        )
        metrics[f"guard_audit_{policy}_performance_false_benefit_upper"] = (
            guard_calibration.audit_policy_performance_false_benefit_uppers[policy]
        )
    metrics["guard_split_seed"] = guard_calibration.split_seed
    metrics["guard_split_assignment_hash"] = (
        guard_calibration.split_assignment_hash
    )
    metrics["guard_population_fit_athletes"] = (
        guard_calibration.population_fit_athletes
    )
    metrics["guard_conformal_calibration_athletes"] = (
        guard_calibration.conformal_calibration_athletes
    )
    metrics["guard_independent_audit_athletes"] = (
        guard_calibration.independent_audit_athletes
    )
    return metrics


def decision_signature(
    decisions: Mapping[str, Sequence[Decision]],
) -> tuple[tuple[str, str, str | None], ...]:
    """Stable representation used to audit locked decisions."""

    return tuple(
        sorted(
            (decision.athlete_id, decision.policy, decision.cue)
            for items in decisions.values()
            for decision in items
        )
    )
