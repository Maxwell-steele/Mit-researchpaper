# CausalMove Results-to-Manuscript Output Contract

**Status:** Pre-analysis specification. No listed real-data output exists yet.  
**Purpose:** Bind every manuscript number and conclusion to one immutable analysis output after database lock.  
**Applies to:** `ssac27-full-paper-final-pre-results.md`, `ssac27-abstract.md`, Figure 2, and the public results tables.  
**Does not apply to:** synthetic design simulations or software fixtures.

This contract prevents manual result selection. The final manuscript may display rounded values, but every displayed value must resolve to a field in the signed results bundle. If an output is missing, non-finite, inconsistent, or unhashed, the corresponding manuscript field remains unresolved.

## 1. Immutable results bundle

The confirmatory analysis creates one new, no-overwrite directory only after:

1. prospective enrollment and all scheduled follow-up windows are closed;
2. every participant, visit, action, slot, attempt, deviation, and adverse event has a terminal state;
3. masked acquisition and task-fidelity adjudication is complete;
4. the database, exclusion log, measurement registry, policy/action mapping, and analysis environment are locked;
5. the frozen analysis source and configuration hashes match the prospective freeze manifest; and
6. the independent custodian authorizes unmasking under the preregistered procedure.

Required bundle root:

```text
results_bundle/
  RESULTS_READY
  results-manifest.json
  participant-flow.json
  gate0-coverage.json
  gate1-load.json
  gate2-performance.json
  task-failures.tsv
  phone-reference-agreement.tsv
  heldout-handball.tsv
  retention.tsv
  reactive-transfer.tsv
  operations-safety.json
  development-ablation.tsv
  athlete-policy-contrasts.tsv
  claim-input.json
  claim-decision.json
  table1-prospective-results.tsv
  table2-development-ablation.tsv
  figure2-athlete-contrasts.svg
  manuscript-values.json
  reproduction-report.json
```

`RESULTS_READY` is valid only when the manifest hashes every sibling artifact and records a successful cross-file invariant check. Because a manifest cannot include its own final digest as a sibling entry, its digest is recorded in the separately signed freeze/release record.

## 2. Manifest requirements

`results-manifest.json` must include:

- study, protocol, preregistration, cue-registry, measurement-registry, data-release, and policy-freeze identifiers;
- database snapshot digest and analysis-ready release digest;
- model, comparator, eligible-set, action-mapping, randomization, missingness, and analysis source hashes;
- software environment and dependency lock digest;
- creation UTC, analysis run ID, custodian approval record, and unmasking audit event;
- the exact command and working-directory contract used to build the bundle;
- every artifact's relative path, SHA-256 digest, row count or object count, schema version, privacy tier, and role;
- `contains_synthetic_athlete_results=false` and `contains_real_prospective_results=true`; and
- the invariant-check outcome and reproduction-report digest.

No path may escape the bundle. No result artifact may be overwritten in place.

## 3. Canonical result files

### 3.1 `participant-flow.json`

Required fields:

- screened, excluded before consent, consented, enrolled, began calibration, randomized to policy crossover, included in the primary policy-value set, included in the safety set, completed Session 2, allocated to practice, completed retention, completed reactive transfer, withdrawn, safety-stopped, operationally stopped, and lost to follow-up;
- each count overall and by basketball, soccer, and handball;
- mutually exclusive primary reasons where required; and
- reconciliation to `athletes`, `sessions`, `assignments`, and the participant-flow audit.

### 3.2 `gate0-coverage.json`

Required fields:

- policy-value denominator \(N_P\);
- active personalized recommendations \(x_P\);
- \(C_P=x_P/N_P\);
- two-sided 95% Wilson lower and upper limits;
- locked \(C_{min}\);
- Boolean `gate0_pass = lower_95 > C_min`; and
- abstention counts by controlled reason and sport.

### 3.3 `gate1-load.json`

Required fields:

- complete policy-value denominator and missingness categories;
- mean \(D_L\), standard error, degrees of freedom, and one-sided 97.5% upper confidence bound;
- locked \(\delta_L\), boundary-null p-value, and Boolean `gate1_pass = upper_97_5 < delta_L`;
- counts of shared-action exact zeros, observed contrasts, technically imputed contrasts, exposed nontechnical penalties, and downstream least-favorable bounds;
- primary, 10,000-resample athlete-bootstrap, complete-technical-case, and tipping-point estimates; and
- adverse-event wording veto state, reported separately from the numeric load gate.

### 3.4 `gate2-performance.json`

Required fields:

- complete policy-value denominator and missingness categories;
- mean \(D_Y\), standard error, degrees of freedom, two-sided 95% interval, and boundary-null p-value;
- locked \(\delta_Y\);
- Boolean `gate2_pass = gate0_pass and gate1_pass and upper_95 < 0`;
- Boolean `practical_margin_pass = gate2_pass and upper_95 < -delta_Y`;
- shared-action exact-zero, observed, failure-penalized, technically imputed, and downstream least-favorable counts;
- primary, 10,000-resample sport-stratified athlete-bootstrap, complete-technical-case, adjusted, and median sensitivities; and
- unpenalized successful-cut time as a descriptive secondary result, clearly separated from the primary score.

### 3.5 Supporting files

- `task-failures.tsv`: scheduled and observed denominators, failures by policy/action/sport/reason, and P-minus-G rate contrast with athlete-level uncertainty.
- `phone-reference-agreement.tsv`: one row per registered measure/event with attempts, athletes, bias, MAE, RMSE, CCC, calibration intercept/slope, Bland–Altman limits, athlete-bootstrap intervals, tolerance, and pass state.
- `heldout-handball.tsv`: handball-only Gate 0–2 quantities and uncertainty, explicitly labeled an empirical transport stress test.
- `retention.tsv`: intention-to-treat practice-arm contrast, confidence interval, p-value, Holm-adjusted p-value, denominators, missingness, and same-action descriptive subset.
- `reactive-transfer.tsv`: the separately named reactive outcome with the same inferential fields; filler trials are excluded and reconciled separately.
- `operations-safety.json`: setup/processing times, abstentions, coach vetoes/overrides under the allowed workflow, technical failures, workload, adverse events, severity, seriousness, relatedness, and study/cue pauses.
- `development-ablation.tsv`: frozen model ladder, athlete-held-out split, metric direction, point estimate, athlete-level interval, coverage, regret, unsafe clearance, and unconditional/active-only policy value.
- `athlete-policy-contrasts.tsv`: one row per athlete and registered P-minus-G or P-minus-N contrast, including sport, contrast source, missingness state, shared-action identity, and analysis weight.
- `claim-input.json`: an exact-schema projection of the locked coverage lower bound and minimum, load upper bound and margin, and performance upper bound and practical margin from the three canonical gate files. It is generated, never hand-entered.

## 4. Manuscript traceability matrix

There are **22 actual `RESULT REQUIRED` slots** in the final pre-results manuscript. The status sentence is not a result slot.

| Slot | Manuscript location | Required source | Required fields / artifact | Release condition |
|---|---|---|---|---|
| R01 | Abstract composite result sentence | `manuscript-values.json` | participant flow, Gates 0–2, phone agreement, retention, transfer, failures, adverse events | All referenced component outputs valid |
| R02 | Table 1 participant flow | `participant-flow.json` | overall and sport counts | Flow reconciliation passes |
| R03 | Table 1 coverage | `gate0-coverage.json` | `x_P`, `N_P`, percent, Wilson interval, `C_min`, pass | Denominator and policy records reconcile |
| R04 | Table 1 load | `gate1-load.json` | `D_L`, SE, upper bound, `delta_L`, p-value, pass | Contrast-builder audit passes |
| R05 | Table 1 performance | `gate2-performance.json` | `D_Y`, SE, 95% interval, p-value, `delta_Y`, gate/practical states | Gate order and contrast audit pass |
| R06 | Table 1 task failures | `task-failures.tsv` | policy counts/rates and contrast | Scheduled slots reconcile |
| R07 | Table 1 phone agreement | `phone-reference-agreement.tsv` | MAE, RMSE, CCC, calibration, bias/limits | Measurement rows and athlete bootstrap valid |
| R08 | Table 1 handball | `heldout-handball.tsv` | n, coverage, `D_L`, `D_Y`, intervals | Pre-freeze handball exclusion verified |
| R09 | Table 1 retention | `retention.tsv` | feedback-free ITT contrast and interval | Practice randomization reconciles |
| R10 | Table 1 reactive transfer | `reactive-transfer.tsv` | named outcome, ITT contrast, interval | Reactive/filler task IDs reconcile |
| R11 | Table 1 operations/safety | `operations-safety.json` | time, abstention, veto/override, adverse events | Safety and workload audits reconcile |
| R12 | Table 2 development ablations | `table2-development-ablation.tsv` | all five frozen comparisons, metrics, intervals, coverage, regret, and unsafe clearance | Model ladder, split, and prospective/computational evidence roles reconcile |
| R13 | Figure 2 | `figure2-athlete-contrasts.svg` | athlete-level P−G and P−N contrasts, intervals, sport, failure marks | No trial/frame pseudo-replication; figure digest valid |
| R14 | Failed-gate Discussion sentence | `claim-decision.json` | ordered failed gate IDs and required lead sentence | Deterministic claim engine passes |
| R15 | Submission blocker: ethics/release | signed governance record | ethics ID and approved public-release language | Human/document verification |
| R16 | Submission blocker: resources | signed Gate A record | laboratory, equipment, staff, access, custodian | Every evidence path inspected |
| R17 | Submission blocker: randomization/rehearsal | approved amendment and rehearsal bundle | versions, signatures, seal, reconciliation | Independent rehearsal review passes |
| R18 | Submission blocker: pilot/constants/sample | reliability bundle and registration | `C_min`, `delta_L`, `delta_Y`, `F_Y`, `kappa_L`, sample sizes | Pilot decision meeting and freeze complete |
| R19 | Submission blocker: phone model | phone model/measurement bundle | model hash and prospective agreement report | Measurement claim rule passes or phone claim removed |
| R20 | Submission blocker: development | development bundle | cohort flow, model/policy freeze, ablations | Independent development audit passes |
| R21 | Submission blocker: prospective cohort | confirmatory bundle | untouched-cohort identity audit and all Table 1 outputs | Results bundle valid |
| R22 | Submission blocker: reproduction | `reproduction-report.json` | clean-clone environment, command, output digests, reviewer | All paper artifacts reproduced |

R15–R22 are removed from a submission manuscript only after their evidence exists. They must not be converted into claims or silently deleted because a deadline arrives.

## 5. `manuscript-values.json`

This file is the only permitted source for values pasted into the abstract or narrative prose. It is generated from the canonical files above and contains:

- a stable key for every displayed value;
- unrounded numeric value and unit;
- display string under the frozen rounding rule;
- source file, source field, and source-file digest;
- analysis population and denominator;
- interval type and level;
- claim status (`permitted`, `weaker_only`, or `prohibited`); and
- every manuscript destination using that value.

The generator must reject a key when its source field is null, non-finite, outside its declared unit/domain, or inconsistent with another destination.

### 5.1 Abstract key map

| Abstract placeholder | Required `manuscript-values.json` key |
|---|---|
| Enrolled/analyzed `[N]` | `flow.primary_policy_value_n.display` |
| Active `[x/N]` | `gate0.active_over_denominator.display` |
| Coverage `[%]` | `gate0.coverage_percent.display` |
| Coverage interval `[L, U]` | `gate0.wilson_95.display` |
| `[did/did not]` | `gate0.boundary_phrase` derived only from `gate0_pass` |
| `[C_min]` | `gate0.minimum.display` |
| Load `[estimate]` | `gate1.mean_contrast.display` |
| Load `[U_L]` | `gate1.upper_97_5.display` |
| Load `[delta_L]` | `gate1.margin.display` |
| Performance `[estimate]` | `gate2.mean_contrast.display` |
| Performance `[L_Y, U_Y]` | `gate2.ci_95.display` |
| Task-failure-rate `[estimate]` | `failures.p_minus_g_rate_contrast.display` |
| Phone `[MAE/CCC]` | `phone.headline_measure_summary.display`, with the measure named |
| Phone limits `[values]` | `phone.headline_measure_loa_95.display` |
| Held-out-sport `[estimate]` | `handball.performance_contrast.display` |
| Held-out-sport `[L, U]` | `handball.performance_ci_95.display` |
| Adverse-event total `[N]` | `safety.adverse_event_n.display` |
| Possibly related `[N]` | `safety.possibly_related_or_higher_n.display` |
| Conclusion branch | `claim.lead_conclusion` copied verbatim from `claim-decision.json` |

The phone headline measure is selected before unmasking in the measurement registry. It cannot be whichever variable produces the best agreement.

## 6. Gate-derived conclusion engine

`claim-decision.json` is deterministic. It may not be hand-edited. The tested generator is `analysis/generate_claim_decision.py`; its complete interface and test command are documented in `analysis/README.md`. It reads only exact-schema `claim-input.json`, embeds the SHA-256 of those exact input bytes, rejects malformed, duplicate, non-finite, missing, and unexpected values, and refuses to overwrite an existing decision file. The bundle audit must verify that every `claim-input.json` value equals its named canonical gate-file field before the generator runs.

The generator records the three numeric boundary states independently as `gate0_pass`, `gate1_boundary_pass`, and `gate2_boundary_pass`. `confirmatory_claim_pass` is true only when all three are true. This naming prevents a favorable Gate 2 boundary alone from being mistaken for passage through the ordered confirmatory sequence.

| Gate state | Required lead conclusion |
|---|---|
| Gate 0 fails | The athlete-specific ranking policy was not confirmed because active-recommendation coverage did not exceed the registered minimum. |
| Gate 0 passes; Gate 1 fails | The athlete-specific ranking policy was not confirmed because mechanical-load noninferiority to neutral instruction was not established. |
| Gates 0–1 pass; Gate 2 fails | The athlete-specific ranking policy was not confirmed because it did not outperform the frozen population ranking on the registered task-performance score. |
| Gates 0–2 pass; practical margin fails | The personalized policy achieved a lower registered acute task-performance score while satisfying coverage and load gates; the result did not establish the prespecified practically meaningful margin. |
| Gates 0–2 and practical margin pass | The personalized policy achieved a practically meaningful improvement in the registered acute task-performance score while satisfying coverage and load gates. |

Additional clauses are independent:

- no favorable retention result → no training-benefit wording;
- no favorable reactive-transfer result → no transfer wording;
- phone agreement failure → no phone-only deployment wording;
- moderate-or-worse intervention-related adverse event → no “safe” or “well tolerated” wording;
- null `M3_FULL` versus simpler baseline → no model-complexity claim; and
- handball result → empirical stress-test wording only, never universal generalization.

## 7. Rounding and presentation

- Counts remain integers; denominators always appear with percentages.
- Percentages and confidence limits use one decimal place unless the frozen style guide requires more to avoid a false zero.
- Times use seconds with the precision justified by the timing system; model analysis remains on the unrounded log scale.
- Normalized knee moment uses N·m/kg and a common decimal precision across estimate, interval, and margin.
- P-values report exact values to three significant digits when ≥0.001 and `<0.001` otherwise; gate decisions depend on intervals, not rounded p-values.
- No displayed interval is recomputed from rounded endpoints.
- Tables state interval direction and confidence level in headers or footnotes.
- The abstract, Table 1, Figure 2, and Discussion must show identical display strings for shared values.

The rounding configuration is frozen before unmasking and hashed in the results manifest.

## 8. Cross-file invariants

Bundle creation fails unless all checks pass:

1. Participant totals reconcile across flow, athlete, assignment, policy-value, safety, retention, transfer, and adverse-event records.
2. Gate 0 denominator contains every eligible prospective athlete who began calibration, including structural-neutral calibration failures.
3. P, G, and N action mappings join to one frozen planned-action definition; matching actions have matching hashes and exact-zero contrasts.
4. Each scheduled slot is observed, technically missing, exposed failure, or downstream-unexposed exactly once.
5. Performance and load contrast counts sum to the policy-value denominator.
6. Technical imputation never absorbs task failure, safety failure, downstream unexposure, or adverse events.
7. All primary estimates use athletes—not frames or trials—as independent resampling units.
8. Sport-stratified bootstrap resamples exactly 10,000 times with the registered seed distinct from randomization.
9. Handball contributes no pre-freeze development, calibration-guard, threshold, or population-ranking data.
10. Retention and transfer preserve randomized practice assignment by intention to treat.
11. Reactive cuts and straight-run fillers use distinct task identifiers; fillers never enter the reactive outcome.
12. Table 1 and Table 2 values equal their canonical source rows before rounding.
13. Figure 2 point estimates match `athlete-policy-contrasts.tsv` and its annotations match the gate files.
14. Every abstract value matches `manuscript-values.json` exactly.
15. Every null, adverse, subgroup, and sensitivity result required by the preregistration appears in the release.

## 9. Figure 2 contract

Figure 2 must show athlete-level evidence, not a decorative average:

- Panel A: P-minus-G `task_performance_score`; lower favors personalized ranking.
- Panel B: P-minus-N normalized peak external knee abduction moment; lower favors personalized ranking.
- One mark per athlete-level registered contrast, with sport encoded redundantly by shape and direct group label.
- Task/safety-failure composites and least-favorable bounds use distinct outlined symbols and a caption explanation.
- Shared-action exact zeros remain visible at zero.
- Group estimate and its registered interval are overlaid; Panel B displays \(\delta_L\), and Panel A displays zero and \(-\delta_Y\).
- Gate state and coverage appear in the caption, not as celebratory color.
- The figure generator reads only `athlete-policy-contrasts.tsv`, gate files, and a frozen style configuration.
- If athlete count makes raw marks unreadable, use sport-faceted jitter with deterministic placement; do not hide participants through density smoothing.

The current `figures/README.md` remains authoritative for the design figure. Figure 2 cannot be rendered before real prospective results.

## 10. Independent reproduction report

`reproduction-report.json` must be created by a person who did not write the analysis pipeline. It records:

- clean-clone repository URL and commit;
- environment/container digest and operating system;
- exact command, start/end UTC, and exit code;
- input release-manifest digest;
- generated output paths and digests;
- equality verdict for Table 1, Table 2, Figure 2, `manuscript-values.json`, and `claim-decision.json`;
- any approved nondeterministic metadata exclusion; and
- reviewer identity/role and signed record reference.

No submission-ready state is permitted when reproduction differs, an input is unavailable, or the public package cannot legally contain the data supporting a headline claim.

## 11. Current state

As of September 27, 2026:

- no real pilot, development, or prospective analysis bundle exists;
- all R01–R22 slots remain unresolved;
- Figure 1 is complete because it represents the preregistered design, not observed results;
- Figure 2 is blocked by prospective data; and
- the abstract and paper remain pre-results artifacts.
