# Study Protocol: CausalMove Cross-Sport Cutting Study

**Version:** Draft 0.2, September 12, 2026  
**Status:** Design draft; not execution-ready. The reliability-pilot randomization design awaits user, statistician, safety, and ethics approval, and workload ledgers and phase-specific replacement rules remain incomplete. A reviewed Stage 1 synthetic-only phone scaffold implements manifests, canonical trajectories, explicit test events, registry-backed features, provenance, and a fail-closed outcome firewall. It does not implement or validate real capture, pose estimation, event detection, phone-reference measurement, or athlete-facing recommendations.  
**Primary task:** Planned 90-degree sidestep cut  
**Sports:** Basketball, soccer, and handball  
**Study type:** Prospective, staged, randomized policy-evaluation study

## 1. Scientific Contract

### Primary question

Can a frozen athlete-specific response model use a short randomized cue-calibration session to rank eligible movement cues better than a frozen population ranking under the same athlete-specific eligibility guard, while remaining noninferior to `CTRL_NEUTRAL_V1` on a prespecified mechanical-load outcome?

### Confirmatory claim

The confirmatory claim is permitted only if all three gates pass:

1. The lower confidence bound for athlete-specific active-recommendation coverage reaches the locked operational minimum \(C_{min}\).
2. The athlete-specific policy is noninferior to `CTRL_NEUTRAL_V1` on the primary mechanical-load outcome.
3. After the first two gates pass, the athlete-specific policy is superior to the population-ranked policy on the primary performance outcome.

The study does not test injury incidence and cannot support an injury-prevention claim. It also does not test whether any proprietary movement system is correct. GOATA and WOATA labels are excluded from the model, outcomes, and confirmatory claims.

## 2. Study Architecture

| Stage | Planned sample | Purpose | Use in confirmatory inference |
|---|---:|---|---|
| Readiness | None | Ethics, equipment, synchronization, cue safety, and public-release approval | No |
| Reliability pilot | 12-15 adults from the development sports | Determine acquisition count, test-retest error, task corridor, tested pilot-task workload, and whether the proposed margins are measurable | No |
| Model development | Joint-simulation target from basketball and soccer | Train and tune the video measurement model, response model, abstention rule, and population cue ranking | No |
| Policy freeze | None | Hash code, weights, features, thresholds, and population policy before prospective testing | Required |
| Prospective validation | Joint-simulation target of new adults allocated across all three sports | Test acute policy value with the frozen system | Yes |
| Training and follow-up | Same prospective cohort | Test retention and reactive transfer after randomized cue practice | Secondary |

The final development and validation samples are set together by pilot-informed simulation, with no access to confirmatory outcomes, and both are frozen before development recruitment begins. If the safety-calibration guard uses disjoint prior-fit, conformal-calibration, and audit subsets, development recruitment must also satisfy its separately simulated split and upper-confidence-bound minimum. The current implementation rejects fewer than 80 development athletes and uses 100 with an approximately 50/25/25 sport-stratified allocation as a planning configuration. Exact integer counts depend on strata and are frozen before outcomes. These numbers are constraints to test, not evidence of power. A reference simulator or its defaults cannot establish sample adequacy. Handball is the planned held-out sport for the population prior. It contributes no pre-freeze participant data, including reliability data. If access requires another sport to be held out, that change must be registered before the reliability pilot begins.

## 3. Required Readiness Gate

Recruitment cannot begin until all items below are documented.

- Institutional ethics approval covers maximal-effort cutting, algorithm-selected cue delivery, repeat visits, adverse-event follow-up, and the planned public release.
- Consent forms separate research participation from public release of identifiable or potentially re-identifiable video.
- A sports medicine clinician or licensed physiotherapist approves the screening and emergency plan.
- A biomechanist and qualified coach approve each cue, dose, and exclusion boundary.
- Before pilot enrollment, freeze the candidate two-phone configuration set and its acceptance rules: view roles, placement and orientation tolerances, candidate frame rate and hardware range, intrinsic/extrinsic calibration, synchronization method, and acquisition-QC thresholds.
- The reference system includes synchronized force plates at 1,000 Hz or higher and three-dimensional kinematics at 200 Hz or higher.
- The force-measurement area covers every registered plant envelope without asking the athlete to target a plate. If it cannot cover the full `PLANT_OFFSET_REDUCE_V1` envelope, that cue is removed before randomization.
- Timing, synchronization, force, and camera pipelines pass a dry run with a known event marker.
- The team confirms that the exact analysis data can be released under the current SSAC rules without violating consent or local law.

After the reliability pilot and before model-development recruitment, apply the pre-pilot acceptance rules using acquisition and measurement-reliability results only, then freeze and hash one final camera configuration. If no candidate passes, stop, amend the protocol, and repeat the relevant pilot; cue-response or prospective outcomes cannot select the configuration.

If only pressure insoles are available, this protocol cannot construct the primary `policy_load_contrast_analysis_value`, because its raw reference constituent is peak external knee abduction moment. An insole-only study requires a separately registered plantar-load outcome and cannot describe that measurement as joint load or injury risk.

## 4. Team Roles and Separation of Duties

- **Principal investigator:** protocol accountability and ethics reporting.
- **Safety lead:** eligibility review, session stopping decisions, and adverse-event assessment.
- **Biomechanics lead:** equipment calibration, trial-validity rules, and reference outcome extraction.
- **Coach:** cue wording, familiarization, and safety review. The coach cannot alter the cue after policy freeze.
- **ML lead:** training code, model card, freeze manifest, and recommendation generation.
- **Independent statistician or data custodian:** randomization, blinded analysis dataset, and code release.
- **Session operator:** standardized warm-up and trial delivery. The operator sees cue text but not whether it came from the athlete-specific or population policy.

No person may change a policy output after seeing the athlete's validation outcomes. Before final P/G decisions, the safety reviewer evaluates every athlete-specific cue-target candidate under neutral codes without seeing policy source, ranking, or predicted benefit. A veto removes that candidate from the common P/G candidate set, after which both frozen fallback rules rerun. Store `raw_model_decision`, `final_system_decision`, `veto_rule_id`, `reviewer_id`, and `review_created_utc`. Gate 0 counts final deliverable P decisions only.

## 5. Participants

### Inclusion criteria

- Age 18-35 years.
- Current organized basketball, soccer, or handball participation at least twice per week during the prior six months.
- At least one year of experience performing planned changes of direction.
- Able to complete the screening cut and maximal-effort familiarization without pain or instability.
- Able to provide informed consent and attend all scheduled visits.
- For the prospective SSAC analysis cohort, willing to release the analysis-ready tabular and derived movement data described in the ethics-approved disclosure statement. Raw-video release remains a separate choice.
- For prospective validation, not sharing a current competitive team or regular training group (`team_cluster_id`) with another enrolled validation athlete; if this is infeasible, a separately powered clustered design must be registered before validation begins.

### Exclusion criteria

- Current lower-limb or back pain greater than 2 on a 0-10 scale during daily activity or screening.
- Lower-limb injury or surgery for which a treating clinician has not cleared maximal cutting.
- Concussion symptoms, uncontrolled cardiopulmonary disease, neurological impairment, or another condition that makes maximal cutting unsafe.
- Use of medication or equipment that the safety lead determines materially changes safe participation.
- Inability to complete the pilot-locked screening minimum after familiarization.

Prior injury, sex, sport level, race or ethnicity, and body size are recorded but are not post hoc exclusion criteria. Participants may stop at any time without losing earned compensation.

### Plant side and standardization

The primary plant limb is the limb the athlete chooses for a maximal planned 90-degree cut during screening. The same limb, footwear, surface, and approach direction are used at every registered cut visit. The other side is outside the confirmatory study and may be recorded only as an explicitly descriptive extension.

## 6. Privacy and Consent

Whole-body movement video can remain identifiable after face blurring. Consent must explain the residual risk of recognition from body shape, gait, tattoos, footwear, or clothing.

The capture area therefore uses:

- lower-body framing whenever it preserves the registered measurements;
- plain study clothing with no name, team number, or sponsor mark;
- no audio recording;
- removal of faces and background by framing at capture rather than relying only on later editing;
- participant IDs that do not encode sport, date, or identity;
- a separate encrypted linkage file with access limited to the data custodian.

The consent form includes separate choices for research participation, public release of analysis-ready tabular and derived movement data, and release of processed or raw video. Pose, gait, detailed trajectories, exact anthropometry, and rare adverse-event combinations are treated as potentially re-identifiable rather than automatically anonymous.

Consent to the approved public analysis-ready release is a prospective eligibility requirement for the SSAC validation cohort. People who decline may enter a separately declared internal feasibility cohort, but that cohort is assigned before any outcome is observed and never enters SSAC analyses. Raw-video release remains optional unless SSAC confirms that raw video is required. If raw video is required for a headline result, the SSAC cohort must provide specific public-video consent before enrollment or that result cannot be submitted.

A disclosure-risk review tests re-identification risk, small cells, rare trajectories, and linkage through timestamps or team information before recruitment. Data minimization or controlled access may be used only if SSAC provides written acceptance that it satisfies the competition rule.

## 7. Movement Task and Cue Library

### Standard task

The athlete accelerates along a five-metre approach, plants the prespecified limb on an embedded force-plate region without being instructed to target it, turns 90 degrees, and accelerates three metres through the exit gate. Entry speed is held within the athlete-specific band frozen from the reliability pilot. Path boundaries are marked on the floor.

### Candidate cue set

The versioned source of truth is `cue-library.md`. Each active condition changes one registered feature. Directions are hypotheses, not claims that the movement is universally better. A conservative numerical pilot dose grid is approved and frozen before pilot enrollment; the final main-study increment is selected later by applying the preregistered rule to masked reliability, executability, and safety evidence.

| ID | Registered role or direction | Target rule |
|---|---|---|
| `BASE_NATURAL_V1` | Natural-technique anchor before randomized probes | No technique target |
| `CTRL_NEUTRAL_V1` | Attention-matched control | Task, effort, entry-speed, cut-angle, and path requirements only |
| `FPA_ALIGN_EXIT_V1` | Reduce absolute plant-foot alignment error relative to the exit axis | Pilot-locked increment from the athlete's natural baseline, clipped to the rehearsed range |
| `PLANT_OFFSET_REDUCE_V1` | Reduce absolute lateral plant offset from projected centre of mass | Pilot-locked increment from the athlete's natural baseline, clipped to the rehearsed range |
| `BRAKE_EARLIER_V1` | Increase the share of deceleration completed before plant contact | Pilot-locked increment from the athlete's natural baseline, clipped to the rehearsed range |
| `TRUNK_TOWARD_EXIT_V1` | Increase signed trunk lean toward the exit at plant contact | Pilot-locked increment from the athlete's natural baseline, clipped to the rehearsed range |

The athlete sees the exact wording and demonstration version stored in the cue registry. Before pilot enrollment, the team registers for each active cue a conservative dose grid, starting dose, maximum dose, staged rehearsal sequence, and dose-specific stopping boundary. Numerical grid values remain `[LOCK BEFORE PILOT]` until the biomechanist, coach, safety lead, and ethics body approve them. Every pilot target is computed and timestamped before cue delivery.

Rehearsal begins at the lowest registered dose and submaximal effort. Escalation occurs only after the athlete executes the target within its corridor without new pain, instability, balance loss, or safety-lead concern. The main-study increment is the smallest registered dose that passes the pilot-locked reliability, executability, and safety rule. If no dose passes, the cue is retired. The pilot cannot introduce a dose outside the registered grid, and no cue can be added after development outcomes are inspected.

The final wording, main-study increment, target tolerance, and safety envelope are versioned before model development. The policy may choose only active cues whose target lies inside that athlete's successfully rehearsed range and observed calibration support.

Cue adherence is measured from achieved kinematics. Poor adherence does not invalidate a trial for the intention-to-treat analysis.

## 8. Visit Procedures

### Visit 0: consent and screening

1. Obtain written consent before collecting identifiable data.
2. Complete health screening, injury history, pain score, sport exposure, and demographic measures.
3. Measure height, mass, leg length, and preferred plant limb.
4. Complete a standardized dynamic warm-up.
5. Perform submaximal and then maximal familiarization cuts.
6. Record eligibility and any exclusion reason before randomization.

### Reliability pilot: two visits

Pilot visits are separated by 3-7 days and occur at the same time of day within two hours where feasible.

1. Complete the standardized warm-up and baseline pain/RPE check.
2. Record the pre-pilot-locked number \(B_{0,pilot}\) of `BASE_NATURAL_V1` cuts.
3. Deliver one practice trial for each active cue.
4. For each active cue, record the pre-pilot-locked number \(B_{pair,pilot}\) of paired blocks. Each block contains one `CTRL_NEUTRAL_V1` trial and one active-cue trial in randomized order. Balance active-cue pair order across athletes.
5. Apply the pre-pilot washout schedule before each cue family and between members of a pair. It includes the locked minimum rest, the neutral reset instruction, and any registered non-analysed reset trials.
6. Repeat the same structure at Visit 2 with a new randomized block order.

Pilot data determine the number of acquisition-complete pairs needed for stable condition means. Pilot participants do not enter model-development or confirmatory efficacy analyses.

The pilot also tests the registered previous-cue effect after each proposed washout. If the confidence interval exceeds the locked carryover tolerance, lengthen washout and retest before development. If no feasible schedule passes, abandon paired crossover calibration and register a new first-period or parallel design. A sensitivity analysis cannot substitute for a failed washout criterion.

### Model-development cohort

Development participants complete the same randomized paired calibration schedule used in prospective validation. Reference sensor data may be used to fit the phone measurement layer and response model. Before outcome access, a frozen sport-stratified randomizer canonicalizes athlete IDs, applies the registered seeded shuffle, and assigns athletes—not trials—to disjoint prior-fit, conformal-calibration, and audit roles whenever the safety-calibration guard is used. The canonical ordering prevents ingestion order from changing the assignment; it is not itself the assignment rule. Tuning occurs only inside the prior-fit role with athlete-grouped folds; the conformal and audit roles remain sealed for their registered functions. All trials from one athlete remain in one role.

The held-out sport contributes no data to population-model fitting, feature selection, hyperparameter selection, cue ranking, conformal calibration, audit-bound selection, or threshold selection. Its prospective calibration trials may enter only that athlete's permitted `personal_update_role`; its later outcomes are `prospective_outcome_role=evaluation`.

### Prospective Validation Session 1: calibration

1. Complete warm-up, pain score, wellness check, and the locked familiarization sequence.
2. Record the pilot-locked number \(B_0\) of `BASE_NATURAL_V1` trials to describe natural movement. These trials are separate from the paired causal contrasts.
3. Give one non-analysed practice attempt for each active cue.
4. For each active cue, record the pilot-locked number \(B_{cal}\) of paired blocks. A block contains one `CTRL_NEUTRAL_V1` trial and one active-cue trial, with within-pair order randomized. Balance the order of cue pairs across athletes.
5. Apply the pilot-locked washout schedule before each cue family and between members of a pair. Store pair ID, replicate, within-pair position, previous cue, washout trial IDs, and any `replacement_of_trial_id` link.
6. Record reference sensors for evaluation, but keep those outcomes encrypted and unavailable to the recommendation pipeline, session team, and model developers. Reference processing may proceed only under masked action labels; decoding waits for database and analysis lock.
7. Run the frozen pipeline using only registered deployment inputs.
8. Write a signed `recommendation.json` containing athlete ID, eligible cues, selected cue or abstention, predicted changes, uncertainty, model hash, feature hash, and timestamp.

The population model and thresholds remain fixed. Only the prespecified athlete-level posterior update is allowed from that athlete's calibration trials.

### Prospective Validation Session 2: acute policy test

Session 2 occurs 2-7 days after Session 1.

1. Repeat the standardized warm-up and readiness check.
2. Test three policies: athlete-specific policy P, frozen population-ranked policy G, and fixed `CTRL_NEUTRAL_V1` policy N.
3. Hide policy source from the athlete by presenting distinct actions with neutral codes and identical timing and display format.
4. Pregenerate \(B_{val}\) scheduled trial slots for each distinct nonstructural planned action, provide the locked familiarization sequence, then attempt those slots under the workload and stop rules. A calibration-failure structural-neutral action has zero exposure slots.
5. After the policy-action map is created, let \(K_i\) be that athlete's number of distinct planned actions. Draw uniformly from the \(K_i!\) unique action orders, record probability \(1/K_i!\), and include the locked neutral washout between blocks.
6. If any of P, G, and N resolve to an identical intended action, the mapper must reuse one `planned_action_id` with a matching complete `planned_action_definition_hash`. Collect one shared action block and assign zero to each contrast between policies sharing that planned action. This includes P=G, P=N, G=N, and P=G=N. Do not duplicate the same observations as independent data.
7. If the athlete-specific policy abstains, record the decision as `abstain` and deliver `CTRL_NEUTRAL_V1` as its validation action. Abstention remains part of policy-value estimation.

After acute testing, participants are randomized 1:1 to practise either the athlete-specific policy or the population-ranked policy. They complete the matching-task-feasibility-locked number \(B_{train}\) of coached trials in the registered block structure, with standardized video feedback. The core reliability pilot alone cannot set this count. Participants whose policies map to the same planned action receive that common action but remain in the randomized intention-to-treat follow-up analysis.

### Prospective Validation Session 3: retention and transfer

Session 3 occurs 7 days after Session 2, with a permitted window of plus or minus 2 days.

1. Repeat the warm-up and readiness check.
2. Record the matching-task-feasibility-locked number \(B_{ret}\) of planned 90-degree cuts after the neutral instruction "perform the cut as practised." Do not provide technical reminders or trial-level feedback.
3. Record the matching-task-feasibility-locked number \(B_{xfer}\) of reactive 90-degree cuts using the same plant limb, interspersed with the locked number \(B_{fill}\) of straight-run filler trials. A randomized light indicates "cut" or "continue" during the locked pre-plant interval. The exact sequence and interval distribution are frozen before validation. Filler trials prevent full anticipation and are excluded from the registered transfer outcome.
4. Record confidence, cue recall, pain, RPE, and any training exposure since Session 2.

Retention and transfer are secondary. The study cannot generalize these results to live competition because there is no defender contact, tactical choice, or uncontrolled camera view.

**Proposed physical-visit amendment, pending approval:** Session 2's `policy_validation` and `practice` segments would share one physical-visit identifier; Session 3's `retention` and `transfer` segments would share another. A phase change would not reset cumulative total-attempt, maximal-attempt, replacement, fatigue, or safety counters. The current data schema does not implement this proposal. User, safety, statistics, and ethics approval plus a versioned schema amendment are required before adoption or field use.

## 9. Acquisition, Task Fidelity, and Attempt Handling

Every assigned attempt remains in the policy record. Outcome magnitude, high load, poor cue adherence, task failure, and apparent lack of benefit are never deletion reasons.

`planned_action_definition_hash` is created before delivery from the registered cue, version, target, text, demonstration, and safety bundle. Every attempted trial then receives a `realized_deliveries` record containing the realized cue, target, text, demonstration, `realized_delivery_hash`, and status. A wrong or partial delivery remains assigned to its planned action for intention-to-treat analysis. P/G/N collision zeros use only pre-delivery planned-action identity—the same `planned_action_id` with a matching complete `planned_action_definition_hash`—and can never be created retrospectively from what happened to be delivered.

### Acquisition failure

A genuine acquisition failure is a corrupted or missing required file, synchronization failure, instrument saturation, confirmed processing failure under the frozen algorithm, or an external interruption unrelated to the athlete's movement. Record the failure before condition decoding. Replacement units and caps are phase-specific and are not yet fully incorporated into the canonical protocol. Until that contract is approved and frozen, no generic attempt-level replacement operation is authorized. Every failed attempt remains in the flow and missingness log.

### Task-fidelity or cue-related failure

Wrong plant limb, entry speed outside the requested corridor, path or cut-angle error, missed force area caused by foot placement, slip, stumble, inability to execute a target, and a safety stop after exposure are post-assignment outcomes. They are not exclusions, and no replacement is scheduled because the outcome was unfavourable. A pre-delivery `safety_veto` removes the candidate symmetrically before final P/G decisions; a resulting abstention maps to `CTRL_NEUTRAL_V1`.

The primary performance measure is `task_performance_score`. A completed trial receives \(\ln(\mathtt{cut\_completion\_time}/1\,\mathrm{s})\). A task or safety failure after exposure receives the development-computed failure value \(F_Y\), set worse than the registered upper tail of successful development trials by the penalty \(\kappa_Y\). The tail estimator, \(\kappa_Y\) formula, development subset, and reason hierarchy are locked before model development; only their prescribed numerical evaluation is filled from development data and frozen before prospective enrollment. Report unpenalized cut time and task-failure rate separately so the composite cannot hide either component.

Load is measured whenever reference acquisition exists, including task-fidelity failures. `peak_external_knee_abduction_moment_normalized` is the raw reference outcome and remains null when unavailable. The canonical primary analysis variable is the derived P-minus-N `policy_load_contrast_analysis_value`. A load outcome and the contrast margin \(\delta_L\) are not interchangeable quantities. For distinct P and N planned actions, any task- or safety-related missing load after exposure invokes \(d_i^L=\delta_L+\kappa_L\), with \(\kappa_L>0\) frozen before prospective enrollment. If P and N share one `planned_action_id` and its complete hash matches, \(d_i^L=0\). Tipping-point analyses vary \(\kappa_L\).

For calibration, an active-control sensor contrast is complete only when both members have usable acquisition. Under the proposed reliability-pilot randomization design, timely masked terminal QC may activate the next same-cue pregenerated replacement pair under a separate athlete-wide paired-replacement cap. This rule remains unauthorized until the design and cap are approved and incorporated. A cue-related task or safety failure enters the registered performance score; an unavailable load measurement makes that cue fail the load-evidence screen for the athlete rather than receiving an absolute value based on \(\delta_L\).

## 10. Technology and Frozen Policy

### Deployment inputs

The validation policy may use only:

- the two synchronized phone videos;
- the assigned cue label;
- height, mass, leg length, and plant side if these fields were registered as model inputs;
- trials collected during that athlete's calibration session.

Force plates and laboratory motion capture from the prospective cohort are evaluation references. They cannot enter the recommendation calculation.

### Model

The planned model is a hierarchical multi-output treatment-response model. It predicts the change from `CTRL_NEUTRAL_V1` in `task_performance_score` and `peak_external_knee_abduction_moment_normalized` for each eligible active cue. Each active-cue trial is differenced against its randomized paired control trial. The calibration likelihood includes within-pair position, pair replicate, previous cue, and global period. Shared block drift cancels in the paired contrast, while randomized order and the locked washout schedule reduce period and carryover bias. Population parameters are learned in development. A new athlete receives a prespecified posterior update from the fixed calibration schedule.

The common P/G eligibility guard retains a cue only when all conditions hold:

1. posterior probability that improvement exceeds the locked \(\delta_Y\) is at least 0.80;
2. posterior probability that the load change is no greater than the locked margin is at least 0.95;
3. prediction uncertainty is below the locked performance and load thresholds;
4. the proposed target remains inside observed support and the safety envelope.

The 0.80 and 0.95 quantities may be presented as probabilities only if development-set calibration passes the frozen Brier-score, reliability-curve, and coverage checks. A recalibration map may be fitted in development and frozen. Failure after freeze produces abstention or blocks prospective deployment; it does not permit threshold tuning on validation outcomes.

P ranks the resulting common eligible set by athlete-specific predicted performance. G ranks the same set by the frozen population order. If the set is empty, both return `abstain` with a controlled reason code and their validation action is `CTRL_NEUTRAL_V1`. The safety-veto screen operates on the shared candidate set before both P and G are finalized; it cannot veto a cue only because one policy selected it.

### Population-ranked comparator

Development data define one frozen ranking of active cues by cross-validated population-average performance. P and G receive the same non-sport context, athlete-specific performance and load eligibility bounds, cue set, target construction, uncertainty rule, observed-support rule, safety veto, fallback, and one-cue action budget. P orders the common eligible set by that athlete's posterior expected performance; G ignores the athlete-specific performance ordering and selects the first cue in the frozen population order. This isolates athlete-specific ranking rather than comparing two policies with unequal opportunity to recommend. The population ranking and common guard are not re-estimated by sport or after prospective outcomes are observed.

Report P and G coverage separately. Decompose the P-minus-G policy difference into athletes with different active cues, personalized abstention, population abstention, and policy concordance.

If the registered calibration minimum is not met, the system must still emit P and G `abstain` records with reason `calibration_failed`, one N `fixed_neutral` record, and three mappings to the same planned `CTRL_NEUTRAL_V1` action using reason `calibration_failure_structural_neutral`. Gate 0 counts P as inactive. No alternative undefined coverage state is permitted.

### Freeze manifest

Before the first prospective validation participant is enrolled or produces baseline or calibration data, archive:

- source-code commit and container or lockfile hash;
- training and development participant IDs;
- external pretraining datasets, licences, versions, checksums, and participant-overlap checks;
- feature list and preprocessing parameters;
- model architecture, weights, priors, random seeds, and hyperparameters;
- cue library and eligibility rules;
- cue-registry, data-dictionary, measure-registry, QC-rule, and safety-rule hashes;
- P/G/N policy-decision and planned-action mapping specification, plus the per-trial realized-delivery schema;
- ethics-approved consent version and public-release plan;
- performance, load, uncertainty, and abstention thresholds;
- operational minimum recommendation coverage \(C_{min}\) and its external justification;
- washout schedule and no-carryover diagnostic;
- population cue ranking;
- randomization generator version;
- complete analysis script and synthetic-data dry-run output.

Any change after freeze is a protocol deviation. A necessary safety change triggers a documented amendment and may require a new validation cohort.

### Required policy QA before freeze

The implementation must pass deterministic tests showing that:

- development, pilot, and prospective athlete IDs are disjoint;
- all views and trials from one athlete remain in one split;
- changing, deleting, or permuting validation outcomes cannot change a locked recommendation;
- fixed seeds reproduce the same calibration summary and decision;
- known infeasible or load-violating fixtures produce abstention;
- abstention contributes the neutral action, not a missing outcome, to policy value;
- fitted covariance matrices meet the registered numerical checks;
- a synthetic near-zero-noise fixture selects the known best feasible cue;
- null and harmful-cue simulations report false-recommendation and load-violation rates.

Simulation checks implementation and design assumptions only. They cannot be presented as evidence that the policy helps athletes.

## 11. Outcomes

### Confirmatory outcomes

**Performance:** `task_performance_score`. A task-complete trial uses \(\ln(\mathtt{cut\_completion\_time}/1\,\mathrm{s})\), from initial plant contact to the three-metre exit gate. A task or safety failure after exposure receives the frozen \(F_Y\) value. Lower values are better. Period, randomized sequence, sport, and pre-assignment natural-baseline performance are adjustment variables in the prespecified sensitivity model. Achieved entry speed, cut angle, and path error are post-assignment descriptors and are never adjustment variables for the primary contrast.

**Mechanical load:** `policy_load_contrast_analysis_value`, the P-minus-N contrast in N*m/kg derived from `peak_external_knee_abduction_moment_normalized` during stance. The raw reference requires synchronized force plates and 3D kinematics and remains null when unavailable. Nontechnical missingness is handled at the contrast level, not by treating \(\delta_L\) as an absolute load. Lower observed moments represent lower measured external joint moment only, without equating the measure to injury probability.

### Secondary measurement outcome and field-deployment criterion

Agreement between phone-derived and reference measurements is evaluated with athlete-clustered MAE, RMSE, concordance correlation coefficient, calibration slope and intercept, Bland-Altman bias, and 95% limits of agreement. Frame-level values are not treated as independent observations.

This analysis is not part of Gates 0-2. Failure blocks phone-measurement and phone-only field-deployment wording but does not remove or redefine the registered policy outcomes.

### Secondary outcomes

- Unpenalized three-metre cut time, exit velocity, change-of-direction deficit, and task-fidelity failure rate.
- Entry velocity, ground-contact time, braking impulse, and peak vertical ground-reaction force.
- Achieved change in each cue target.
- Athlete-level policy win rate.
- Recommendation coverage and abstention reasons.
- Calibration of predicted performance and load changes.
- Setup time, processing time, failed-trial rate, and safety-veto rate.
- Planned-cut retention and reactive-transfer performance at Session 3.
- Pain and perceived exertion before and after each session.

### Outcomes excluded from the study

Injury incidence, internal tissue stress, medical diagnosis, long-term performance, and live-game effectiveness are not outcomes. The paper may motivate future research on these topics but cannot claim them as results.

## 12. Reliability Pilot and Margin Lock

For each primary measure, report within-session and between-session reliability using ICC(A,1), ICC(A,k), within-athlete coefficient of variation, standard error of measurement, and minimal detectable change at 95% confidence. Report Bland-Altman bias and limits across visits.

The pilot sets:

- the number of trials (k) required for ICC(A,k) of at least 0.75;
- the entry-speed and path-error validity bands;
- the maximum tolerable phone-reference decision error;
- nuisance variances and within-athlete correlations for power simulation.

The core reliability pilot can inform repeatability, tested cue-dose acquisition counts, natural-anchor counts, tested task corridors, tested washout carryover, phone-reference error, and calibration-task nuisance distributions. It cannot establish cue efficacy, personalized-policy value, or counts and workload caps for practice, retention, reactive transfer, and filler tasks that it did not perform. Final \(B_{cal}\) and \(B_{val}\) also require the joint policy-coverage and power simulation.

The mechanical-load noninferiority margin \(\delta_L\) must be justified from prior evidence and biomechanical judgment before the pilot is analysed. Pilot noise can reject a proposed margin or force better measurement, but it cannot be used to widen the margin until the study passes. If the minimal detectable change remains larger than \(\delta_L\) at a feasible trial count, the confirmatory study stops or changes measurement under a new protocol.

The practically meaningful performance difference \(\delta_Y\) is also locked before prospective enrollment. Statistical superiority and whether the effect reaches \(\delta_Y\) are reported separately.

## 13. Randomization and Blinding

The independent data custodian generates all schedules with a reproducible seed that remains concealed until data lock.

- Calibration uses randomized `CTRL_NEUTRAL_V1`-active order within each pair and a balanced Williams design for active-cue pair order within sport. The pilot-locked washout schedule is applied before cue families and between pair members.
- Acute validation draws uniformly from the \(K_i!\) orders of each athlete's \(K_i\) distinct planned actions after P/G/N mapping and stores probability \(1/K_i!\).
- Follow-up training uses 1:1 permuted blocks of sizes 4 and 6, stratified by sport and whether P and G map to different `planned_action_definition_hash` values.

Athletes know the physical cue but are blind to its source and to the expected direction of the primary comparison. The session operator receives standardized cue text labelled only by action code. Biomechanics processors, outcome assessors, and the confirmatory statistician remain blind to decoded policy names until the quality-control report and analysis hash are signed.

Unblinding is allowed for urgent safety care. The person, reason, time, and affected records are logged.

## 14. Confirmatory Statistical Gates

The athlete is the unit of independent inference. Trials are repeated observations nested within athlete.

Let \(Y_i(P)\) and \(Y_i(G)\) be athlete-level `task_performance_score` values under the personalized and population-ranked policies. When both distinct planned actions have observed or technically imputed reference load, let \(L_i(P)\) and \(L_i(N)\) be their mean `peak_external_knee_abduction_moment_normalized` values. The finalized \(d_i^L\) is stored as `policy_load_contrast_analysis_value`.

### Gate 0: minimum policy coverage

Estimate \(C_P\), the proportion of prospective athletes whose `final_system_decision` for P is an active, deliverable recommendation after the shared safety-veto screen. A veto that leaves P at abstention or neutral and every calibration-failure fallback count as inactive; a veto followed by an approved active fallback counts as active. Coverage passes only when the lower two-sided 95% confidence bound reaches the externally justified and preregistered \(C_{min}\). This prevents high abstention from making the load contrast trivially favourable.

### Gate 1: load noninferiority

For P=N by shared planned-action identity and matching hash, set \(d_i^L=0\). For distinct P and N planned actions with complete or technically imputed load, set \(d_i^L=L_i(P)-L_i(N)\). If either exposed distinct action has task- or safety-related missing load, use \(\delta_L+\kappa_L\). If an earlier different action prevented exposure, use \(L_{max}-L_i(N)\) when only P is unexposed, \(L_i(P)-L_{min}\) when only N is unexposed, and \(L_{max}-L_{min}\) when both are unexposed. If the other action instead has exposed nontechnical missing load, the downstream upper endpoint is also \(L_{max}-L_{min}\); use the maximum of that endpoint and \(\delta_L+\kappa_L\). Estimate \(D_L=E[d_i^L]\). Noninferiority passes only when the upper one-sided 97.5% confidence bound is below the locked \(\delta_L\).

### Gate 2: performance superiority

Estimate \(D_Y=E[d_i^Y]\), where the registered contrast builder includes observed or technically imputed action summaries, shared-action zeros, and the least-favourable downstream-unexposed endpoint. Because a lower task-performance score is better, superiority passes only when the upper bound of the two-sided 95% confidence interval is below zero. Report the score contrast and task-failure contrast. Report unpenalized cut time among completed tasks as a descriptive secondary result because completion is post-assignment.

Use the phrase "practically meaningful improvement" only when the same upper confidence bound is below \(-\delta_Y\). Statistical superiority alone permits only the narrower phrase "lower registered task-performance score."

The three requirements form a gatekept claim. All must pass. Failure of any gate blocks the combined claim. Secondary outcomes cannot rescue a failed primary gate.

The registered analysis forms athlete-action summaries, then one policy contrast per athlete through `policy_action_map`, assigning zero only when two policies share one `planned_action_id` and its complete `planned_action_definition_hash` matches. It averages those contrasts across the full policy-value set, so concordant athletes are neither dropped nor duplicated. The preregistration fixes the scheduled-slot rules, estimator, confidence-interval method, and covariate-adjusted sensitivity model. Achieved speed, path, cut angle, adherence, and other post-assignment variables never enter the primary contrast.

Secondary confirmatory contrasts use Holm correction within the acute, retention, transfer, and measurement families. Exploratory interaction analyses use false-discovery-rate control and are labelled exploratory.

## 15. Missing Data, Deviations, and Sensitivity Analyses

### Analysis populations

- **Primary policy-value set:** every eligible prospective participant who begins calibration. A calibration failure creates P and G `abstain` decisions with reason `calibration_failed`, an N `fixed_neutral` decision, and three planned-action mappings to `CTRL_NEUTRAL_V1`; it is not an exclusion. Its P/G and P/N contrasts are structural zeros, and Gate 0 counts P as inactive.
- **Safety set:** every participant who begins a study cut.
- **Per-protocol set:** participants meeting the pilot-locked minimum acquisition count per required action with no major deviation. This set is secondary.

The primary analysis follows assigned policy and ignores whether the athlete achieved the cue target. Achieved dose is a secondary adherence or mediation variable.

Classify every scheduled slot as observed, technical and plausibly missing at random, a failure after that action's exposure, or `unexposed_previous_action_stop` before decoding policy labels. Multiple imputation under a missing-at-random assumption is allowed only for genuine technical loss. Exposed task or safety failures receive \(F_Y\) for performance; remaining slots in that stopped action use the same value so its denominator stays \(B_{val}\). A later unexposed action is not labelled as its own failure. For a distinct P/G comparison, substitute \(F_Y\) for an unexposed P and the registered best-performance bound \(Y_{min}\) for an unexposed G. For a distinct P/N load comparison, substitute \(L_{max}\) for an unexposed P and \(L_{min}\) for an unexposed N. An exposed nontechnical missing load uses \(\delta_L+\kappa_L\); when both load rules apply, use the larger upper bound. Shared planned actions remain zero. Do not impute an adverse event away as ordinary technical loss.

Valid extreme values remain in the primary analysis. A value is corrected or removed only when a documented equipment or transcription error is established while condition labels are masked.

### Deviation classes

- **Minor:** visit outside the window, one missing trial, brief synchronization repair, or rest interval outside tolerance.
- **Major:** wrong policy delivered, reference outcomes accessed before recommendation, model or threshold changed after freeze, ineligible participant enrolled, condition unblinded before analysis lock, or unregistered outcome-based exclusion.
- **Safety amendment:** cue removal, dose reduction, or session change required by an adverse event.

All deviations appear in a public table by blinded condition. Major deviations trigger a sensitivity analysis and an ethics review. A model change after outcome access starts a new validation version rather than being treated as a silent update.

## 16. Adverse Events and Stop Rules

### Individual trial or session stop

Apply the active `SAFETY_GLOBAL_V1` registry row. Stop immediately for participant request; any new or increased pain; sharp pain; pain of 3 or higher on a 0-10 scale; a rise of 2 or more points from the session baseline; instability, slip, trip, fall, or dizziness; neurological or chest symptoms; visible acute injury; repeated unsafe execution; the locked fatigue or RPE threshold; the maximum attempt count; equipment fault; or safety-lead concern. Provide first aid and referral under the approved emergency plan.

No athlete exposure is authorized until safety and ethics authorities approve a numerical workload contract. The pending recommendation is to lock separate pilot caps for all started protocol task attempts and for attempts delivered at maximal effort, with applicable completed, aborted, failed, reset, rehearsal, filler, and replacement attempts represented explicitly. It also proposes main-study phase-specific values based on matching-task feasibility evidence within the approved safety envelope. If adopted, reaching either workload cap or any fatigue threshold ends physical exposure without make-up trials.

Severity is registered as mild, moderate, or severe; seriousness is a separate boolean field. Mild events are transient and require no treatment or activity change. Moderate events require clinical assessment, treatment beyond simple first aid, or modification of normal sport for more than 24 hours. Severe describes intensity or functional limitation and does not automatically mean serious. A serious event follows the ethics body's definition, including life threat, hospitalization, persistent disability, or another medically important event. Relatedness is coded unrelated, unlikely, possible, probable, or definite.

### Cue stop

Pause a cue after one moderate or severe event, or any serious event, assessed at least possibly related, or after the locked repeated-mild-event threshold. A cue-wide suspension after prospective enrollment immediately pauses recruitment and closes that validation version; later athletes cannot be pooled under a reduced candidate set. Restart requires a new cue registry, policy and mapping hashes, ethics approval or amendment, preregistration version, and validation cohort. A pre-decision individual veto is recorded as `safety_veto` and follows the symmetric candidate-set rule. The safety lead reviews events while blinded to efficacy outcomes.

### Study-wide pause

Pause recruitment for:

- any serious adverse event assessed at least possibly related;
- two similar moderate-or-worse events assessed at least possibly related;
- equipment or synchronization failure that could invalidate the primary load measure;
- a privacy breach involving identifiable video or the linkage key.

Report serious events to the ethics body under its required timeline. Follow all participants for pain, medical assessment, and missed training through seven days after the final visit. Report event counts, severity, relatedness, action, and resolution without implying that absence of events proves safety.

## 17. Open Data and Reproducibility

The current [SSAC Research Paper Competition](https://www.sloansportsconference.com/research-paper-competition) requires an open-source repository containing the data used in the research. Before enrollment, the team must obtain written confirmation of what satisfies this requirement for potentially identifiable movement video.

The public release must include, at minimum:

- deidentified participant-level demographics needed for analysis, using coarse categories where possible;
- every attempted trial, cue assignment, order, acquisition status, task- and safety-outcome reason, achieved cue dose, and outcome;
- `policy_decisions`, `planned_actions`, `realized_deliveries`, `scheduled_action_slots`, `policy_action_map`, and `policy_contrasts` tables so shared planned P/G/N actions are represented once while delivery deviations, fixed denominators, and derived P-minus-G/P-minus-N values remain visible;
- synchronized derived pose, event, performance, and load tables used by the analysis;
- training, development, calibration, and validation split manifests;
- model weights, code, environment lockfile, random seeds, and freeze hashes;
- permitted external model and dataset versions, checksums, licences, and download instructions;
- the population cue ranking and every individual recommendation or abstention reason;
- preregistration, amendments, data dictionary, consent-compatible licence, model card, and datasheet;
- scripts that reproduce every number and figure from a clean environment.

Raw video is released only under explicit consent and ethics approval. If raw video is required to reproduce a headline result, it must either be released under those terms or the headline result cannot be used for SSAC. Face blur alone is not described as anonymization.

Run the release pipeline before confirmatory recruitment using synthetic data. Before submission, a team member who did not write the pipeline must clone the public repository, run the documented command, and compare generated tables and figures with the manuscript checksums.

## 18. Go or No-Go Checkpoints

1. **Before pilot:** ethics approval, consent, emergency plan, equipment, and release plan are complete.
2. **After pilot:** all primary measures meet the locked reliability requirement, the proposed load margin remains measurable, and \(C_{min}\) is fixed from the operational use case rather than prospective outcomes.
3. **Before development:** cue library, held-out sport, jointly selected development and validation sample sizes, and development split counts are frozen.
4. **Before validation:** model, population comparator, analysis, and randomization are hashed and publicly timestamped; the already frozen validation sample is verified unchanged.
5. **Before SSAC abstract:** the coverage, load, and performance gates, all adverse events, actual sample counts, confidence intervals, and the reproducibility run are complete.

Do not submit an SSAC abstract containing promised results or unresolved result placeholders. A null or negative result may still be reported. Missing confirmatory evidence cannot be replaced by model accuracy, qualitative examples, or stronger language.
