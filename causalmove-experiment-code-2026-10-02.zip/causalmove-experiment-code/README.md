# CausalMove: SSAC27 Research Package

## Current decision

CausalMove now has a complete methods-and-simulation paper and a separate final pre-results athlete-study manuscript. It is **not an SSAC27-ready athlete-benefit submission** because no real athlete intervention outcomes exist. The complete simulation paper reports 560 synthetic stress-test runs and makes no athlete-performance claim. The differentiating future empirical contribution remains a prospective test of whether a policy learned from randomized cue probes selects a better cutting cue for an individual athlete than a frozen population ranking while satisfying a preregistered mechanical-load constraint.

The October 1, 2026 abstract can proceed only if the resource gate in `ssac27-execution-plan.md` is already satisfied and real prospective results replace every bracket in `ssac27-abstract.md`. Synthetic outputs are software diagnostics and cannot be reported as athlete results.

## Research question

> Can two synchronized phones and a brief randomized calibration choose a better eligible cue for this athlete's 90-degree sidestep cut than a frozen population ranking, without worsening normalized peak external knee abduction moment beyond a preregistered margin?

Basketball and soccer supply development data. Handball is a prospective transport stress test, not proof of universal or distribution-free generalization. The system ranks four bounded, coach- and biomechanist-approved cues and can abstain. It does not generate unrestricted technique advice.

## Read these first

Source-audited update: [SSAC27 track and evidence positioning](ssac27-track-and-evidence-positioning.md) gives the current track recommendation and athlete-use threshold; [the source ledger](report-source.md) records the supporting official and primary sources.

1. [`ssac27-full-paper-simulation-study.md`](ssac27-full-paper-simulation-study.md) — complete methods-and-simulation paper with a 248-word abstract, 560 synthetic runs, completed Results section, and no empirical placeholder. The editable [`LaTeX source`](ssac27-full-paper-simulation-study.tex), compiled [`nine-page PDF`](ssac27-full-paper-simulation-study.pdf), strict [`analysis bundle`](analysis-output/analysis-report.md), and [`self-review`](ssac27-full-paper-simulation-self-review.md) report the same evidence boundary.
2. [`ssac27-full-paper-final-pre-results.md`](ssac27-full-paper-final-pre-results.md) — final pre-results athlete-study manuscript with an explicit results contract; not a completed empirical paper. The editable [`LaTeX source`](ssac27-full-paper-final-pre-results.tex) and compiled [`11-page PDF`](ssac27-full-paper-final-pre-results.pdf) are review copies of the same pre-results paper.
3. [`ssac27-full-paper-self-review.md`](ssac27-full-paper-self-review.md) — claim, citation, reviewer-risk, and finalist-criteria audit of the pre-results athlete-study manuscript.
4. [`ssac27-finalist-readiness-audit.md`](ssac27-finalist-readiness-audit.md) — direct finalist and athlete-utility judgment, evidence ladder, and claim limits.
5. [`ssac27-mock-review.md`](ssac27-mock-review.md) — evidence-only rejection today and the conditional finalist-contending standard.
6. [`gate-a-readiness-checklist.md`](gate-a-readiness-checklist.md) — fillable evidence gate separating team, expert, pilot, and development locks.
7. [`athlete-workload-audit.md`](athlete-workload-audit.md) — reached-boundary workload equations, conditional proposed-design scenarios, and unresolved session burden.
8. [`protocol-reconciliation-proposal.md`](protocol-reconciliation-proposal.md) — approval-bounded corrections for workload, phase, replacement, randomization, and phone architecture.
9. [`research-question-card.md`](research-question-card.md) — locked confirmatory question, falsification conditions, and verified evidence records.
10. [`ssac27-decision-memo.md`](ssac27-decision-memo.md) — current acceptability judgment and claim boundary.
11. [`ssac27-execution-plan.md`](ssac27-execution-plan.md) — dated 28-day route and hard go/no-go gates.
12. [`ssac27-abstract.md`](ssac27-abstract.md) — humanized, sub-500-word results template; not submission-ready while fields remain unresolved.
13. [`study-protocol.md`](study-protocol.md) and [`preregistration.md`](preregistration.md) — intervention and analysis contract.
14. [`ml-evidence-plan.md`](ml-evidence-plan.md) — baselines and ablations that test whether ML adds value.
15. [`public-data-integration-plan.md`](public-data-integration-plan.md) — verified public datasets and the causal data still missing.
16. [`docs/superpowers/specs/2026-09-03-two-phone-pipeline.md`](docs/superpowers/specs/2026-09-03-two-phone-pipeline.md) — independently reviewed, provider-neutral architecture for a local synthetic-fixture scaffold; real-video implementation remains approval-gated.
17. [`docs/superpowers/plans/2026-09-03-two-phone-pipeline-implementation.md`](docs/superpowers/plans/2026-09-03-two-phone-pipeline-implementation.md) and [`phone_pipeline/README.md`](phone_pipeline/README.md) — executable Stage 1 implementation plan, exact test command, and synthetic evidence-bundle runner.
18. [`pilot/pilot-approval-record.md`](pilot/pilot-approval-record.md) and [`pilot/pilot-session-runbook.md`](pilot/pilot-session-runbook.md) — restricted no-go-by-default approval record and visit-level operating sequence needed to move from protocol to a real reliability pilot.
19. [`results-output-contract.md`](results-output-contract.md) — immutable bundle, source-field, abstract-key, gate-conclusion, Figure 2, and independent-reproduction contract for all 22 real-result slots in the manuscript.
20. [`analysis/README.md`](analysis/README.md) — tested, deterministic Gate 0–2 conclusion generator; it consumes locked estimates and cannot create athlete evidence.

## Manuscript figure

[`figures/figure1-causal-design.svg`](figures/figure1-causal-design.svg) is the paper-ready vector schematic of the causal design, immutable policy freeze, and prospective outcome firewall. [`figures/README.md`](figures/README.md) contains its caption, claim contract, accessibility notes, and the data-gated specification for Figure 2.

## After Gate A: pilot data checks

Use the reliability pilot before selecting a sample size or claiming phone deployment:

```bash
cd "/Users/caokhanhngoc/Documents/ChatGPT/mit sloan sport/athlete-movement-ssac27"
python3 -B pilot/validate_pilot.py pilot/your-pilot-data.csv
python3 -B pilot/analyze_reliability.py pilot/your-pilot-data.csv > pilot/your-pilot-reliability.json
```

The shipped `pilot/pilot-data-template.csv` contains the registered 29-column schema and no fabricated rows. `pilot/README.md` defines the two-visit, 12–15-athlete protocol and explains each reliability statistic. The analyzer refuses structurally invalid input before estimating any result.

## Evidence hierarchy

- **Primary evidence:** prospective athlete-level comparison of personalized versus population-ranked advice, plus coverage and load noninferiority.
- **Supporting evidence:** phone-to-reference agreement, test–retest reliability, held-out-athlete prediction, and registered ML ablations.
- **Engineering evidence only:** explicit basketball/soccer/handball synthetic design simulations and passing software tests.
- **Unsupported until tested:** injury prevention, improvement during games, universal movement rules, or GOATA/WOATA validity.

## Reproduce the current software checks

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s pilot/tests -v
```

The pilot suite currently passes 39/39 tests. The independently reviewed reference-policy scaffold passes 38/38 tests; see `prototype/README.md` for its runtime and commands. These checks validate implementation behavior, not athlete benefit.

The Stage 1 two-phone software scaffold has a separate 118-test suite and deterministic synthetic runner:

```bash
/Users/caokhanhngoc/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  -m unittest discover -s phone_pipeline/tests -v
/Users/caokhanhngoc/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  phone_pipeline/run_synthetic.py \
  --input phone_pipeline/tests/fixtures \
  --output /tmp/causalmove-synthetic-stage1-check
```

The normal runner deliberately produces no policy batch and reports `load_measure_unavailable`. Its generated black videos, synthetic trajectories, and explicit event annotations test software interoperability only. They are not phone-measurement validation, athlete data, training advice, or SSAC results.

The primary claim boundary has a separate 14-test suite. It validates strict gate inequalities, every conclusion branch, malformed input rejection, deterministic output, exact-input hashing, and no-overwrite behavior:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest \
  analysis.tests.test_claim_decision \
  analysis.tests.test_generate_claim_decision -v
```

This tool is run only after the canonical real-data gate analyses are locked. Its passing tests do not resolve any manuscript result field.
