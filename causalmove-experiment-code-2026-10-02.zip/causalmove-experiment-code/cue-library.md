# Neutral Cue Library for the 90-Degree Sidestep Cut

## Purpose

This registry bounds what the model is allowed to recommend. It is a candidate intervention set, not a list of universally correct techniques. Every cue must be approved by a qualified coach and biomechanist, rehearsed at submaximal effort, and version-locked before randomized data collection.

The model may select one active cue or abstain. It may not invent a new technique, increase cue amplitude beyond the registered envelope, combine cues unless that combination was independently registered, or convert a commercial movement label into scientific ground truth.

## Task and coordinate frame

- Primary task: preplanned 90-degree sidestep cut on a marked approach and exit path.
- Incoming axis: `x_in` follows the approach.
- Exit axis: `x_out` follows the intended new direction.
- Vertical axis: `z` points upward.
- Left and right cuts are stored anatomically, then reflected only for registered side-normalized analyses.
- Events are detected with a frozen algorithm: penultimate contact, plant initial contact, weight acceptance, plant toe-off, and exit gate.

## Versioned registry fields

Each `cue_registry.tsv` row must contain:

| Field | Definition |
|---|---|
| `cue_id` | Stable neutral identifier |
| `cue_version` | Version of wording, target, and safety rules |
| `status` | `draft`, `pilot_only`, `active`, or `retired` |
| `display_text` | Exact instruction used in the trial language |
| `demonstration_id` | Versioned coach demonstration, if used |
| `target_measure_name` | Canonical feature from the data dictionary |
| `target_event` | Event or time window at which feature is evaluated |
| `dose_direction_multiplier` | `+1` if an increase follows the cue, `-1` if a decrease follows it |
| `target_rule_id` | Frozen rule that converts baseline into an athlete-specific target |
| `target_unit` | Unit of target and achieved dose |
| `pilot_dose_grid` | Conservative candidate increments approved before pilot enrollment |
| `starting_dose` | First rehearsed increment from the registered grid |
| `maximum_dose` | Largest permitted increment, never exceeded by the policy |
| `dose_escalation_rule_id` | Fixed rehearsal, tolerability, and executability rule |
| `dose_stop_rule_id` | Dose-specific stop and de-escalation rule |
| `main_dose_selection_rule_id` | Fixed reliability, executability, and safety rule used to choose or retire a dose after the pilot |
| `adherence_tolerance_id` | Frozen target band |
| `safety_rule_ids` | Global plus cue-specific eligibility rules |
| `coach_approval_id` | Signed approval and version |
| `biomechanics_approval_id` | Signed approval and version |
| `source_provenance` | Optional origin of the cue idea, with citation or internal design record |
| `permission_record_id` | Required when source provenance is proprietary |
| `scientific_ground_truth` | Always `false` |

If written permission exists, `source_provenance` may name the originating proprietary framework. A proprietary name must never become an athlete label, outcome, target, or statement of correctness.

## Candidate library

The final active subset is chosen after the reliability and safety pilot. Inclusion below does not imply benefit.

### `BASE_NATURAL_V1`: natural-technique baseline

- **Use:** anchor trials only, before randomized cue probes.
- **Display text:** "Use your normal cutting technique and follow the marked path."
- **Target:** none.
- **Operational role:** estimates athlete-specific baseline centers and variability for all registered features.
- **Dose:** not applicable.
- **Restriction:** baseline trials cannot be relabeled as successful examples after outcomes are observed.

### `CTRL_NEUTRAL_V1`: attention-matched control

- **Use:** randomized validation comparator.
- **Display text:** "Run through the gate at the requested effort and follow the marked 90-degree path."
- **Target:** task completion without a technique instruction.
- **Operational measure:** entry-speed corridor, achieved cut angle, and path error only.
- **Dose:** not applicable.
- **Restriction:** timing, delivery method, demonstration exposure, and feedback duration must match intervention conditions as closely as the protocol permits.

### `FPA_ALIGN_EXIT_V1`: orient plant foot toward exit

- **Display text:** "As you plant, point the foot slightly more toward the exit path."
- **Target feature:** `foot_exit_alignment_error_at_initial_contact`.
- **Target event:** plant initial contact.
- **Direction:** reduce the absolute wrapped angle between the plant-foot long axis and `x_out`; `dose_direction_multiplier = -1` for the absolute error.
- **Raw companion measure:** signed `foot_progression_angle_at_initial_contact` is retained so opposite rotations are not hidden by the absolute value.
- **Target rule:** move from the athlete's locked natural baseline toward the exit axis by a pilot-locked increment, clipped to the athlete's successfully rehearsed range.
- **Adherence:** achieved alignment change is inside the frozen tolerance around the pretrial target.
- **Cue-specific boundary:** never instruct an athlete to twist on a fixed foot, force rotation through the knee, or exceed the pain-free range demonstrated during screening and rehearsal.

### `PLANT_OFFSET_REDUCE_V1`: reduce lateral plant offset

- **Display text:** "Place the plant foot slightly closer beneath you as you change direction."
- **Target feature:** `plant_lateral_offset_normalized`.
- **Target event:** plant initial contact.
- **Direction:** reduce the absolute lateral distance from plant-ankle center to projected COM; `dose_direction_multiplier = -1`.
- **Target rule:** reduce the athlete's baseline offset by a pilot-locked increment, bounded by the valid marked corridor and the successfully rehearsed range.
- **Adherence:** achieved normalized offset falls inside the frozen target band while entry speed, cut angle, and path remain valid.
- **Cue-specific boundary:** no instruction may ask the athlete to drive the knee inward or outward. Trials with a forced cross-over step, loss of balance, or invalid foot contact follow the registered stop or QC rule.

### `BRAKE_EARLIER_V1`: shift deceleration before plant

- **Display text:** "Begin slowing one step earlier, then make the same 90-degree cut."
- **Target feature:** `penultimate_deceleration_share`.
- **Target window:** approach through penultimate contact, with plant contact retained for the denominator.
- **Direction:** increase the share of total approach-to-exit speed loss completed before plant contact; `dose_direction_multiplier = +1`.
- **Privileged companion measure:** penultimate braking-impulse share may be computed when sequential valid force contacts exist. It is not substituted when only one contact is measured.
- **Target rule:** increase the athlete's baseline share by a pilot-locked amount while remaining inside the same entry-speed and path criteria.
- **Adherence:** directed change reaches the frozen target band without a task-fidelity failure.
- **Cue-specific boundary:** the cue may redistribute braking, not lower the requested approach effort. Extra repetitions, excessive approach length, or a target outside the rehearsed deceleration envelope are prohibited.

### `TRUNK_TOWARD_EXIT_V1`: small trunk lean toward exit

- **Display text:** "As you plant, let your torso move slightly toward the exit path."
- **Target feature:** `trunk_lean_toward_exit_at_initial_contact`.
- **Target event:** plant initial contact, with a secondary value at peak weight acceptance.
- **Direction:** increase signed trunk lean toward `x_out`; `dose_direction_multiplier = +1`.
- **Target rule:** add a pilot-locked increment to the athlete's natural baseline, clipped to the successfully rehearsed range.
- **Adherence:** the initial-contact change is within the target band and the registered trunk-motion signal passes QC.
- **Cue-specific boundary:** no extreme side bend, rapid head movement, or compensation outside the marked path. The coach demonstrates the intended whole-torso shift before the first randomized probe.

## Athlete-specific target construction

Before pilot enrollment, each active cue has an approved conservative dose grid, starting dose, maximum dose, staged escalation rule, and dose-specific stop criteria. The pilot may select a main-study increment only through the registered reliability, executability, and safety rule. It may not improvise a new value after reviewing outcomes.

The selected main-study rule may use the feature's smallest detectable change and an athlete's rehearsed envelope. It cannot use that athlete's post-assignment outcome.

For athlete $i$ and cue $k$:

\[
T_{ik}=\operatorname{clip}\left(B_{ik}+s_k\Delta_k,\ E_{ik}^{\min},\ E_{ik}^{\max}\right),
\]

where $B_{ik}$ is the locked natural baseline, $s_k$ is the registered direction, $\Delta_k$ is the pilot-locked cue increment, and $[E_{ik}^{\min},E_{ik}^{\max}]$ is the pain-free range successfully rehearsed by that athlete. The numerical target and its calculation hash are saved before cue delivery.

No value for $\Delta_k$, the adherence band, or the envelope is supplied here because those values require approved pre-pilot bounds and reliability and safety-pilot evidence. The pre-pilot dose grid is therefore a hard prerequisite, not a field that may remain blank when pilot dosing begins.

## Global safety and delivery rules

### Before a session

- Confirm eligibility and the ethics-approved readiness screen.
- Record current pain or symptoms using the registered scale.
- Verify footwear, surface, approach area, cameras, force systems, and timing equipment.
- A coach teaches each active cue in neutral language and checks comprehension.
- The athlete rehearses at the staged effort specified by the protocol before maximal testing.

### Before every randomized trial

- Confirm the assigned cue and target were generated before trial start.
- Show or speak the exact registered wording. Save its text hash.
- Keep feedback duration and demonstration exposure consistent across arms.
- Enforce the same entry-speed, rest, path, and cut-angle rules across cues.
- Never reveal predicted performance or load to the athlete during blinded validation.

### Between cue families

- Apply the pilot-derived, version-locked washout schedule after every active cue and before a different cue family.
- The schedule includes minimum rest and registered `CTRL_NEUTRAL_V1` reset attempts; the next active cue cannot begin until the reset rule passes or the session stops.
- Save previous cue, within-pair position, global period, reset-trial IDs, and any replacement linkage.
- Random order does not by itself remove cue carryover. The confirmatory model includes previous cue and period, and a first-period or registered no-carryover sensitivity analysis is required.

### Stop or withdraw a cue

Apply one ethics-approved rule, `SAFETY_GLOBAL_V1`, everywhere in the protocol and software. Its proposed triggers are an athlete request; any new or increased pain; sharp pain; pain at least 3/10; an increase of at least 2/10 from the session baseline; instability, slip, trip, fall, dizziness, neurological or chest symptoms, visible acute injury, repeated unsafe execution, the locked fatigue or RPE threshold, the maximum attempt count, equipment fault, or safety-lead concern. The approved registry version controls if an ethics body changes these thresholds. Record the attempted trial, delivered action, mapped policy labels, event, action, and relatedness assessment. Do not replace an adverse-event trial with an unrecorded attempt.

The registry also defines maximum attempted maximal cuts including replacements, minimum recovery, a fatigue or performance-decline stop, severity and seriousness categories, and relatedness. One moderate-or-worse event assessed at least possibly related suspends that cue pending review. A repeated-mild-event suspension threshold must be locked before pilot enrollment.

A cue is unavailable to the policy when:

- its target lies outside the athlete's successfully rehearsed envelope;
- required measurement or calibration has failed;
- the model's load bound exceeds the locked noninferiority margin;
- prediction uncertainty exceeds the locked threshold;
- the coach or biomechanist suspends that cue version;
- a related adverse event triggers the protocol's withdrawal rule.

If every cue is unavailable, the only valid output is `abstain`.

## Policy interface

The policy receives a versioned candidate set and returns one of:

```json
{
  "decision": "recommend",
  "selected_cue_id": "<active registry ID>",
  "selected_cue_version": "<frozen version>",
  "target_value": "<precomputed numeric target>",
  "target_unit": "<registered unit>",
  "policy_freeze_hash": "<sha256>"
}
```

or

```json
{
  "decision": "abstain",
  "abstention_reason": "<controlled reason>",
  "policy_freeze_hash": "<sha256>"
}
```

Free-form generative advice is outside the confirmatory study. If an interface later paraphrases a cue, the exact text must pass human semantic review and receive a new cue version before it can be used experimentally.

## Approval checklist for each cue version

- [ ] Target feature has a reproducible measurement definition.
- [ ] Reliability and smallest detectable change are quantified in the pilot.
- [ ] Exact athlete-facing wording and demonstration are frozen.
- [ ] Target increment, tolerance, and envelope rule are frozen.
- [ ] Coach confirms the cue is understandable and executable.
- [ ] Biomechanist confirms the target and measurement interpretation.
- [ ] Study safety lead confirms global and cue-specific stop rules.
- [ ] Ethics approval covers the cue, measurements, and public release.
- [ ] Any proprietary provenance has written permission on file.
- [ ] Registry row states `scientific_ground_truth = false`.
- [ ] Pilot logs show no unresolved cue-related safety signal.

## Interpretation boundary

A positive response means that the assigned cue improved the preregistered outcome for the tested athlete under the tested protocol. It does not establish a universal ideal movement pattern, diagnose an injury, or show injury prevention. A cue that helps one athlete can be neutral or harmful for another, which is the heterogeneity this study is designed to measure.
