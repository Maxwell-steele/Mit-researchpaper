# Preregistration: CausalMove Prospective Policy Evaluation

**Registration platform:** OSF Registries or an equivalent immutable public registry  
**Registration status:** Draft. Do not register until every item marked `LOCK` is resolved.  
**Protocol version:** Draft 0.1, September 3, 2026  
**Related protocol:** `study-protocol.md`

## 1. Freeze Record

Complete and timestamp this table before the first prospective validation participant is enrolled.

| Field | Locked value |
|---|---|
| Ethics approval ID and date | `LOCK` |
| Public data-release language approved | `LOCK` |
| Reliability pilot registration and dates | `LOCK` |
| Pre-pilot cue dose grids, starting doses, maxima, and stop rules | `LOCK BEFORE PILOT ENROLLMENT` |
| Main-study dose-selection rule | `LOCK BEFORE PILOT ENROLLMENT` |
| Candidate pilot washout schedule and diagnostic; main-study washout selection rule and schedule | `PROPOSED; PENDING APPROVAL — PILOT SCHEDULE AND MAIN SELECTION RULE LOCK BEFORE PILOT; MAIN SCHEDULE LOCK FROM PILOT BEFORE DEVELOPMENT` |
| Candidate phone-configuration-set hash | `LOCK BEFORE PILOT ENROLLMENT` |
| Phone-configuration acceptance-rule hash | `LOCK BEFORE PILOT ENROLLMENT` |
| Pilot-qualified final phone-configuration hash and freeze time | `LOCK FROM PILOT ACQUISITION AND RELIABILITY EVIDENCE BEFORE MODEL DEVELOPMENT` |
| Maximum acceptable previous-cue carryover | `LOCK BEFORE PILOT ANALYSIS` |
| Model-development sample and disjoint split counts | `LOCK FROM JOINT PILOT-INFORMED SIMULATION BEFORE DEVELOPMENT RECRUITMENT` |
| Confirmatory validation sample and sport allocation | `LOCK FROM THE SAME JOINT SIMULATION BEFORE DEVELOPMENT RECRUITMENT` |
| Held-out sport | Handball, unless amended before the reliability pilot begins |
| Primary performance margin \(\delta_Y\) | `LOCK WITH UNITS AND JUSTIFICATION` |
| Primary load noninferiority margin \(\delta_L\) | `LOCK WITH UNITS AND EXTERNAL JUSTIFICATION BEFORE PILOT OUTCOME REVIEW` |
| Task-failure tail estimator, \(\kappa_Y\) formula, development subset, and reason hierarchy | `LOCK BEFORE MODEL DEVELOPMENT` |
| Computed task-failure performance value \(F_Y\) | `LOCK FROM THE PRESPECIFIED DEVELOPMENT CALCULATION BEFORE PROSPECTIVE ENROLLMENT` |
| Post-exposure load-contrast penalty \(\kappa_L>0\) | `LOCK WITH EXTERNAL JUSTIFICATION BEFORE PROSPECTIVE ENROLLMENT` |
| Downstream-unexposed support bounds \(Y_{min},L_{min},L_{max}\) and derivation rules | `LOCK BEFORE MODEL DEVELOPMENT; COMPUTE ONLY BY THE REGISTERED RULE BEFORE PROSPECTIVE ENROLLMENT` |
| Valid entry-speed band | `LOCK FROM PILOT` |
| Valid path-error band | `LOCK FROM PILOT` |
| Pilot natural-anchor trials \(B_{0,pilot}\) | `LOCK BEFORE PILOT` |
| Pilot paired blocks per active cue \(B_{pair,pilot}\) | `LOCK BEFORE PILOT` |
| Main natural-anchor trials \(B_0\) | `LOCK FROM PILOT` |
| Calibration paired blocks per active cue \(B_{cal}\) | `LOCK FROM PILOT-INFORMED JOINT POLICY-COVERAGE AND POWER SIMULATION` |
| Acute validation slots per distinct planned action \(B_{val}\) | `LOCK FROM THE SAME PILOT-INFORMED JOINT SIMULATION` |
| Practice, retention, transfer, and filler counts \(B_{train},B_{ret},B_{xfer},B_{fill}\) | `LOCK FROM PREDECLARED MATCHING-TASK FEASIBILITY EVIDENCE AND JOINT SIMULATION; CORE RELIABILITY PILOT ALONE IS INSUFFICIENT` |
| Pilot total-physical and maximal-attempt caps, anchor reserves per visit, and athlete-wide paired-calibration replacement cap | `PROPOSED STRUCTURE; PENDING APPROVAL — LOCK BEFORE PILOT WITH EXPLICIT UNITS AND SCOPE` |
| Main physical-visit caps and phase-specific technical replacement rules | `PROPOSED STRUCTURE; PENDING APPROVAL — LOCK FROM MATCHING PILOT OR FEASIBILITY EVIDENCE WITHIN APPROVED ENVELOPES BEFORE DEVELOPMENT` |
| Measurement decision tolerance | `LOCK BEFORE PROSPECTIVE ENROLLMENT` |
| Policy uncertainty thresholds | `LOCK BEFORE PROSPECTIVE ENROLLMENT` |
| Probability-calibration metrics, acceptance limits, and recalibration rule | `LOCK BEFORE PROSPECTIVE ENROLLMENT` |
| Minimum active-recommendation coverage \(C_{min}\) and external basis | `LOCK BEFORE PROSPECTIVE ENROLLMENT` |
| Population cue ranking | `LOCK FROM DEVELOPMENT ONLY` |
| Source-code commit | `LOCK` |
| Container or environment hash | `LOCK` |
| Model and weights hash | `LOCK` |
| Feature and preprocessing hash | `LOCK` |
| Cue registry and athlete-target-rule hash | `LOCK` |
| Data dictionary, measure registry, and QC-rule hash | `LOCK` |
| Safety-rule registry and consent-version hash | `LOCK` |
| P/G/N planned-policy-action mapping specification hash | `LOCK` |
| Randomization file hash | `LOCK` |
| Analysis script hash and dry-run checksum | `LOCK` |

Any unresolved `LOCK` blocks confirmatory enrollment. Pilot-dependent fields are filled in a dated amendment without inspecting prospective validation outcomes.

## 2. Research Question

Can a fixed treatment-response pipeline, updated only with a new athlete's randomized paired calibration trials, rank a common eligible cue set better than a fixed population ranking while keeping the derived P-minus-neutral `policy_load_contrast_analysis_value`—built from peak external knee abduction moment—inside its noninferiority margin?

## 3. Hypotheses

### Operational coverage gate

Let \(C_P\) be the proportion of prospective athletes for whom P returns an active cue. Before interpreting load noninferiority, the lower two-sided 95% confidence bound for \(C_P\) must reach the externally justified and preregistered \(C_{min}\). This prevents an almost-always-abstaining policy from passing the load gate trivially.

### Co-primary hypotheses

**H1, load noninferiority**

Let \(d_i^L\) be the canonical `policy_load_contrast_analysis_value`, the P-minus-N contrast built from observed or technically imputed `peak_external_knee_abduction_moment_normalized`, the exact-zero collision rule, and the registered nontechnical-missingness bounds. Let \(D_L=E[d_i^L]\). The null and alternative are:

\[
H_{01}:D_L \ge \delta_L, \qquad H_{11}:D_L < \delta_L.
\]

**H2, performance superiority**

Let \(D_Y=E[d_i^Y]\), where \(d_i^Y\) is the canonical `policy_performance_contrast_analysis_value`: the registered P-minus-G `task_performance_score` contrast built from observed or technically imputed action summaries, exact-zero planned-action collisions, and the least-favourable downstream-unexposed endpoint. A task-complete trial contributes \(\ln(\mathtt{cut\_completion\_time}/1\,\mathrm{s})\). A task or safety failure after exposure contributes the frozen failure value \(F_Y\). Lower values are better.

\[
H_{02}:D_Y \ge 0, \qquad H_{12}:D_Y < 0.
\]

The combined study claim requires the coverage gate plus rejection of both null hypotheses. H1 is tested after coverage passes, and H2 is interpreted confirmatorily only after H1 passes.

### Secondary hypotheses

1. Phone-derived performance and load estimates satisfy the locked agreement tolerances against laboratory reference measures.
2. After randomized practice, the athlete-specific training arm has lower planned-cut time at retention than the population-cue arm.
3. After randomized practice, the athlete-specific training arm has lower reactive-cut time than the population-cue arm.
4. Athlete-specific policy benefit varies across athletes, but sport, sex, and prior injury interactions are exploratory unless separately powered and locked.

No injury-prevention, diagnostic, or live-game hypothesis is registered.

## 4. Design

This is a staged study with three non-overlapping samples.

- Reliability pilot: 12-15 adults from the development sports, two visits, no confirmatory use.
- Model development: final target from the joint pilot-informed simulation, using basketball and soccer only.
- Prospective validation: final target and sport allocation from the same joint simulation, using new adults from all three sports.

Prospective validation begins with randomized `CTRL_NEUTRAL_V1`-active paired calibration. It then uses a within-athlete acute crossover of three policies followed by a between-athlete 1:1 randomized practice phase and a one-week retention/transfer visit.

The held-out sport contributes no pre-freeze participant data, including reliability data, and no data to population-model training or threshold selection. Its athletes receive the same fixed calibration schedule and the same registered athlete-level update as athletes from development sports.

If the safety-calibration guard uses disjoint prior-fit, conformal-calibration, and audit subsets, development recruitment must satisfy its separate split-size and upper-confidence-bound requirement. The current implementation rejects fewer than 80 development athletes. Its planning configuration uses 100 with an approximately 50/25/25 sport-stratified allocation, with exact integer counts frozen by stratum. Neither those defaults nor a reference simulator establish power. The joint simulation must justify the final counts.

## 5. Eligibility and Recruitment

Eligibility follows `study-protocol.md`. Recruitment source, club, competitive level, sex, age, prior injury, and screen failures are reported in a flow diagram. Recruitment stops at the frozen sample size, not when a favourable result appears.

Participants in the pilot or development cohort cannot re-enter prospective validation. To preserve the athlete as the independent unit, at most one prospective validation athlete may be enrolled per current competitive team or regular training group, recorded as `team_cluster_id`. If that rule is infeasible, recruitment cannot proceed under this preregistration; the team must first register a cluster-powered design, cluster-aware randomization and inference, and a revised joint simulation.

## 6. Interventions and Comparators

The policy can choose one active cue or abstain. `cue-library.md` is the versioned source of truth:

- `BASE_NATURAL_V1`: natural-technique anchor used before randomized probes, unavailable for policy selection;
- `CTRL_NEUTRAL_V1`: attention-matched control and the delivered action after abstention;
- `FPA_ALIGN_EXIT_V1`: reduce absolute foot-to-exit alignment error;
- `PLANT_OFFSET_REDUCE_V1`: reduce absolute lateral plant offset from projected centre of mass;
- `BRAKE_EARLIER_V1`: increase the share of deceleration completed before plant contact;
- `TRUNK_TOWARD_EXIT_V1`: increase signed trunk lean toward the exit at plant contact.

Before pilot enrollment, each active cue receives an ethics-approved conservative dose grid, starting dose, maximum dose, staged rehearsal algorithm, and dose-specific stop rule. The pilot selects the smallest registered increment that passes the locked reliability, executability, and safety rule. No dose outside that grid can be introduced. Exact main-study prompts, pilot-locked increments, allowable target ranges, adherence tolerances, and safety boundaries are frozen before model development. Only one variable is cued at a time.

The acute comparators are:

1. **P:** cue or abstention returned by the frozen athlete-specific policy;
2. **G:** the highest cue in a development-locked population ranking that passes the same athlete-specific performance, load, uncertainty, support, and safety screen as P;
3. **N:** `CTRL_NEUTRAL_V1`.

An abstention is recorded as `abstain` and delivers `CTRL_NEUTRAL_V1`. When any of P, G, and N resolve to an identical intended action, the mapper must reuse one `planned_action_id` with a matching complete `planned_action_definition_hash`. One shared action block is collected and each contrast between policies sharing it is zero. This covers P=G, P=N, G=N, and P=G=N. Every attempted trial separately stores the actual cue, target, text, demonstration, `realized_delivery_hash`, and delivery status. Wrong or partial delivery remains assigned to the planned action for intention-to-treat analysis and never changes a collision zero after the fact.

## 7. Randomization and Allocation Concealment

An independent data custodian generates schedules using a recorded software version and seed.

- Calibration randomizes `CTRL_NEUTRAL_V1`-active order within each pair and uses a balanced Williams design for active-cue pair order within sport. Apply the pilot-locked washout schedule before cue families and between pair members.
- After P/G/N mapping, acute validation computes \(K_i\), the number of distinct planned actions, and randomizes uniformly over that athlete's \(K_i!\) unique action orders. Store allocation probability \(1/K_i!\). The frozen randomizer handles \(K_i=1,2,3\) without an incomplete balance block.
- Practice allocation uses 1:1 permuted blocks of sizes 4 and 6, stratified by sport and whether P and G map to different `planned_action_definition_hash` values.

The complete allocation list and each unreleased next assignment remain inaccessible to recruiters and session staff. The system reveals only the action needed for the current randomized unit. Outcome assessors remain masked until database and analysis lock. Allocation occurs only after eligibility and the applicable pre-assignment baseline data are complete.

## 8. Blinding

Athletes are told the cue but not whether it was chosen by the athlete-specific policy, population policy, or control procedure. The cue display and delivery timing are identical across conditions.

The operator sees a coded prompt and cannot alter it. Automated outcome extraction, manual quality review, and confirmatory analysis use masked labels. The decode key is released only after the quality-control report, exclusion log, analysis hash, and primary output files are signed.

Emergency unblinding is recorded and reported.

## 9. Model and Recommendation Rule

### Model inputs

Only the two phone videos, assigned cue, prespecified anthropometric fields, plant side, and that athlete's calibration trials are permitted. Sport identity is recorded for analysis but is not an input to P or G, so the held-out sport does not require an unseen category parameter. Prospective reference force and laboratory kinematic outcomes are sealed from the policy pipeline.

### Model class

A frozen hierarchical multi-output treatment-response model estimates cue-specific changes from `CTRL_NEUTRAL_V1` using randomized paired differences in:

- registered task-performance score;
- normalized peak external knee abduction moment.

For athlete \(i\), active cue \(a\), and paired block \(b\), the calibration summaries are

\[
Z^Y_{iab}=S^{active}_{iab}-S^{control}_{iab},
\qquad
Z^L_{iab}=L^{active}_{iab}-L^{control}_{iab}.
\]

Assigned cue and randomized order define the primary calibration contrast. Achieved dose is post-assignment behaviour and is used only in registered secondary adherence or mediation analyses.

In prospective calibration, \(S\) and \(L\) in these summaries are outputs from the frozen phone measurement layer and failure-score rule. Laboratory reference values are recorded concurrently but remain encrypted and unavailable to the recommendation pipeline, session team, and model developers. Reference processing uses masked action labels, and decoding waits for database and analysis lock. The response likelihood includes previous cue, within-pair position, pair replicate, and global period. Store `pair_id`, `pair_replicate`, `previous_cue_id`, `washout_trial_ids`, and `replacement_of_trial_id`. A first-period-only or no-carryover analysis is prespecified as a sensitivity check.

Population parameters, video feature extractor, hyperparameters, candidate-cue support, and population cue ranking use only their frozen development roles. If the guard is active, athlete-level sport-stratified randomization creates disjoint prior-fit, conformal-calibration, and audit subsets before outcome access. IDs are first placed in a canonical order and then assigned only through the registered seeded shuffle, so arbitrary ingestion order cannot change the split or audit sequence. No trial, view, or athlete crosses roles. In a prospective athlete, permitted calibration trials have only `personal_update_role=update_input`; later validation outcomes have only `prospective_outcome_role=evaluation` and cannot update the population system or thresholds.

### Selection and abstention

For eligible cue \(a\), the policy evaluates predicted performance change \(\Delta Y_i(a)\) and load change \(\Delta L_i(a)\). It recommends:

\[
a_i^*=\arg\min_a E\{\Delta Y_i(a)\mid D_i\}
\]

only when:

\[
P\{\Delta Y_i(a)<-\delta_Y\mid D_i\}\ge0.80
\]

and

\[
P\{\Delta L_i(a)\le\delta_L\mid D_i\}\ge0.95.
\]

The cue must also pass the frozen uncertainty, observed-support, and safety-envelope thresholds. Failure of any rule returns `abstain` and a machine-readable reason, with `CTRL_NEUTRAL_V1` delivered during validation. The 0.80 and 0.95 values are called probabilities only after development-set Brier-score, reliability-curve, and coverage checks pass the locked limits. Any recalibration is fitted in development and frozen.

P and G use one common eligible set produced by the athlete-specific performance and load bounds, uncertainty rule, support rule, safety veto, fallback, and one-cue action budget. P orders that set by athlete-specific predicted performance. G ignores that personal ordering and chooses the first eligible cue in the frozen development population ranking. Report P and G coverage separately and decompose the P-minus-G difference into active-cue reranking, P-only abstention, G-only abstention, and policy concordance. Under the shared-set rule, asymmetric abstention is a protocol-deviation diagnostic rather than an expected policy difference.

Before final P/G decisions, a safety reviewer assesses every athlete-specific cue-target candidate under neutral codes, without policy source, ranking, predicted benefit, or validation outcomes. A veto removes that candidate from the common candidate set and both frozen fallback rules rerun. Store `raw_model_decision`, `final_system_decision`, `veto_rule_id`, `reviewer_id`, and `review_created_utc`. Gate 0 counts final deliverable P decisions. If calibration does not meet its minimum, emit P and G `abstain` decisions with reason `calibration_failed`, an N `fixed_neutral` decision, and three `calibration_failure_structural_neutral` mappings to the same planned `CTRL_NEUTRAL_V1` action.

### Freeze evidence

The public registration attaches or hashes the feature schema, preprocessing, source commit, environment, trained weights, priors, thresholds, seeds, population cue ranking, and recommendation script. The script is dry-run on synthetic participants before prospective enrollment.

## 10. Outcomes and Measurement Time Points

### Co-primary outcomes

1. **Performance:** `task_performance_score` during Session 2. A completed task uses \(\ln(\mathtt{cut\_completion\_time}/1\,\mathrm{s})\), from initial plant contact to the three-metre exit gate. A task or safety failure after exposure uses the frozen \(F_Y\) value. Lower is better.
2. **Mechanical load:** `policy_load_contrast_analysis_value` during Session 2, the P-minus-N contrast in N*m/kg derived from `peak_external_knee_abduction_moment_normalized`. The raw stance value requires a valid synchronized force-plus-3D reference and remains null otherwise. Nontechnical missingness is handled conservatively in the contrast, not by treating \(\delta_L\) as an absolute load. Lower observed moments represent lower measured external moment only.

### Secondary outcomes

- Exit velocity, change-of-direction deficit, ground-contact time, braking impulse, peak vertical ground-reaction force, and path error.
- Achieved kinematic dose for the assigned cue.
- Athlete-level policy win, coverage, abstention, safety veto, and processing time.
- Phone-reference MAE, RMSE, concordance correlation, calibration, bias, and limits of agreement.
- Session 3 planned-cut retention and reactive-cut transfer.
- Pain, RPE, failed trials, and adverse events.

Every outcome resolves to one hashed row in `measure_registry.tsv`. Before prospective enrollment, the two primary rows must lock the formal equation, initial-contact and exit-gate events, force threshold, stance window, gap filling, filtering and resampling, inverse-dynamics method, coordinate and anatomical frames, knee-moment sign, signed-versus-absolute peak rule, multiple-peak handling, body-mass normalization, timing precision, aggregation level, acquisition-failure rule, task-failure score, favourable sign, and gate interpretation. A plain-language measure name is not sufficient to start analysis.

## 11. Unit of Analysis

The athlete is the independent unit. Individual trials are repeated measures nested within athlete. Camera frames, joints, views, trials, and left/right events are never counted as independent participants.

The primary estimands average policy value across the prospective validation population. A sport-specific claim requires a separately powered contrast. The held-out-sport estimate is reported with its uncertainty even when inconclusive.

## 12. Sample Size

The development and validation samples are selected jointly by a pilot-informed Monte Carlo simulation that regenerates the complete development, model-freeze, policy-selection, and validation process. It includes cue-effect heterogeneity, disjoint fit/calibration/audit splits, safety-guard upper-confidence-bound behavior, winner selection, measurement error, the P and G abstention rules, policy concordance, sport allocation, performance-load covariance, fixed-slot task and safety failures, downstream-unexposed actions, technical missingness, and withdrawal. It does not use prospective validation outcomes. A reference implementation is a design scaffold only; its default sample values are not power evidence.

The development sample must first satisfy the guard's separately registered minimum counts and error-bound target in every disjoint subset. Conditional on that constraint, the chosen pair of samples must give at least 80% Monte Carlo probability that all three conditions hold in the same simulated study: the coverage gate passes, H1 passes at one-sided \(\alpha=0.025\), and H2 passes using the two-sided 95% confidence interval. The assumed true load contrast \(D_L^{true}\) is stated separately from the allowed noninferiority margin \(\delta_L\). The assumed true performance contrast, coverage, concordance, and withdrawal rates are also reported. Sample size includes the locked withdrawal allowance rather than applying an undocumented inflation afterward.

The simulation script, assumptions, seed, marginal power curves, joint power curve, selected development and validation sample sizes, and all split minima are attached to the preregistration. If either required sample is infeasible, the study is labelled a pilot and does not make the confirmatory policy claim.

## 13. Attempt Classification and Exclusion Rules

Every assigned attempt is classified while policy labels are masked.

**Technical acquisition failure:** corrupted or absent required file, synchronization failure, instrument saturation, confirmed frozen-pipeline failure, or an external interruption unrelated to the athlete's movement. Pending approval, the proposed amendment would retain the original attempt and activate only the next replacement permitted by a phase-specific frozen rule; anchor reserves and paired-calibration replacement pairs would have different units and caps, and no extra attempt would replace a fixed acute, retention, transfer, or filler slot unless a separate one-to-many rule were registered and represented in the schema. Until that amendment is approved and frozen, no generic technical-replacement operation is authorized.

**Post-assignment task or safety outcome:** wrong plant limb, entry speed outside the requested corridor, path or cut-angle error, missed force area caused by foot placement, slip, stumble, inability to execute the target, pain stop, or withdrawal after cue exposure. These events are not excluded, and no replacement is scheduled because the outcome was unfavourable. A pre-delivery `safety_veto` removes the candidate symmetrically before final P/G decisions; a resulting abstention maps to `CTRL_NEUTRAL_V1`.

For performance, a completed task receives log cut time and a task or safety failure receives \(F_Y\), the value computed from the registered successful-development-trial upper tail and \(\kappa_Y\) formula. The tail estimator, penalty formula, development subset, and reason hierarchy are locked before model development; the resulting value is frozen before prospective enrollment. For load, use the measured value whenever acquisition exists and otherwise leave the absolute load null. The contrast builder applies the registered \(\delta_L+\kappa_L\) rule; it never substitutes a contrast margin as an outcome value.

A high or low outcome, failure to improve, poor cue adherence, policy abstention, and apparent outlier status without verified equipment or transcription error are never exclusion reasons. A confirmed violation of a pre-assignment eligibility rule may exclude a participant from the primary target population only after masked adjudication. That participant remains in the flow diagram and an all-enrolled sensitivity analysis. Consent withdrawal removes prior data only when required by law or the consent terms. Every enrolled participant appears in the flow diagram and attempt log.

## 14. Analysis Populations

### Primary policy-value set

All eligible prospective participants who begin calibration enter the primary set. Failure to complete calibration creates P and G `abstain` records with reason `calibration_failed`, an N `fixed_neutral` record, and three planned-action mappings to `CTRL_NEUTRAL_V1` using `calibration_failure_structural_neutral`. Its P/G and P/N contrasts are structural zeros, and Gate 0 counts P as inactive. Participants remain in the set after non-adherence, safety veto, task failure, cue suspension, or protocol deviation. Technical missingness and safety-related missingness follow different registered rules.

### Safety set

All participants who begin a study cut.

### Per-protocol set

Participants meeting the pilot-locked minimum acquisition count per required action, with no major deviation and attendance within the registered visit windows. This analysis is secondary and cannot replace the primary analysis.

## 15. Primary Analysis

### Primary estimator and policy mapping

The frozen randomization file pregenerates \(B_{val}\) scheduled slots for every distinct nonstructural planned action. A calibration-failure structural-neutral action has zero exposure slots and its registered contrasts are structural zeros. Each nonstructural slot is classified as observed, technical missing, failure after that action's exposure, or downstream-unexposed because a previous action stopped the session. For athlete \(i\) and action \(a\), \(\bar Y_{ia}\) is the fixed-denominator mean across its \(B_{val}\) performance slots. An exposed task or safety failure receives \(F_Y\), and every unattempted remainder of that stopped action also receives \(F_Y\). A later action not exposed because of the prior stop is labelled downstream-unexposed, not as a failure of the unreceived action. Technical missingness follows Section 18.

When all load slots for planned action \(a\) are observed or technically imputed, let \(\bar L_{ia}\) be their fixed-denominator mean `peak_external_knee_abduction_moment_normalized`. Nontechnical missing load remains null until `policy_load_contrast_analysis_value` is constructed.

Let \(a_i(P)\), \(a_i(G)\), and \(a_i(N)\) be the action IDs obtained by joining `policy_decisions`, `policy_action_map`, and `planned_actions`. When both required performance action summaries are available, construct

\[
d^Y_i=\bar Y_{i,a_i(P)}-\bar Y_{i,a_i(G)}.
\]

If P and G share one `planned_action_id` and its `planned_action_definition_hash` matches, set \(d_i^Y=0\). For distinct actions, a downstream-unexposed P value is replaced by \(F_Y\), and a downstream-unexposed G value is replaced by \(Y_{min}\), the frozen best-performance support bound. Retain the observed, failure-composite, or technically imputed value for the other action. Thus, if both are downstream-unexposed, \(d_i^Y=F_Y-Y_{min}\). This is the upper endpoint of the partial-identification interval and is least favourable to the superiority claim.

For load, set

\[
d_i^L=\begin{cases}
0, & a_i(P)=a_i(N)\text{ and the planned-action hashes match},\\
\bar L_{i,a_i(P)}-\bar L_{i,a_i(N)}, & \text{both distinct action summaries are complete or technically imputed},\\
\delta_L+\kappa_L, & \text{a distinct exposed action has task- or safety-related missing load},
\end{cases}
\]

where \(\kappa_L>0\) is frozen with external justification. If only P is downstream-unexposed and N is observed or technically imputed, use \(L_{max}-\bar L_{i,a_i(N)}\). If only N is downstream-unexposed and P is observed or technically imputed, use \(\bar L_{i,a_i(P)}-L_{min}\). If both are downstream-unexposed, use \(L_{max}-L_{min}\). If one action is downstream-unexposed and the other has exposed nontechnical missing load, use the maximum of \(L_{max}-L_{min}\) and \(\delta_L+\kappa_L\). Thus \(\delta_L\), a contrast margin, is never used as an absolute KAM value.

When any two policies share one `planned_action_id` and its complete `planned_action_definition_hash` matches, the shared outcome is read once and their contrast is exactly zero. This covers P=G, P=N, G=N, and P=G=N. The primary estimators are the arithmetic means of \(d_i^Y\) and \(d_i^L\) over the full policy-value set. They are unadjusted because distinct-action order is randomized. This estimator remains defined when cue identities and numerical targets differ across athletes.

The prespecified precision sensitivity first residualizes trial outcomes with a masked random-intercept model containing global period, randomized sequence, sport, and the corresponding pre-assignment `BASE_NATURAL_V1` outcome. It then rebuilds action means and policy contrasts with the same mapping. Achieved speed, path error, cut angle, adherence, and all other post-assignment variables are excluded. A second sensitivity uses raw medians rather than action means. Neither sensitivity replaces the primary estimator.

### Gate 0

Estimate \(C_P\), the proportion of prospective athletes whose `final_system_decision` for P is active and deliverable after the shared safety-veto screen. Both a veto that leaves P at abstention or neutral and a calibration-failure fallback are inactive; a veto followed by an approved active fallback is active. Coverage passes only when the lower two-sided 95% confidence bound reaches the externally justified \(C_{min}\).

### Gate 1

Estimate \(D_L=E[d_i^L]\). Declare load noninferiority only if the upper one-sided 97.5% confidence bound is below \(\delta_L\).

### Gate 2

If Gates 0 and 1 pass, estimate \(D_Y=E[d_i^Y]\). Declare performance superiority only if the upper bound of the two-sided 95% confidence interval is below zero.

Report policy-specific task-performance scores, the mean within-athlete difference, standardized paired effect, confidence interval, prespecified p-value, and task-failure-rate difference. Report unpenalized cut time among completed tasks as descriptive because completion is post-assignment. Also report the proportion whose personalized policy beats the population policy with an athlete-level confidence interval.

Use the phrase "practically meaningful improvement" only when the upper confidence bound for \(D_Y\) is below \(-\delta_Y\). A bound below zero but not below \(-\delta_Y\) supports only the narrower statement that the registered task-performance score was lower.

### Inference

Gate 0 uses a two-sided 95% Wilson interval. With complete technical acquisition, Gate 1 uses the upper limit of a one-sided 97.5% one-sample t interval for \(d_i^L\), and Gate 2 uses the upper limit of a two-sided 95% one-sample t interval for \(d_i^Y\). The corresponding boundary-null t tests provide p-values. The exact finite-sample operating characteristics of these estimators, including the failure-score mixture, are checked in the frozen sample-size simulation.

Each multiply imputed dataset passes through the same contrast builder. Point estimates and variances are combined with Rubin's rules and Barnard-Rubin degrees of freedom; the resulting pooled limits determine the gates when residual technical imputation is required. A 10,000-resample athlete bootstrap stratified by sport, with a seed distinct from the randomization seed, and the unadjusted complete-technical-case analysis are reported as sensitivities. All numerical details are implemented and checksum-locked before prospective enrollment.

The coverage gate and two primary hypotheses form one gatekept claim. All three must pass. No secondary result can overturn failure of any gate.

## 16. Measurement Analysis

Phone-reference agreement is a prespecified secondary measurement analysis on prospective validation trials. Report MAE, RMSE, concordance correlation, calibration intercept and slope, Bland-Altman bias, and 95% limits of agreement. Confidence intervals resample athletes, not frames.

A phone-deployment measurement claim is allowed only if:

- the confidence interval for mean bias lies inside the locked equivalence interval;
- the 95% limits-of-agreement half-width is smaller than the registered decision tolerance;
- the performance and load engineering error criteria both pass.

These are engineering deployment criteria, not Gate 0, 1, or 2. Failure leaves the policy outcomes intact but blocks wording that the phone accurately measures the registered biomechanics in individual athletes or supports phone-only field deployment.

## 17. Retention and Transfer Analysis

The randomized practice allocation is analysed by intention to treat. The primary secondary contrast is athlete-specific-practice versus population-practice at Session 3, adjusted for the corresponding pre-practice Session 2 neutral value and sport, with an athlete random intercept for repeated planned and reactive trials. Achieved Session 3 entry speed and path are post-randomization variables and are not primary adjustment covariates.

Planned retention and reactive transfer are separate outcome families. Holm correction controls the family-wise error rate within each family. Report an all-randomized estimate and a prespecified descriptive estimate among athletes for whom P differed from G. The latter is not a replacement for intention-to-treat inference.

No result from the reactive laboratory task is described as live-game effectiveness.

## 18. Missing Data

Every pregenerated validation slot is classified before policy decoding as:

1. **technical and plausibly MAR:** corrupted file, synchronization failure, instrument saturation, or unrelated external interruption;
2. **task failure after action exposure:** missed capture caused by assigned movement, path failure, wrong limb, slip, stumble, or inability to execute;
3. **safety failure after action exposure:** pain, instability, adverse event, or withdrawal after exposure;
4. **`unexposed_previous_action_stop`:** the action was never received because a previous action stopped the session.

The analysis retains every observed outcome. Multilevel multiple imputation under missing at random is permitted only for category 1. Its predictors are sport, pre-assignment baseline performance and load, randomized sequence, period, prior injury, baseline pain, and observed outcomes. Post-assignment entry speed, path, achieved dose, and future outcomes are not imputation predictors. Use at least 50 imputations or more than the percentage of incomplete cases, whichever is larger.

Categories 2 and 3 receive \(F_Y\) in the exposed action's scheduled performance slots; any remaining slots in that stopped action also receive \(F_Y\). Category 4 is not attributed to the unreceived action. Its P/G contrast uses the least-favourable substitutions P=\(F_Y\) and G=\(Y_{min}\); its P/N load contrast uses P=\(L_{max}\) and N=\(L_{min}\), retaining an available other-policy value. Exposed task- or safety-related missing load in a distinct P/N comparison yields \(d_i^L=\delta_L+\kappa_L\); when both rules apply, take the larger upper bound. A pre-delivery `safety_veto` is resolved symmetrically in the candidate set before final P/G decisions and therefore does not itself create a missing slot. An intervention-related moderate-or-worse adverse event blocks wording that the policy was safe or well tolerated, regardless of the numeric load gate.

Sensitivity analyses include:

1. complete technical cases while retaining task and safety failures;
2. per protocol;
3. first-period-only and no-carryover analyses;
4. a tipping-point analysis that varies \(\kappa_L\) and the frozen \(Y_{min},L_{min},L_{max}\) support bounds toward worse personalized-policy performance and load;
5. the full lower and upper partial-identification interval for downstream-unexposed actions, reported separately from the least-favourable primary endpoint;
6. a failure-score sensitivity that varies \(F_Y\) across the locked development-supported range and a rank composite in which every task failure is worse than every completed task.

The number and reason for missing observations are reported by masked action and then by decoded policy after lock.

## 19. Assumptions, Outliers, and Transformations

The primary performance outcome is log transformed by design. Inspect conditional residual and random-effect diagnostics without using them to switch among favourable models.

Valid extreme values remain in the primary analysis. Verified equipment spikes are corrected only by the locked signal-processing rule or marked missing with a reason. Report robust-estimator and untransformed-outcome sensitivity analyses.

Model convergence, residual behaviour, heteroskedasticity, and influence are documented. Diagnostics can qualify confidence in the result but do not authorize an unregistered primary model.

## 20. Multiplicity

- Primary claim: Gate 0 must pass, then the intersection-union rule requires both H1 and H2 to pass.
- Acute secondary outcomes: Holm correction within one family.
- Measurement outcomes: two locked engineering error criteria; remaining metrics are descriptive.
- Planned retention outcomes: Holm correction within family.
- Reactive transfer outcomes: Holm correction within family.
- Heterogeneity and interaction analyses: Benjamini-Hochberg false-discovery-rate control at 5% and exploratory labels.

All tested contrasts, including null and adverse results, appear in the released analysis table.

## 21. Heterogeneity and Fairness

Report sample composition and performance separately by sport and sex when cell sizes protect privacy. Evaluate calibration error, abstention, safety veto, missingness, and policy benefit across these groups with confidence intervals.

These analyses are descriptive unless the power simulation locks a confirmatory interaction. Small cells are combined or suppressed under the data-release plan, not interpreted as evidence of no disparity.

## 22. Protocol Deviations

The blinded data custodian classifies deviations before label decoding. Major deviations include wrong cue delivery, premature reference-data access, a changed model or threshold, condition unblinding, ineligible enrollment, and outcome-based deletion.

Report every deviation, its date, cause, affected records, correction, and whether an ethics amendment was required. A change to the policy after prospective outcomes are accessible creates a new version and new validation cohort.

## 23. Adverse Events and Stopping

The active `SAFETY_GLOBAL_V1` row in `safety_rule_registry.tsv` and the `study-protocol.md` rules apply. Stop an individual attempt or session for participant request; any new or increased pain; sharp pain; pain at least 3 of 10; a rise of at least 2 points from session baseline; instability, slip, trip, fall, or dizziness; neurological or chest symptoms; visible acute injury; repeated unsafe execution; the locked fatigue or RPE threshold; the maximum attempt count; equipment fault; or safety-lead concern. Pause a cue after one moderate or severe event, or any serious event, assessed at least possibly related, or after the locked repeated-mild-event threshold. Record `safety_veto` and `cue_suspended` as policy reasons.

A cue-wide suspension after prospective enrollment pauses recruitment and closes that validation version. Do not pool later athletes tested under a reduced candidate set. Restart requires a new cue registry, P/G policy and mapping hashes, ethics approval or amendment, preregistration version, and validation cohort.

Recruitment pauses after a possibly related serious event, two similar moderate-or-worse possibly related events, a primary-measure equipment failure, or a privacy breach. Severity and relatedness definitions, minimum rest, RPE threshold, and performance-decline fatigue threshold are frozen before pilot enrollment. The pending safety amendment proposes separate pilot total-physical and maximal-attempt ledgers representing applicable resets, rehearsal, failures, and replacements, plus main-study phase-specific values based on matching-task feasibility evidence within approved envelopes. That structure and every numerical value require safety and ethics approval before adoption.

Stopping for efficacy or futility is not planned. The study ends at the frozen sample size unless the independent safety lead stops it.

## 24. Open Science and SSAC Release

Before data collection, verify the current [SSAC competition rule](https://www.sloansportsconference.com/research-paper-competition) requiring a repository with the data used in the research. The registration links the consent-compatible release plan.

Consent to public release of the analysis-ready tabular and derived movement data is an eligibility condition for the prospective SSAC cohort. A person who declines can enter only a separately declared internal feasibility cohort assigned before any outcome is observed; those records never enter the SSAC analysis. Raw-video consent is separate. Pose, gait, detailed trajectories, exact anthropometry, and rare adverse-event combinations are treated as potentially re-identifiable. Any controlled-access substitute requires written SSAC acceptance before enrollment.

Release:

- protocol, preregistration, and all amendments;
- participant flow, masked quality-control log, and deviations;
- every attempted trial, acquisition/task/safety classification, and the analysis-ready derived video, kinematic, force, and outcome tables used in the paper;
- `policy_decisions`, `planned_actions`, `realized_deliveries`, `scheduled_action_slots`, `policy_action_map`, and `policy_contrasts`, so fixed denominators, deviations, and P-minus-G/P-minus-N contrasts are reproducible without outcome duplication;
- complete split manifests and data provenance;
- code, weights, hashes, seeds, environment, and exact reproduction command;
- external pretrained models and datasets with versions, checksums, licences, and overlap checks;
- all planned results, including null results and adverse events;
- model card, dataset datasheet, and limitations.

Raw video is public only when consent and ethics approval explicitly allow it. If a paper result depends on non-releasable input data and SSAC does not accept a privacy-preserving alternative, that result is excluded from the SSAC submission.

## 25. Claim Rules

### Allowed after all three gates pass

The frozen athlete-specific policy improved the registered cutting-performance outcome relative to the frozen population policy in the tested population, and the derived P-minus-neutral external-knee-moment contrast satisfied its prespecified noninferiority margin.

This wording supports only an acute laboratory policy-value claim. A training-effect claim additionally requires a favorable randomized, feedback-free Session 3 retention result; a game-performance claim requires separate field evidence.

### Required weaker wording after any gate fails

Report the observed estimates and uncertainty, state which gate failed, and treat the policy as unconfirmed.

### Prohibited wording

- prevents injuries or proves a safer movement pattern;
- finds a universally optimal technique;
- validates GOATA or WOATA;
- measures internal tissue stress from phone video;
- works in competition or across sports not prospectively studied;
- proves personalization when P does not outperform G.

## 26. Completion Gate Before Registration

- [ ] Every `LOCK` field is filled.
- [ ] Ethics approval and consent language are attached.
- [ ] Pilot report contains reliability, margins, and power inputs.
- [ ] Held-out sport and cue library are frozen.
- [ ] Population model and comparator are hashed.
- [ ] Synthetic-data dry run reproduces the complete output table.
- [ ] Randomization and masking procedures have been rehearsed.
- [ ] Public-release pipeline has passed privacy review.
- [ ] A statistician who did not develop the policy has reviewed the estimands and code.

Registration and the full freeze occur before the first prospective validation participant is enrolled or produces baseline or calibration data. Later amendments are dated, justified, and clearly separated from the original confirmatory plan.
